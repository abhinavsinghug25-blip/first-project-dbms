# Testing status — what was actually run, and what was not

## Executed during development (sandbox without MySQL / FastAPI / internet)
| Check | Result |
|---|---|
| `python tools/generate_seed.py` — self-check that the 189 seeded weekly slots have **no room, teacher or section overlap** | passed |
| `python -m unittest discover -s backend/tests -p test_scheduling_logic.py` — 25 tests: interval overlap incl. adjacent/contained, time-window rules, "only the target class may be replaced", time parsing/serialisation, `can_decide` / `require_section` authority rules (self-approval, other section, ADMIN-routed, viewer) | **25/25 passed** |
| `py_compile` of every backend module and test; `node --check` of all JS | passed |
| Real-browser (headless Chromium) smoke test, `tools/browser_smoke_test.js`, against `tools/mock_server.py` (a stand-in API that returns the real response shapes): login error, live data load, role-specific navigation, CR section-limited dropdown, cancel dialog + room freed, direct cross-section cancel → 403, viewer has no write controls, ADMIN console loads, no JS errors. Ran 3×, stable | passed |

## NOT executed — needs your environment (be explicit about this in your viva)
* `db/001_schema.sql`, `002_seed.sql`, `003_dcl.sql`, `004_demo_queries.sql`, `005_migration_example.sql` were **never run against MySQL**
  (written carefully for 8.0.16+, reviewed for the known pitfalls — CHECK vs. FK actions, table-level GRANT/REVOKE — but unexecuted).
  Run them in order and read any error message first; typos are most likely here.
* The FastAPI application (`backend/app/**`) was compile-checked only; it has **not been started** or called over HTTP.
* `backend/tests/test_api_integration.py` (viewer/CR/ADMIN permission matrix, signup mass-assignment, CSRF, cancel scope + automatic release,
  CR→CR approval, self-approval, unrelated CR, stale decision, reject-needs-reason, replace-on-approval, section clash, **concurrent approvals**,
  room change, audit visibility) is written but has **not been run**. To run:
  `cd backend && RW_INTEGRATION=1 python -m pytest tests -v` (needs the seeded DB and the `.env`).
* The real frontend ↔ real backend pairing has not been exercised; only frontend ↔ mock.

## Things to watch when you first run it
1. Concurrency test: two approvals can also be resolved by a deadlock/lock-timeout, which the API reports as 409 "busy" — still safe (nothing committed).
2. `INSERT IGNORE` materialisation runs on reads; if you see many 409 "busy" under load, pre-generate with `python -m app.cli materialize --weeks 12`.
3. Timezones: "today" uses the server's local date; MySQL timestamps are UTC (`time_zone='+00:00'` per connection).
4. Frontend time model is whole-hour; fractional-hour classes created through the API are shown rounded up to whole hours.

## Manual checklist (tick during the demo)
- [ ] Signup creates VIEWER; sending `role` in the body is rejected (422)
- [ ] VIEWER: reads work, every write → 403, no Requests/Schedule/Admin pages
- [ ] CR: only assigned sections in dropdowns, cancel other section → 403
- [ ] Cancel needs a reason; room shows Available at once; row still exists as Cancelled; notification to ADMIN/CRs
- [ ] Request routed to owning CR (or ADMIN); requester cannot approve; unrelated CR cannot
- [ ] Approve creates a *new* class, old one stays Cancelled; stale second approval → 409; reject needs reason
- [ ] Clash (room/teacher/section/capacity/inactive room/teacher unavailable) refused with explanation
- [ ] ADMIN edits any class/room/section/CR assignment; every action appears in the audit log
- [ ] `roomwise_app` cannot DROP/ALTER or delete audit rows

## Fix log: MySQL 8 error 3065 on `POST /api/requests`
`common.cr_ids_for_section` used `SELECT DISTINCT a.user_id … ORDER BY a.assignment_id`. Replaced by
`SELECT a.user_id … GROUP BY a.user_id ORDER BY MIN(a.assignment_id)`. `errors.py` no longer reports every SQL error as
"database unavailable" (503); only real connection/auth failures do, everything else is a logged 500.
* Ran here (no DB): `tests/test_routing_regression.py` (10 tests: SQL shape, static DISTINCT/ORDER BY guard over all app SQL, routing for
  one CR / several CRs / no CR / free room, requester excluded, notification de-duplication) — pass, and the guard flags the old query.
* NOT run here: `tests/test_api_integration.py::Routing` against MySQL 8 (needs your DB): `RW_INTEGRATION=1 python -m pytest tests/test_api_integration.py -k Routing -v`

## Displacement / daily schedule / rescheduling (added with migration 006)
**Run in the authoring sandbox (no MySQL, FastAPI, PyMySQL or network available):**
`cd backend && python -m unittest tests.test_displacement_unit tests.test_scheduling_logic tests.test_routing_regression -v` — 52 tests, all passed
(display-status derivation, notification recipients/dedup/content, authority rules, "second reschedule refused before any booking", static guards:
no write to `TIMETABLE`/`TIMETABLE_SLOT`, migration has no DROP/ALTER/DELETE and no CHECK-vs-SET NULL FK, no DISTINCT+ORDER BY). `py_compile` of backend + tests and `node --check` of the JS also passed.

**NOT run there — needs your MySQL 8 (do not treat as verified until you have):**
* `db/006_displaced_classes.sql` itself, the new SQL in `displacement.py`, and `tests/test_displacement_integration.py` (15 test methods covering the 16 requirements: approval/cancel-that-date-only,
  requester booked, displacement notification content, Pending rescheduling visibility, reschedule success, occupied/section-conflict rejection, unrelated CR + VIEWER + anonymous rejected,
  no double reschedule, daily schedule + role scoping, weekly timetable snapshot-equal, future date untouched, history/audit intact, concurrent reschedule, concurrent approvals, rollback on failed approval, ADMIN-routed flow).
* The full existing suite after the change, and the browser UI (`daily.js`) against the real backend.

## Dismiss / row dialog / cancel (added with migration 007)
Apply once:  `mysql -u <privileged_user> -p roomwise < db/007_displacement_dismissed.sql`   (re-running is a no-op)
Offline:     `python -m pytest tests/test_dismiss_unit.py tests/test_daily_ui.py -v`   (the UI file needs `playwright` + Chromium, otherwise it skips)
MySQL:       `RW_INTEGRATION=1 python -m pytest tests/test_displacement_dismiss_integration.py -v`
Whole suite: `RW_INTEGRATION=1 python -m pytest tests -v`
