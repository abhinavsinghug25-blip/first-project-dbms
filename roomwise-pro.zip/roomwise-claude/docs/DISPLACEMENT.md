# Daily schedule, displacement & rescheduling

## Workflow
1. CR *R* requests a room/slot held by section *H*. Routing is unchanged: the request goes to *H*'s CR (or ADMIN if none) — `REQUEST_RECEIVED` notification, once.
2. *H*'s CR (or ADMIN; never the requester, never an unrelated CR/VIEWER) approves. **One transaction**: re-validate → cancel *H*'s dated class
   (`CLASS_SCHEDULE.status='Cancelled'` + `CLASS_CANCELLATION` row, as before) → book *R*'s class → insert `CLASS_DISPLACEMENT(status='Awaiting')`
   → audit → notify. Any failure rolls everything back and the request stays *Pending*.
3. Notifications: `CLASS_DISPLACED` to every active CR of *H* (date, time, room, requesting section + subject, what to do next);
   `REQUEST_APPROVED` to the requester (room/date/time); `CLASS_CANCELLED` to ADMINs (unchanged).
4. *H*'s CR opens **Pending rescheduling**, presses *Find available rooms* (exact same date/time; same validation as booking), picks a room → **reschedule**:
   lock displacement row → lock room/teacher/section → re-validate → insert a *new* dated class → mark displacement `Rescheduled` → audit → `CLASS_RESCHEDULED` to *H*'s CR(s).
5. **Daily schedule** shows each date's real state: *Scheduled*, *Cancelled*, *Displaced* (awaiting / rescheduled — the original row stays visible), *Rescheduled* (the new booking), plus notes for extra classes and room changes.

## Why one new table
`CLASS_SCHEDULE.status` only has Scheduled/Cancelled/Completed and `CLASS_CANCELLATION.reason` is free text, so neither can say *"cancelled **because displaced**, and rescheduled to X"*.
`CLASS_DISPLACEMENT` records exactly that and nothing else; "displaced" is **derived** (Cancelled + a displacement row), so there is no second status to drift out of sync.
Unique keys on `original_class_id`, `request_id`, `displacing_class_id`, `rescheduled_class_id` make double displacement/double rescheduling impossible even under a race;
a CHECK ties `status` to `rescheduled_class_id`/`rescheduled_at`. All FKs are `RESTRICT` (history can't be orphaned by a delete).

## The recurring timetable is never written
Nothing in the new code references `TIMETABLE`/`TIMETABLE_SLOT` except the pre-existing read-only materialisation. Every operation is an INSERT/UPDATE on date-specific
`CLASS_SCHEDULE` / `CLASS_DISPLACEMENT`. Guarded by a static test and a before/after table comparison in the integration tests.

## Known limits (deliberate)
* Only **extra-class approvals** create displacements. A room-change approval that releases a class still just cancels it (as before) — say if you want it to enter the same workflow.
* If a *rescheduled* class is later cancelled, it is an ordinary cancellation; the displacement stays `Rescheduled`.
* Backfill in 006 covers only **future** classes already released by approved requests; no notifications are sent for them.
* Frontend time model is unchanged (whole-hour grid in the weekly view); the Daily schedule shows exact start/end times.

## Dismissing (migration `db/007_displacement_dismissed.sql`)
`Awaiting → Dismissed` means "this class will not be rescheduled". It adds `dismissed_by_user_id` / `dismissed_at` and replaces the state CHECK with `ck_disp_state_v2`
(Dismissed ⇒ no rescheduled class, `dismissed_at` set). The original class, its cancellation, the displacement row, the approved request and all audit rows stay.
Only ADMIN or the section's actively assigned CR may dismiss (VIEWER / unrelated CR ⇒ 403). Dismissed items drop out of the Awaiting list and the pending badge,
show under the **Dismissed** tab, and the Daily Schedule still shows the class as *Displaced - dismissed*.
Cancelling from the Daily Schedule row dialog reuses `POST /api/classes/{id}/cancel`; a cancelled class never counts as occupying a room (see `available_rooms`).
