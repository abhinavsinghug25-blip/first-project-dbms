# Design notes

## 1. Audit of the supplied frontend (Stage 1)
Single-page app, one `index.html`, `assets/js/app.js` (1,047 lines). Pages: Overview, Room directory, Timetable,
Class scheduling, Requests, Teachers, Academic setup (Excel/OCR import), Reports. All state lived in
`localStorage` (`roomwise.*` keys); 189 weekly entries for rooms 5215–5222 were hard-coded. No backend, no auth,
no capacity/feature data. **Changes made:** hard-coded events and every localStorage read/write removed from
`app.js`; everything else (markup, CSS, render functions) kept. New files add the API bridge and role-aware UI.

## 2. Schema decisions
* `EXTRA_CLASS_REQUEST` was **extended** (not duplicated by a new `ROOM_USE_REQUEST`): requester, requester section,
  requested room/date/time, target class/section, recipient role/user, decision fields, `resulting_class_id`.
  `CLASS_SCHEDULE` stays the only booking truth.
* `CLASS_CANCELLATION.cancelled_by_user_id → USER_ACCOUNT` (not TEACHER). Cancelled classes are never deleted.
* `SECTION_CR_ASSIGNMENT` has a generated `active_key` so a user can hold at most one *active* assignment per section
  while revoked rows stay as history. Only ADMIN writes it; first assignment promotes VIEWER→CR, last revoke demotes.
* `USER_ACCOUNT.role` is `ENUM('ADMIN','CR','VIEWER') DEFAULT 'VIEWER'`.
* `TIMETABLE` (draft → published → archived) is the weekly template; `CLASS_SCHEDULE` rows are materialised from
  **published** timetables only (documented publication policy).

## 3. Scheduling engine (`backend/app/scheduling.py`)
Rules and the half-open overlap predicate `start1 < end2 AND start2 < end1` live in one module used by bookings,
approvals, room changes, ADMIN edits and publication. Cancelled classes never block.
**Concurrency:** each write transaction runs at READ COMMITTED and first takes `SELECT … FOR UPDATE` on the ROOM(s),
TEACHER and SECTION rows in a fixed global order (rooms by id → teacher → section). Concurrent attempts touching the same
room/teacher/section serialise; the second re-reads committed data and fails with 409 — nothing is overwritten.
Lock-wait timeouts/deadlocks return 409 "busy" with nothing committed.
**Limitations:** single MySQL node; default 50 s lock wait; an approval may replace only the *one* class recorded as the
request's target (a request spanning several classes is rejected at creation); extra classes booked for a date that has
not been materialised yet trigger materialisation first, but a timetable published *later* is not re-checked against
pre-existing extra classes.

## 4. Routing & authority
Request → the class holding the slot (or the cancelled class that freed it) → its section's active CR (excluding the
requester) → otherwise ADMIN. Decision-time checks: still pending (else 409), not the requester (even ADMIN), caller is
ADMIN or an *actively assigned* CR of the target section and the request was routed to CR, then conflicts re-validated.
ADMIN approving a CR-routed request is recorded as `admin_override` in the audit log.

## 5. Security summary
Argon2id; random 256-bit session token stored only as SHA-256; HttpOnly + SameSite=Lax cookie (+Secure via env);
per-session CSRF header + Origin check; pydantic `extra=forbid` (mass assignment); parameterised SQL everywhere;
generic login error + throttle; least-privilege DB account (no DDL, append-only `AUDIT_LOG`); no SQL console;
UI rendering escapes all data. Throttle is in-process (per worker).
