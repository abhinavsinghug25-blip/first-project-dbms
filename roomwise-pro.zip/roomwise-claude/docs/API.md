# API reference
Base: same origin as the frontend. JSON in/out. Errors: `{"error":{"code","message","details"}}`
(401 unauthenticated, 403 forbidden, 404, 409 conflict/stale/clash, 422 validation, 429 login throttle).
All endpoints except `/api/auth/signup|login` need the `rw_session` cookie; every non-GET also needs header
`X-CSRF-Token` (returned by login/me). Identity and role always come from the session, never from the body
(bodies reject unknown fields, so `role`, `user_id`, `requester` etc. cannot be injected).
Interactive docs: `/api/docs`.

| Method & path | Who | Notes |
|---|---|---|
| POST `/api/auth/signup` | public | always creates **VIEWER** |
| POST `/api/auth/login` · `/logout` · GET `/me` | public / any | cookie + csrf token; 5 failures ⇒ 15 min throttle |
| GET `/api/rooms` `?q&status&min_capacity&feature_id&room_type&limit&offset` | any | |
| GET `/api/rooms/{id}?date=` | any | features + that day's classes |
| GET `/api/availability?date&start&end&min_capacity&feature_id` | any | derived from active `CLASS_SCHEDULE`; lists the cancelled class that released a room |
| GET `/api/events?week_start=` | any | Mon–Fri active classes (+ cancelled) in UI shape |
| GET `/api/classes?date_from&date_to&section_id&room_id&teacher_id&status` | any | ≤120 days |
| GET `/api/my/timetable?date_from&date_to` | CR (assigned sections) / ADMIN (all) | VIEWER ⇒ 403 |
| GET `/api/timetable/published` | any | weekly template |
| GET `/api/sections` `/subjects` `/teachers` `/branches` `/features` | any | `my_section_ids` tells the UI a CR's scope |
| GET `/api/dashboard` | any | DB-computed counts, room hours, inbox size |
| POST `/api/classes` | ADMIN | direct booking of an extra class |
| PUT `/api/classes/{id}` | ADMIN | correction; re-validated; audited |
| POST `/api/classes/{id}/cancel` `{reason}` | CR (own section) / ADMIN | class kept as *Cancelled*; room auto-released; notifies |
| POST `/api/requests` | CR (own section) / ADMIN | extra-class room/slot request; routed to the owning CR or ADMIN |
| POST `/api/requests/room-change` | CR (own class) / ADMIN | move a dated class to another room |
| GET `/api/requests?status=` | CR (own + routed to them) / ADMIN (all) | `can_decide` computed server-side |
| POST `/api/requests/{extra\|room-change}/{id}/decision` `{decision, reason}` | eligible CR / ADMIN | not the requester; reason required on reject |
| POST `/api/requests/{kind}/{id}/withdraw` | requester / ADMIN | |
| GET `/api/notifications` · POST `/{id}/read` · `/read-all` | any | |
| `/api/admin/*` rooms (POST/PATCH, PUT features), features, branches, sections, subjects, teachers, teacher-availability, timetables (+slots, publish, archive), materialize, cr-assignments, users, audit | **ADMIN only** | validated DML only; no SQL console, no DDL |
| GET `/api/daily-schedule?date=YYYY-MM-DD[&section_id=]` | any | date-specific schedule with derived `status` = scheduled / cancelled / displaced / rescheduled, `note`, counts. ADMIN + VIEWER: all sections; CR: assigned sections + the class that displaced theirs |
| GET `/api/displaced-classes?status=Awaiting\|Rescheduled\|Dismissed` | CR (own sections) / ADMIN (all) | "Pending rescheduling": original subject/section/date/time/room, reason, requesting section, status. VIEWER ⇒ 403 |
| GET `/api/displaced-classes/{id}/available-rooms` | CR (that section) / ADMIN | rooms free for the **exact same date/time** (full conflict re-check); 409 once rescheduled |
| POST `/api/displaced-classes/{id}/reschedule` `{room_id}` | CR (that section) / ADMIN | atomic: lock → re-validate room/teacher/section → new dated class → mark `Rescheduled` → audit → notify. Occupied room ⇒ 409; second attempt ⇒ 409; VIEWER/unrelated CR ⇒ 403 |
| POST `/api/displaced-classes/{id}/dismiss` | CR (that section, actively assigned) / ADMIN | `Awaiting → Dismissed`; records who/when (`dismissed_by_user_id`, `dismissed_at`), audit `CLASS_DISPLACEMENT_DISMISSED`, notifies the section's CRs + admins (not the actor). Nothing is deleted. Already rescheduled/dismissed ⇒ 409; VIEWER/unrelated CR ⇒ 403. A dismissed item can no longer be rescheduled (409) and is excluded from `status=Awaiting` and the pending badge |
