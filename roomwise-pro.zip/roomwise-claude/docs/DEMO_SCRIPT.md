# 5–10 minute lab demonstration
Prep: setup steps 1–5 in README (use `seed-demo`; note the printed password). Two browsers/profiles help.

**A. Database (≈3 min)** — open `db/004_demo_queries.sql` in MySQL:
1. ER diagram (`docs/ER_DIAGRAM.png`): 15 baseline tables + 4 extensions.
2. DDL: show `001_schema.sql`; run `005_migration_example.sql` (ALTER/INDEX via controlled migration).
3. DML + joins + GROUP BY/HAVING + subquery + availability query.
4. Constraint failures (duplicate room, capacity 0, bad time range, role 'TEACHER', FK) — each must error.
5. Transaction: UPDATE → ROLLBACK → verify; COMMIT.
6. DCL: `SHOW GRANTS FOR 'roomwise_app'@'%'`; as that user `DROP TABLE ROOM;` and `DELETE FROM AUDIT_LOG;` are denied.
7. The three integrity queries return 0 rows.

**B. Application (≈6 min)**
1. **VIEWER** (`viewer1`): timetable, room directory, availability visible; no Requests/Schedule/Admin; direct API write → 403.
2. **CR** (`cr_cs5`): Timetable → *Cancel a class* → reason required → class vanishes, room free (Schedule page shows it Available).
   Try a class of another section via API → 403.
3. **CR→CR request** (`cr_cs3`): Class scheduling → pick that date/time → *Request this room* → routed to cs5's CR.
   `cr_cs3` cannot approve it (no buttons; API 403).
4. **Decision** (`cr_cs5`): bell shows notification → Requests → Approve → new class appears; old one remains *Cancelled*.
   Re-approve same request → 409 stale. Show a Rejected one with its reason.
5. **ADMIN** (`demo_admin`): Administration → CR assignments (assign/revoke), Rooms (edit status → room becomes unavailable),
   Audit log (every step above is listed with actor and time); edit a class in Timetable → clash is refused with explanation.
6. **Concurrency**: two admin tabs approve two requests for the same free room together — one succeeds, one gets 409.
