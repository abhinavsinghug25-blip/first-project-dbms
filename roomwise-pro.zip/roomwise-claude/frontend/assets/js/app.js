let rooms=[];
let teachers=[];
let requests=[];
let timetableEvents=[];
let preferredScheduleRoom="";
const requestStorageKey="roomwise.roomRequests.v1";
requests=(window.RW_BOOT&&window.RW_BOOT.requests)||[];
const $=(q,root=document)=>root.querySelector(q), $$=(q,root=document)=>[...root.querySelectorAll(q)];
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function toast(message,type="success"){const el=document.createElement("div");el.className=`toast${type==="error"?" toast-error":""}`;el.innerHTML=`<span>${type==="error"?"!":"✓"}</span>${esc(message)}`;$("#toastRegion").append(el);setTimeout(()=>el.remove(),3400)}
function go(page){$$(".page").forEach(p=>p.classList.toggle("active",p.id===`page-${page}`));$$(".nav-item").forEach(n=>n.classList.toggle("active",n.dataset.page===page));const active=$(`.nav-item[data-page="${page}"]`);$("#breadcrumbCurrent").textContent=active?active.textContent.trim():({dashboard:"Overview",rooms:"Room directory",timetable:"Timetable",schedule:"Class scheduling",requests:"Requests",teachers:"Teachers",academics:"Academic setup",reports:"Reports & analytics"}[page]||page);$("#sidebar").classList.remove("open");window.scrollTo({top:0,behavior:"smooth"})}
$$(".nav-item").forEach(b=>b.addEventListener("click",()=>go(b.dataset.page)));$$("[data-go]").forEach(b=>b.addEventListener("click",()=>go(b.dataset.go)));
$("#mobileMenu").addEventListener("click",()=>$("#sidebar").classList.toggle("open"));
$("#notificationBtn")?.addEventListener("click",()=>go("requests"));
$("#helpBtn").addEventListener("click",()=>openDialog("About this timetable",`<p class="dialog-message">This site is built from the four weekday timetable images for rooms 5215, 5216, 5221, and 5222. Room capacity, features, and email addresses were not provided in those images.</p><div class="dialog-actions"><button class="btn btn-primary" data-dialog-close>Close</button></div>`));
$("#dismissNote")?.addEventListener("click",()=>$(".prototype-note")?.remove());
function getEventSemester(event){
 return String(`${event.section||""} ${event.meta||""}`).match(/\bsem(?:ester)?\s*([357])\b/i)?.[1]||"";
}
function getRoomSlotStatus(room,day,start){
 const classes=timetableEvents.filter(event=>event.room===room&&event.day===day&&start>=event.start&&start<event.start+event.duration);
 if(!classes.length)return {status:"available",classes};
 if(classes.some(event=>getEventSemester(event)!=="7"))return {status:"busy",classes};
 return {status:"maybe",classes};
}
function getRoomScheduleState(room,event){
 const classes=timetableEvents.filter(existing=>existing.room===room&&existing.day===event.day&&intervalsOverlap(event.start,event.start+event.duration,existing.start,existing.start+existing.duration));
 if(!classes.length)return {status:"available",classes};
 return {status:classes.every(existing=>getEventSemester(existing)==="7")?"maybe":"busy",classes};
}
function getTeacherScheduleConflict(event){
 const teacher=String(event.teacher||"").trim().toLowerCase();
 if(!teacher)return null;
 return timetableEvents.find(existing=>String(existing.teacher||"").trim().toLowerCase()===teacher&&existing.day===event.day&&intervalsOverlap(event.start,event.start+event.duration,existing.start,existing.start+existing.duration))||null;
}
function countRoomSlotStatuses(room){
 const counts={available:0,busy:0,maybe:0};
 const day=(new Date().getDay()+6)%7;
 if(day>4)return {...counts,total:0};
 for(let start=8;start<18;start++)counts[getRoomSlotStatus(room,day,start).status]++;
 counts.total=10;
 return counts;
}
function getNextSchedulableSlot(now=new Date()){
 const day=(now.getDay()+6)%7,minuteOfDay=now.getHours()*60+now.getMinutes();
 if(day>4||minuteOfDay>=18*60)return null;
 const start=Math.max(8,Math.ceil(minuteOfDay/60));
 return start<18?{day,start,date:now}:null;
}
function prepareRoomSchedule(room){
 const slot=getNextSchedulableSlot();
 if(!slot||getRoomSlotStatus(room,slot.day,slot.start).status!=="available"){
  toast("That room is no longer available for the next whole-hour slot. Please check the room list again.","error");
  renderRooms();return;
 }
 const date=slot.date,start=String(slot.start).padStart(2,"0");
 $('#scheduleForm [name="date"]').value=`${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,"0")}-${String(date.getDate()).padStart(2,"0")}`;
 $('#scheduleForm [name="start"]').value=`${start}:00`;
 $('#scheduleForm [name="end"]').value=`${String(slot.start+1).padStart(2,"0")}:00`;
 preferredScheduleRoom=room;
 resetAvailableRooms();go("schedule");
 toast(`Room ${room} is available at ${start}:00. Add the class details to continue.`);
}
function openRoomRequest(room,day,start,scheduleEvent=null){
 const candidate=scheduleEvent||{day,start,duration:1,title:"",meta:"",teacher:"",section:"",branch:"",courseCode:"",kind:"blue-event",source:"local"},state=getRoomScheduleState(room,candidate);
 if(state.status==="available"){toast("This room is available for that time. Use Schedule instead of sending a request.","error");return}
 const now=new Date(),dateText=scheduleEvent?.date||`${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,"0")}-${String(now.getDate()).padStart(2,"0")}`;
 openDialog(`Request Room ${room}`,`<form id="roomRequestForm" class="dialog-content"><p class="dialog-message">This room has a ${state.status==="maybe"?"tentative Semester 7 class":"scheduled class"} during the requested time. Send a request for review; acceptance replaces the conflicting room schedule.</p><label class="field">Class / subject<input name="subject" required value="${esc(scheduleEvent?.courseCode||"")}" placeholder="Class name or course code"></label><label class="field">Requested by<input name="requestedBy" placeholder="Your name (optional)"></label><label class="field">Note<textarea name="note" rows="3" placeholder="Add context for the request (optional)"></textarea></label><div class="dialog-list"><div><strong>Slot:</strong> ${esc(scheduleDays[day])}, ${String(start).padStart(2,"0")}:00–${String(start+candidate.duration).padStart(2,"0")}:00</div><div><strong>Room:</strong> ${esc(room)}</div>${scheduleEvent?`<div><strong>Teacher:</strong> ${esc(candidate.teacher||"Unspecified")}</div><div><strong>Section:</strong> ${esc(candidate.section||"Unspecified")}</div>`:""}</div><div class="dialog-actions"><button type="button" class="btn btn-secondary" data-dialog-close>Cancel</button><button type="submit" class="btn btn-primary">Send request</button></div></form>`);
 $("#roomRequestForm").addEventListener("submit",submitEvent=>{
  submitEvent.preventDefault();
  const form=new FormData(submitEvent.currentTarget),subject=String(form.get("subject")).trim();
  if(scheduleEvent&&getRoomScheduleState(room,scheduleEvent).status==="available"){toast("This room is now available. Recheck the room list and schedule it directly.","error");$("#appDialog").close();return}
  const proposed={...candidate,room,date:dateText,title:[candidate.branch,subject].filter(Boolean).join(" · ")||subject,courseCode:subject,meta:[candidate.teacher,candidate.section].filter(Boolean).join(" · ")};
  const request={id:`request-${Date.now()}-${Math.random().toString(36).slice(2)}`,request:subject,requestedBy:String(form.get("requestedBy")).trim()||"Guest",date:dateText,day,start,room,status:"Pending",note:String(form.get("note")).trim(),createdAt:new Date().toISOString(),type:"Extra class",scheduleEvent:proposed};
  requests.unshift(request);
  try{localStorage.setItem(requestStorageKey,JSON.stringify(requests))}
  catch(error){requests.shift();console.error("Unable to save room request.",error);toast("The request could not be saved in this browser.","error");return}
  $("#appDialog").close();renderRequests();renderDashboard();renderReports();
  toast(`Request for Room ${room} saved for review in this browser.`);
 });
}
function renderRooms(){
 const today=new Date(),todayIndex=(today.getDay()+6)%7,todayName=today.toLocaleDateString(undefined,{weekday:"long"}),todayLabel=todayIndex<5?todayName:"No weekday schedule";
 const todaysEvents=timetableEvents.filter(event=>event.day===todayIndex);
 const currentAvailability=getAvailabilitySnapshot(today);
 const search=($("#roomSearch")?.value||"").trim().toLowerCase();
 const list=rooms.filter(room=>room.number.toLowerCase().includes(search));
 const roomTable=$("#roomsTable").closest("table");
 roomTable.querySelector("thead").innerHTML=`<tr><th>ROOM</th><th>${todayIndex<5?`CLASSES · ${todayName.toUpperCase()}`:"CLASSES · TODAY"}</th><th class="room-slot-summary-heading">AVAILABLE / BUSY / MAYBE</th><th>CURRENT STATUS</th><th>NEXT SLOT & ACTION</th></tr>`;
 const roomAddButton=$("#addRoomBtn");if(roomAddButton)roomAddButton.hidden=true;
 roomTable.closest(".directory-panel").querySelectorAll(".filter-bar select").forEach(select=>select.remove());
 const roomStats=$(".compact-stats");
 if(roomStats){const slots=rooms.reduce((sum,room)=>{const count=countRoomSlotStatuses(room.number);return {available:sum.available+count.available,busy:sum.busy+count.busy,maybe:sum.maybe+count.maybe,total:sum.total+count.total}},{available:0,busy:0,maybe:0,total:0}),branches=new Set(todaysEvents.map(event=>event.branch).filter(Boolean));roomStats.innerHTML=`<article class="stat-card"><div class="stat-top"><span class="stat-label">Rooms in provided schedules</span><span class="stat-icon blue">▤</span></div><div class="stat-value">${rooms.length}</div><div class="stat-foot">No other room inventory supplied</div></article><article class="stat-card"><div class="stat-top"><span class="stat-label">Scheduled entries · ${esc(todayLabel)}</span><span class="stat-icon violet">▣</span></div><div class="stat-value">${todaysEvents.length}</div><div class="stat-foot">From today's schedule</div></article><article class="stat-card"><div class="stat-top"><span class="stat-label">Today's slot status</span><span class="stat-icon green">✓</span></div><div class="stat-value">${slots.total?`${slots.available} available`:"—"}</div><div class="stat-foot">${slots.total?`${slots.busy} busy · ${slots.maybe} maybe · 08:00–18:00`:"No weekday timetable today"}</div></article><article class="stat-card"><div class="stat-top"><span class="stat-label">Today's branches</span><span class="stat-icon amber">⌂</span></div><div class="stat-value">${branches.size}</div><div class="stat-foot">${esc(todayLabel)} schedule</div></article>`}
 $("#roomsTable").innerHTML=list.map(room=>{
  const events=todaysEvents.filter(event=>event.room===room.number);
  const statusCounts=countRoomSlotStatuses(room.number),nextSlot=getNextSchedulableSlot(),status=nextSlot?getRoomSlotStatus(room.number,nextSlot.day,nextSlot.start):{status:"unknown"};
  const currentStatus=currentAvailability.known?(currentAvailability.availableRooms.includes(room.number)?"available":currentAvailability.occupiedRooms.includes(room.number)?"occupied":"maybe"):"unknown";
  const currentStatusLabel={available:"Available",occupied:"Occupied",maybe:"Maybe",unknown:"Unknown"}[currentStatus];
  const statusLabel=status.status==="unknown"?"Not available now":`${scheduleDays[nextSlot.day].slice(0,3)} ${String(nextSlot.start).padStart(2,"0")}:00 · ${status.status==="maybe"?"Maybe":status.status==="busy"?"Busy":"Available"}`;
  const action=status.status==="available"?`<button class="btn btn-primary room-slot-action" data-schedule-now="${esc(room.number)}">Schedule now</button>`:status.status==="maybe"?`<button class="btn btn-secondary room-slot-action" data-send-room-request="${esc(room.number)}" data-request-day="${nextSlot.day}" data-request-start="${nextSlot.start}">Send request</button>`:`<button class="row-more" data-room-detail="${esc(room.number)}">View schedule</button>`;
  const slotCounts=statusCounts.total?`<span class="slot-available">${statusCounts.available} available</span><span class="slot-busy">${statusCounts.busy} busy</span><span class="slot-maybe">${statusCounts.maybe} maybe</span>`:`<span class="state-unknown">No weekday schedule today</span>`;
  return `<tr><td><div class="room-title"><span class="room-icon">▤</span><div><strong>${esc(room.number)}</strong><small>${esc(todayLabel)}</small></div></div></td><td>${events.length} classes</td><td><div class="room-slot-counts">${slotCounts}</div></td><td><span class="current-room-status status-${currentStatus}"><i></i>${currentStatusLabel}</span></td><td><div class="room-next-slot"><span class="availability-state state-${status.status}">${esc(statusLabel)}</span>${action}</div></td></tr>`;
 }).join("")||`<tr><td colspan="5" class="empty-row">No rooms from the supplied timetable match this search.</td></tr>`;
 $("#roomCount").textContent=`Showing ${list.length} of ${rooms.length} rooms found in the timetable images`;
 $$("[data-room-detail]").forEach(button=>button.addEventListener("click",()=>{const room=button.dataset.roomDetail;$("#roomFilter").value=room;renderTimetable();go("timetable")}));
 $$("[data-schedule-now]").forEach(button=>button.addEventListener("click",()=>prepareRoomSchedule(button.dataset.scheduleNow)));
 $$("[data-send-room-request]").forEach(button=>button.addEventListener("click",()=>openRoomRequest(button.dataset.sendRoomRequest,Number(button.dataset.requestDay),Number(button.dataset.requestStart))));
}
$("#roomSearch")?.addEventListener("input",renderRooms);
function renderRequests(filter="All"){
 const visible=requests.filter(request=>filter==="All"||request.type===filter);
 $("#requestsTable").innerHTML=visible.length?visible.map(request=>`<tr><td><strong>${esc(request.request)}</strong><small class="request-subtext">${esc(request.type||"Room request")}${request.note?` · ${esc(request.note)}`:""}</small></td><td>${esc(request.requestedBy||"Guest")}</td><td>${esc(request.date||"")} · ${esc(scheduleDays[request.day]||"")} · ${String(request.start).padStart(2,"0")}:00</td><td>${esc(request.room)}</td><td><span class="pill ${request.status==="Pending"?"pill-pending":"pill-scheduled"}">${esc(request.status||"Pending")}</span></td><td>${request.status==="Pending"?`<div class="request-actions"><button type="button" class="btn btn-primary request-action" data-accept-request="${esc(request.id)}">Accept & replace</button><button type="button" class="btn btn-secondary request-action" data-reject-request="${esc(request.id)}">Decline</button></div>`:`<span class="request-local-note">${esc(request.status)} · saved locally</span>`}</td></tr>`).join(""):`<tr><td colspan="6" class="empty-row">No room requests have been sent yet.</td></tr>`;
 const heading=$("#page-requests .page-heading p");if(heading)heading.textContent=requests.length?`${requests.length} room request${requests.length===1?"":"s"} saved in this browser for review.`:"Send a request for a Maybe slot; requests are saved locally in this browser.";
 $$("[data-request-filter]").forEach(button=>{const count=button.querySelector("span");if(count)count.remove()});
 $$("[data-accept-request]").forEach(button=>button.addEventListener("click",()=>acceptRoomRequest(button.dataset.acceptRequest)));
 $$("[data-reject-request]").forEach(button=>button.addEventListener("click",()=>rejectRoomRequest(button.dataset.rejectRequest)));
}
function saveRoomRequests(){
 try{localStorage.setItem(requestStorageKey,JSON.stringify(requests));return true}
 catch(error){console.error("Unable to save room request updates.",error);toast("The request update could not be saved in this browser.","error");return false}
}
function acceptRoomRequest(id){
 const request=requests.find(item=>item.id===id);
 if(!request||request.status!=="Pending"){toast("This request is no longer pending.","error");return}
 const event=request.scheduleEvent;
 if(!event||!event.room||!Number.isInteger(event.day)||!Number.isInteger(event.start)||!Number.isInteger(event.duration)||event.duration<1){toast("This request has no valid class details to schedule.","error");return}
 const overlapping=timetableEvents.filter(existing=>existing.day===event.day&&intervalsOverlap(event.start,event.start+event.duration,existing.start,existing.start+existing.duration));
 const replaced=overlapping.filter(existing=>existing.room===request.room);
 const outsideRoomConflict=overlapping.find(existing=>existing.room!==request.room&&((event.teacher&&existing.teacher&&event.teacher.toLowerCase()===existing.teacher.toLowerCase())||(event.section&&existing.section&&event.section.toLowerCase()===existing.section.toLowerCase())));
 if(outsideRoomConflict){toast(`Cannot accept: ${event.teacher||event.section} conflicts with ${outsideRoomConflict.title} in Room ${outsideRoomConflict.room}.`,"error");return}
 const approved={...event,id:`accepted-${request.id}`,room:request.room,source:"local",createdAt:new Date().toISOString(),replacedEvents:replaced};
 const previousTimetable=timetableEvents.map(item=>({...item})),previousAdded=addedScheduleEvents.slice(),previousStatus=request.status;
 const nextTimetable=[...timetableEvents.filter(item=>!replaced.some(old=>old.id===item.id)),approved];
 addedScheduleEvents.push(approved);
 if(!persistManagedTimetable(nextTimetable)){addedScheduleEvents=previousAdded;return}
 request.status="Accepted";request.approvedAt=new Date().toISOString();
 if(!saveRoomRequests()){
  request.status=previousStatus;delete request.approvedAt;addedScheduleEvents=previousAdded;
  persistManagedTimetable(previousTimetable);
  return;
 }
 renderRequests();renderDashboard();renderRooms();
 toast(`Accepted. ${event.title||request.request} replaced the conflicting class in Room ${request.room}.`);
}
function rejectRoomRequest(id){
 const request=requests.find(item=>item.id===id);
 if(!request||request.status!=="Pending"){toast("This request is no longer pending.","error");return}
 request.status="Declined";
 if(!saveRoomRequests()){request.status="Pending";return}
 renderRequests();renderDashboard();renderReports();toast("Room request declined.");
}
$$("[data-request-filter]").forEach(b=>b.addEventListener("click",()=>{$$("[data-request-filter]").forEach(x=>x.classList.toggle("active",x===b));renderRequests(b.dataset.requestFilter)}));
function renderTeachers(){const q=($("#teacherSearch")?.value||"").toLowerCase(),branch=$("#teacherBranch")?.value||"";const table=$("#teachersTable").closest("table");table.querySelector("thead").innerHTML="<tr><th>TEACHER</th><th>BRANCHES</th><th>COURSE CODES</th><th>SCHEDULED CLASSES</th></tr>";const addButton=$("#addTeacherBtn");if(addButton)addButton.hidden=true;const list=teachers.filter(t=>(`${t.name} ${t.branches.join(" ")} ${t.courses.join(" ")}`.toLowerCase().includes(q))&&(!branch||t.branches.includes(branch)));$("#teachersTable").innerHTML=list.map(t=>`<tr><td><div class="teacher-person"><span class="teacher-avatar t1">${esc(t.name.split(/\s+/).map(x=>x[0]).join("").slice(0,2).toUpperCase())}</span><div><strong>${esc(t.name)}</strong><small>From provided timetable</small></div></div></td><td>${esc(t.branches.join(", ")||"Unspecified")}</td><td>${esc(t.courses.join(", ")||"Unspecified")}</td><td>${t.events.length} scheduled classes</td></tr>`).join("")||`<tr><td colspan="4" class="empty-row">No teachers found in the supplied timetable.</td></tr>`}
function getAvailabilitySnapshot(now=new Date()){
 const day=(now.getDay()+6)%7,minuteOfDay=now.getHours()*60+now.getMinutes();
 const availableRooms=[],occupiedRooms=[],maybeRooms=[];
 if(day>4)return {known:false,reason:"No weekday schedule provided",availableRooms,occupiedRooms,maybeRooms};
 if(minuteOfDay<480||minuteOfDay>=1080)return {known:false,reason:"Outside the listed 08:00–18:00 schedule",availableRooms,occupiedRooms,maybeRooms};
 rooms.forEach(room=>{
  const classes=timetableEvents.filter(event=>event.room===room.number&&event.day===day&&minuteOfDay>=event.start*60&&minuteOfDay<(event.start+event.duration)*60);
  const status=classes.length?(classes.some(event=>getEventSemester(event)!=="7")?"busy":"maybe"):"available";
  ({available:availableRooms,busy:occupiedRooms,maybe:maybeRooms})[status].push(room.number);
 });
 return {known:true,reason:"",availableRooms,occupiedRooms,maybeRooms};
}
function getGreeting(hour){
 if(hour>=5&&hour<12)return "Good morning";
 if(hour>=12&&hour<17)return "Good afternoon";
 if(hour>=17&&hour<21)return "Good evening";
 return "Good night";
}
function renderDashboard(){
 const now=new Date(),availability=getAvailabilitySnapshot(now);
 const totalSlots=rooms.length*50,occupied=new Set(timetableEvents.flatMap(event=>Array.from({length:event.duration},(_,index)=>`${event.room}:${event.day}:${event.start+index}`))).size;
 const openSlots=Math.max(0,totalSlots-occupied),utilization=totalSlots?Math.round(occupied/totalSlots*100):0;
 const stats=$(".stats-grid");
 if(stats)stats.innerHTML=`<article class="stat-card"><div class="stat-top"><span class="stat-label">Rooms in provided schedules</span><span class="stat-icon blue">▤</span></div><div class="stat-value">${rooms.length}</div><div class="stat-foot">Rooms with timetable entries</div></article><article class="stat-card"><div class="stat-top"><span class="stat-label">Busy now</span><span class="stat-icon violet">▣</span></div><div class="stat-value">${availability.known?availability.occupiedRooms.length:"—"}</div><div class="stat-foot">${availability.known?"Confirmed scheduled classes":availability.reason}</div></article><article class="stat-card"><div class="stat-top"><span class="stat-label">Available now</span><span class="stat-icon green">✓</span></div><div class="stat-value">${availability.known?availability.availableRooms.length:"—"}</div><div class="stat-foot">${availability.known?"No listed class in this slot":availability.reason}</div></article><article class="stat-card"><div class="stat-top"><span class="stat-label">Scheduled utilization</span><span class="stat-icon amber">◷</span></div><div class="stat-value">${utilization}%</div><div class="stat-foot">Across all listed weekday slots</div></article>`;
  const day=(now.getDay()+6)%7,dayName=now.toLocaleDateString(undefined,{weekday:"long"}),dateLabel=now.toLocaleDateString(undefined,{weekday:"long",year:"numeric",month:"long",day:"numeric"}),timeLabel=now.toLocaleTimeString(undefined,{hour:"numeric",minute:"2-digit"});
  const classes=timetableEvents.filter(event=>event.day===day).sort((a,b)=>a.start-b.start);
  $("#todayClasses").innerHTML=classes.map(event=>`<tr><td><div class="class-name"><span class="subject-color color-blue"></span><div><strong>${esc(event.title)}</strong><small>${esc(event.section)}</small></div></div></td><td>${String(event.start).padStart(2,"0")}:00 – ${String(event.start+event.duration).padStart(2,"0")}:00</td><td><span class="room-pill">${esc(event.room)}</span></td><td>${esc(event.teacher||event.meta.split(" · Sem")[0])}</td><td><span class="pill pill-scheduled">${event.source==="image"?"From image":"Added here"}</span></td></tr>`).join("")||`<tr><td colspan="5" class="empty-row">No ${day>4?"weekday":dayName} classes are listed.</td></tr>`;
  const requestPreviewHeading=$(".requests-panel .panel-heading p");if(requestPreviewHeading)requestPreviewHeading.textContent=requests.length?`${requests.length} request${requests.length===1?"":"s"} saved locally`:"Requests are saved locally in this browser";
  $("#requestPreview").innerHTML=requests.length?requests.slice(0,4).map(request=>`<div class="request-preview-item"><strong>${esc(request.request)}</strong><span>Room ${esc(request.room)} · ${esc(scheduleDays[request.day])} ${String(request.start).padStart(2,"0")}:00 · ${esc(request.status)}</span></div>`).join(""):`<div class="empty-row">No room requests have been sent yet.</div>`;
  const occupancy=$("#occupancyChart");
  if(occupancy)occupancy.innerHTML=`<div class="grid-lines"><i></i><i></i><i></i><i></i><i></i></div><div class="chart-columns">${Array.from({length:10},(_,i)=>{const hour=i+8,count=new Set(timetableEvents.filter(event=>hour>=event.start&&hour<event.start+event.duration).map(event=>`${event.day}:${event.room}`)).size;return `<div class="chart-column"><div class="bar-group"><i class="bar bar-occupied" style="height:${rooms.length?Math.round(count/(rooms.length*5)*100):0}%"></i></div><small>${hour>12?hour-12:hour}${hour>=12?" PM":" AM"}</small></div>`}).join("")}</div>`;
   const heading=$(".page-heading");
   const userName = window.RW_BOOT?.user?.full_name || "User";
if(heading){heading.querySelector(".eyebrow").textContent=`${dateLabel} · ${timeLabel}`;heading.querySelector("h1").innerHTML=`${getGreeting(now.getHours())}, ${esc(userName)} <span>✦</span>`;heading.querySelector("p").textContent="Room availability and today's classes, based on the provided timetable."}
   const occupancyPanel=$(".occupancy-panel");
   if(occupancyPanel){occupancyPanel.querySelector(".panel-heading h2").textContent="Room availability now";occupancyPanel.querySelector(".panel-heading p").textContent=`Local schedule check · updated at ${timeLabel}`;const summary=occupancyPanel.querySelector(".occupancy-summary");if(summary)summary.innerHTML=availability.known?`<div><span class="legend-dot available"></span> Available <strong>${availability.availableRooms.length}</strong></div><div><span class="legend-dot occupied"></span> Busy <strong>${availability.occupiedRooms.length}</strong></div><div><span class="legend-dot maybe"></span> Maybe <strong>${availability.maybeRooms.length}</strong></div><div class="available-room-list">${availability.availableRooms.map(number=>`<button type="button" class="room-pill" data-now-room="${esc(number)}">${esc(number)}</button>`).join("")||"No rooms available right now"}</div>`:`<div>${esc(availability.reason)} · availability is not inferred outside the listed weekday hours.</div>`}
   const classesHeading=$(".classes-panel .panel-heading h2");if(classesHeading)classesHeading.textContent=`${dayName}'s classes`;
   const classesCaption=$(".classes-panel .panel-heading p");if(classesCaption)classesCaption.textContent=`${dateLabel} · Current weekday schedule`;
   $$("[data-now-room]").forEach(button=>button.addEventListener("click",()=>{$("#roomFilter").value=button.dataset.nowRoom;renderTimetable();go("timetable")}));
   $("#occupancyPeriod")?.remove();
   const quickPanel=$(".quick-panel");
   if(quickPanel){const actions=quickPanel.querySelectorAll(".quick-action");if(actions[0])actions[0].querySelector("small").textContent="Use the provided schedule data";if(actions[1])actions[1].querySelector("small").textContent="See available, busy, and maybe slots";if(actions[2])actions[2].querySelector("small").textContent="Review locally saved room requests"}
   const note=$(".prototype-note");if(note)note.innerHTML="<span>ⓘ</span><div><strong>Source information</strong><p>Room, teacher, branch, section, and time details come from the supplied timetable images. Semester 7 slots are marked Maybe and require a request. Requests are stored only in this browser; no request is sent to a server.</p></div>";
  }
function renderReports(){
 const totalSlots=rooms.length*50,occupiedByDay=Array.from({length:5},(_,day)=>new Set(timetableEvents.filter(event=>event.day===day).flatMap(event=>Array.from({length:event.duration},(_,index)=>`${event.room}:${event.start+index}`))).size);
 const average=totalSlots?Math.round(occupiedByDay.reduce((sum,count)=>sum+count,0)/(rooms.length*50)*100):0;
 const cards=$$("#page-reports .stats-grid .stat-value");
 if(cards.length===4){
  cards[0].textContent=`${average}%`;cards[1].textContent=timetableEvents.length;
  const conflicts=timetableEvents.reduce((count,event,index)=>count+timetableEvents.slice(index+1).filter(other=>event.day===other.day&&intervalsOverlap(event.start,event.start+event.duration,other.start,other.start+other.duration)&&(event.room===other.room||(event.teacher&&event.teacher===other.teacher)||event.section===other.section)).length,0);
  cards[2].textContent=conflicts;cards[3].textContent=requests.length;
  cards[0].closest(".stat-card").querySelector(".stat-foot").textContent="From listed hourly room slots";
  cards[1].closest(".stat-card").querySelector(".stat-foot").textContent="Across the supplied weekday schedules";
  cards[2].closest(".stat-card").querySelector(".stat-foot").textContent="Potential overlaps; verify against source";
  cards[3].closest(".stat-card").querySelector(".stat-foot").textContent="Room requests saved in this browser";
 }
 const bars=$$(".report-bars > div");
 bars.forEach((bar,index)=>{const percent=rooms.length?Math.round(occupiedByDay[index]/(rooms.length*10)*100):0;bar.querySelector("i b").style.width=`${percent}%`;bar.querySelector("strong").textContent=`${percent}%`});
 const reportPanel=$(".report-panel");if(reportPanel){reportPanel.querySelector(".panel-heading p").textContent="Calculated from the room and weekday entries";reportPanel.querySelector(".pill").textContent="Provided schedules"}
}
$("#teacherSearch").addEventListener("input",renderTeachers);$("#teacherBranch").addEventListener("change",renderTeachers);
// Timetable data now comes from the backend (CLASS_SCHEDULE in MySQL) via window.RW_BOOT; nothing is hard-coded here.
const sourceTimetableEvents=((window.RW_BOOT&&window.RW_BOOT.events)||[]).map(e=>({...e}));
const scheduleDays=["Monday","Tuesday","Wednesday","Thursday","Friday"];
const scheduleStorageKey="roomwise.scheduleAdditions.v1";
const managedTimetableStorageKey="roomwise.managedTimetable.v1";
let addedScheduleEvents=[];
let managedTimetableEvents=null;
function rebuildScheduleIndexes(){
 timetableEvents=(managedTimetableEvents||[...sourceTimetableEvents,...addedScheduleEvents]).map((event,index)=>({...event,id:event.id||`schedule-${event.room}-${event.day}-${event.start}-${index}`}));
 rooms=[...new Set(timetableEvents.map(event=>event.room))].sort((a,b)=>a.localeCompare(b,undefined,{numeric:true})).map((number,index)=>({id:index+1,number}));
 window.rooms=rooms;
 const indexed=new Map();
 timetableEvents.forEach(event=>{
  const teacher=event.teacher||event.meta.split(" · Sem")[0].trim();
  if(!teacher||/unavailable|not legible/i.test(teacher))return;
  const key=teacher.toLowerCase();
  if(!indexed.has(key))indexed.set(key,{name:teacher,branches:new Set(),courses:new Set(),events:[]});
  const record=indexed.get(key);
  record.branches.add(event.branch);record.courses.add(event.courseCode);record.events.push(event);
 });
 teachers=[...indexed.values()].map(record=>({...record,branches:[...record.branches].sort(),courses:[...record.courses].sort()})).sort((a,b)=>a.name.localeCompare(b.name));
}
rebuildScheduleIndexes();
function renderTimetable(updateEditor=true){
 const days=["MON","TUE","WED","THU","FRI"];
 const events=timetableInlineEdit?timetableInlineDraft:timetableEvents,type=$("#timetableTypeFilter").value,selectedRoom=$("#roomFilter").value,selectedSection=$("#sectionFilter").value,facultyFilter=$("#facultyFilter");
 const selectedFaculty=facultyFilter.value;
 const roomOptions=[...new Set(events.map(event=>event.room))],roomFilter=$("#roomFilter");
 const sectionOptions=[...new Set([...events.map(event=>event.section),...academicRecords.sections.filter(item=>item.status.toLowerCase()!=="inactive").map(academicLabel)])];
 const facultyOptions=[...new Set(events.map(event=>event.teacher).filter(Boolean))].sort((a,b)=>a.localeCompare(b));
 roomFilter.innerHTML=`<option value="">All rooms</option>${roomOptions.map(room=>`<option value="${esc(room)}">Room ${esc(room)}</option>`).join("")}`;
 roomFilter.value=selectedRoom===""||roomOptions.includes(selectedRoom)?selectedRoom:(roomOptions.includes("5222")?"5222":"");
 $("#sectionFilter").innerHTML=`<option>All sections</option>${sectionOptions.map(section=>`<option>${esc(section)}</option>`).join("")}`;
 $("#sectionFilter").value=sectionOptions.includes(selectedSection)?selectedSection:"All sections";
 facultyFilter.innerHTML=`<option value="">All faculty</option>${facultyOptions.map(name=>`<option value="${esc(name)}">${esc(name)}</option>`).join("")}`;
 facultyFilter.value=facultyOptions.includes(selectedFaculty)?selectedFaculty:"";
 roomFilter.hidden=type!=="room";facultyFilter.hidden=type!=="faculty";$("#sectionFilter").hidden=type!=="class";
 const selectedRoomLabel=type==="room"?(roomFilter.value?`Room ${roomFilter.value}`:"All rooms"):type==="faculty"?(facultyFilter.value||"All faculty"):selectedSection;
 const currentVersion=academicRecords.timetables.find(item=>item.version===$("#timetableVersionFilter").value);
 $("#timetableSubtitle").textContent=[currentVersion&&[currentVersion.semester&&`Semester ${currentVersion.semester}`,currentVersion.academicYear,currentVersion.status].filter(Boolean).join(" · "),selectedRoomLabel,currentVersion?"":"From supplied images"].filter(Boolean).join(" · ");
 $("#weekGrid").innerHTML=`<div class="week-head" style="grid-row:1;grid-column:1"></div>${days.map((day,index)=>`<div class="week-head ${index===0?"today":""}" style="grid-row:1;grid-column:${index+2}">${day}</div>`).join("")}${Array.from({length:10},(_,index)=>{const hour=index+8,label=new Date(2026,0,1,hour).toLocaleTimeString("en-US",{hour:"2-digit",minute:"2-digit"}),row=index+2;return `<div class="time-label" style="grid-row:${row};grid-column:1">${label}</div>${days.map((day,dayIndex)=>`<div class="day-column" data-day="${dayIndex}" data-hour="${hour}" style="grid-row:${row};grid-column:${dayIndex+2}"></div>`).join("")}`}).join("")}`;
 const visibleEvents=events.filter(event=>{
  if(type==="room")return !roomFilter.value||event.room===roomFilter.value;
  if(type==="faculty")return !facultyFilter.value||event.teacher===facultyFilter.value;
  return selectedSection==="All sections"||event.section===selectedSection;
 });
 visibleEvents.forEach(event=>{
  const column=$(`.day-column[data-day="${event.day}"][data-hour="${event.start}"]`);if(!column)return;
  const duration=event.duration||1;
  const semester=getEventSemester(event);
  const item=document.createElement("div");item.className=`event ${event.kind}${semester?` semester-${semester}`:""}${semester==="7"?" event-maybe":""}`;item.style.top="3px";item.style.height=`${Math.max(56,duration*82-8)}px`;
  item.innerHTML=`<strong>${esc(event.title)}${semester==="7"?` <span class="event-status-maybe">Maybe</span>`:""}</strong><small>${esc(event.meta)}<br>Room ${esc(event.room)}</small>`;
  item.addEventListener("click",()=>{if($("#timetableEditToggle").getAttribute("aria-pressed")==="true")return;openDialog(event.title,`<div class="dialog-content"><p class="dialog-message">${event.source==="image"?"Transcribed from a provided room timetable image.":"Added in this browser."}</p><div class="dialog-list"><div><strong>Day:</strong> ${days[event.day]}</div><div><strong>Time:</strong> ${String(event.start).padStart(2,"0")}:00 – ${String(event.start+duration).padStart(2,"0")}:00</div><div><strong>Room:</strong> ${esc(event.room)}</div><div><strong>Details:</strong> ${esc(event.meta)}</div><div><strong>Section:</strong> ${esc(event.section)}</div></div><div class="dialog-actions"><button class="btn btn-primary" data-dialog-close>Close</button></div></div>`)});
  column.append(item);
 });
 const dayView=$("#viewFilter").value==="Day view";
 if(dayView){$("#weekGrid").style.gridTemplateColumns="68px minmax(120px,1fr)";$$(".day-column").forEach(column=>column.style.display=Number(column.dataset.day)===0?"block":"none");$$(".week-head").forEach((heading,index)=>{if(index>1)heading.style.display="none"})}
 else{$("#weekGrid").style.gridTemplateColumns="";$$(".day-column,.week-head").forEach(element=>element.style.display="")}
 if(timetableInlineEdit&&updateEditor)renderTimetableInlineEditor();
}
let timetableInlineEdit=false,timetableInlineDraft=[];
const inlineFields=["day","start","duration","room","branch","section","courseCode","teacher"];
function setTimetableEditMode(enabled){
 timetableInlineEdit=enabled;
 $("#timetableEditToggle").setAttribute("aria-pressed",String(enabled));
 $("#timetableEditToggle").textContent=enabled?"Editing enabled":"Enable edit";
 $("#timetableEditSave").hidden=!enabled;$("#timetableEditCancel").hidden=!enabled;
 $("#timetableInlineEditor").hidden=!enabled;
 if(enabled){timetableInlineDraft=timetableEvents.map(event=>({...event}));renderTimetableInlineEditor()}
 else $("#timetableInlineEditor").innerHTML="";
 renderTimetable();
}
function renderTimetableInlineEditor(){
 const target=$("#timetableInlineEditor"),type=$("#timetableTypeFilter").value,selectedRoom=$("#roomFilter").value,selectedFaculty=$("#facultyFilter").value,selectedSection=$("#sectionFilter").value;
 const records=timetableInlineDraft.filter(event=>type==="room"?(!selectedRoom||event.room===selectedRoom):type==="faculty"?(!selectedFaculty||event.teacher===selectedFaculty):(selectedSection==="All sections"||event.section===selectedSection));
 target.innerHTML=`<div class="timetable-inline-heading"><div><strong>Edit timetable rows</strong><p>Changes below are a draft until you choose Save edits.</p></div><button type="button" class="btn btn-secondary" id="inlineAddRow">＋ Add row</button></div><div class="academic-table-wrap timetable-edit-table-wrap"><table class="academic-record-table timetable-edit-table"><thead><tr>${inlineFields.map(field=>`<th>${timetableFieldLabels[field]}</th>`).join("")}<th>Remove</th></tr></thead><tbody>${records.map(event=>`<tr data-inline-row="${esc(event.id)}">${inlineFields.map(field=>`<td>${timetableDraftInput(field,field==="start"?event.start:field==="duration"?event.duration:event[field],event.id).replaceAll("data-event-id","data-inline-event-id")}</td>`).join("")}<td><button type="button" class="timetable-delete-row" data-inline-delete="${esc(event.id)}">Delete</button></td></tr>`).join("")}</tbody></table>${records.length?"":`<div class="academic-empty">No rows match the selected timetable filters.</div>`}</div>`;
 $$("[data-inline-event-id]",target).forEach(input=>input.addEventListener("change",()=>{const id=input.dataset.inlineEventId;const event=timetableInlineDraft.find(item=>item.id===id);if(!event)return;const field=input.dataset.field,value=input.value;event[field]=field==="day"||field==="duration"?Number(value):field==="start"?Number(value.slice(0,2)):value;refreshEventDisplayFields(event);renderTimetable(false)}));
 $$("[data-inline-delete]",target).forEach(button=>button.addEventListener("click",()=>{timetableInlineDraft=timetableInlineDraft.filter(event=>event.id!==button.dataset.inlineDelete);renderTimetableInlineEditor();renderTimetable()}));
 $("#inlineAddRow").addEventListener("click",()=>{const event={id:`inline-${Date.now()}-${Math.random().toString(36).slice(2)}`,day:0,start:8,duration:1,room:selectedRoom||"",branch:"",section:"",courseCode:"",title:"",teacher:"",meta:"",kind:"blue-event",source:"managed"};timetableInlineDraft.push(event);renderTimetableInlineEditor();renderTimetable()});
}
function refreshEventDisplayFields(event){
 event.title=[event.branch,event.courseCode].filter(Boolean).join(" · ")||event.courseCode||event.title;
 const semester=String(event.semester||event.meta.match(/\bsem(?:ester)?\s*(\d+)\b/i)?.[1]||"");
 event.semester=semester;
 event.meta=[event.teacher,semester&&`Sem ${semester}`].filter(Boolean).join(" · ");
}
function collectInlineDraft(){
 $$("#timetableInlineEditor [data-inline-row]").forEach(row=>{
  const event=timetableInlineDraft.find(item=>item.id===row.dataset.inlineRow);if(!event)return;
  $$("[data-inline-event-id]",row).forEach(input=>{const field=input.dataset.field,value=input.value;event[field]=field==="day"||field==="duration"?Number(value):field==="start"?Number(value.slice(0,2)):value});
  refreshEventDisplayFields(event);
 });
}
function validateTimetableRows(rows,changedIds){
 const changed=rows.filter(event=>changedIds.has(event.id)),invalid=[];
 changed.forEach(event=>{
  if(!Number.isInteger(event.day)||event.day<0||event.day>4)invalid.push(`${event.title||"A row"} needs a weekday.`);
  if(!event.room?.trim())invalid.push(`${event.title||"A row"} needs a room number.`);
  if(!event.courseCode?.trim()&&!event.title?.trim())invalid.push(`A row in Room ${event.room||"?"} needs a subject or class.`);
  if(!Number.isInteger(event.start)||event.start<8||event.start>=18||!Number.isInteger(event.duration)||event.duration<1||event.start+event.duration>18)invalid.push(`${event.title||"A row"} has an invalid time slot.`);
 });
 const keys=new Set();
 rows.forEach(event=>{
  const key=`${event.room}|${event.day}|${event.start}|${event.duration}`;
  if(keys.has(key)&&changedIds.has(event.id))invalid.push(`Duplicate room/time entry: Room ${event.room}, ${scheduleDays[event.day]} at ${String(event.start).padStart(2,"0")}:00.`);
  keys.add(key);
 });
 changed.forEach(event=>rows.forEach(other=>{
  if(event.id===other.id||event.day!==other.day||!intervalsOverlap(event.start,event.start+event.duration,other.start,other.start+other.duration))return;
  const same=event.room===other.room||(event.teacher&&other.teacher&&event.teacher.toLowerCase()===other.teacher.toLowerCase())||(event.section&&other.section&&event.section.toLowerCase()===other.section.toLowerCase());
  if(same)invalid.push(`Scheduling conflict: ${event.title||"Edited class"} overlaps ${other.title||"another class"} in Room ${other.room} on ${scheduleDays[event.day]}.`);
 }));
 return [...new Set(invalid)];
}
function persistManagedTimetable(rows){
 const next=rows.map(event=>({...event,source:event.source||"managed"}));
 try{localStorage.setItem(managedTimetableStorageKey,JSON.stringify(next))}
 catch(error){console.error("Unable to save managed timetable data.",error);toast("Timetable changes could not be saved in this browser.","error");return false}
 managedTimetableEvents=next;
 const currentById=new Map(managedTimetableEvents.map(event=>[event.id,event]));
 addedScheduleEvents=addedScheduleEvents.filter(event=>currentById.has(event.id)).map(event=>({...event,...currentById.get(event.id)}));
 saveScheduleAdditions();rebuildScheduleIndexes();updateAcademicSurfaces();renderRooms();renderDashboard();renderReports();renderScheduleActivity();return true;
}
function saveInlineTimetable(){
 collectInlineDraft();
 const before=new Map(timetableEvents.map(event=>[event.id,JSON.stringify(event)])),after=new Map(timetableInlineDraft.map(event=>[event.id,JSON.stringify(event)]));
 const changedIds=new Set([...after].filter(([id,value])=>before.get(id)!==value).map(([id])=>id));
 const errors=validateTimetableRows(timetableInlineDraft,changedIds);
 if(errors.length){toast(errors[0],"error");return}
 persistManagedTimetable(timetableInlineDraft);setTimetableEditMode(false);toast("Timetable edits saved and synchronized across the site.");
}
$("#roomFilter").addEventListener("change",renderTimetable);$("#sectionFilter").addEventListener("change",renderTimetable);$("#facultyFilter").addEventListener("change",renderTimetable);$("#timetableTypeFilter").addEventListener("change",renderTimetable);$("#viewFilter").addEventListener("change",renderTimetable);
$("#timetableEditToggle").addEventListener("click",()=>setTimetableEditMode(!timetableInlineEdit));
$("#timetableEditSave").addEventListener("click",saveInlineTimetable);
$("#timetableEditCancel").addEventListener("click",()=>setTimetableEditMode(false));
function updateWeekLabel(){$("#weekLabel").textContent="Monday – Friday";renderTimetable()}$("#weekLabel").textContent="Monday – Friday";$("#weekPrev").hidden=true;$("#weekNext").hidden=true;
function openDialog(title,html){const d=$("#appDialog");d.classList.remove("academic-dialog");$("#dialogTitle").textContent=title;$("#dialogBody").innerHTML=html;if(!d.open)d.showModal();$$("[data-dialog-close]",d).forEach(b=>b.addEventListener("click",()=>d.close()));$$("[data-book-room]",d).forEach(b=>b.addEventListener("click",()=>{const r=rooms.find(x=>x.id===Number(b.dataset.bookRoom));d.close();go("schedule");toast(`Room ${r.number} selected as a suggestion. Complete the class form to continue.`)}));}
$("#dialogClose").addEventListener("click",()=>$("#appDialog").close());
const academicSchemas={
 branches:{title:"Branches",headers:["Code","Name","Status"],required:["code","name"],fields:[["Code","code"],["Name","name"],["Status","status"]],aliases:{code:["code","branchcode","departmentcode"],name:["name","branch","department","branchname"],status:["status","active"]}},
 sections:{title:"Sections",headers:["Branch","Section","Semester","Academic year","Status"],required:["branch","section"],fields:[["Branch","branch"],["Section","section"],["Semester","semester"],["Academic year","academicYear"],["Status","status"]],aliases:{branch:["branch","branchcode","branchname","department","departmentname"],section:["section","sectionname","sectioncode"],semester:["semester","term"],academicYear:["academicyear","year"],status:["status","active"]}},
 subjects:{title:"Subjects",headers:["Code","Name","Type","Branch","Semester"],required:["code","name"],fields:[["Code","code"],["Name","name"],["Type","type"],["Branch","branch"],["Semester","semester"]],aliases:{code:["code","subjectcode"],name:["name","subject","subjectname"],type:["type","subjecttype"],branch:["branch","branchcode","department"],semester:["semester","term"]}},
 features:{title:"Room features",headers:["Name","Description","Status"],required:["name"],fields:[["Name","name"],["Description","description"],["Status","status"]],aliases:{name:["name","feature","featurename"],description:["description","details"],status:["status","active"]}},
 timetables:{title:"Timetable versions",headers:["Version","Academic year","Semester","Status","Published on"],required:["version"],fields:[["Version","version"],["Academic year","academicYear"],["Semester","semester"],["Status","status"],["Published on","publishedOn"]],aliases:{version:["version","name","versionname"],academicYear:["academicyear","year"],semester:["semester","term"],status:["status"],publishedOn:["publishedon","date"]}},
};
const academicStorageKey="roomwise.academicRecords.v1";
let academicRecords={branches:[],sections:[],subjects:[],features:[],timetables:[]};
function saveAcademicRecords(){}
function academicLabel(section){return `${section.branch} · ${/^section\s/i.test(section.section)?section.section:`Section ${section.section}`}`}
function updateAcademicSurfaces(){
 const branchFilter=$("#teacherBranch"),selectedBranch=branchFilter.value;
 const importedBranches=academicRecords.branches.filter(item=>item.status.toLowerCase()!=="inactive").map(item=>item.code);
 const branchOptions=[...new Set([...teachers.flatMap(item=>item.branches),...importedBranches])].sort();
 branchFilter.innerHTML=`<option value="">All branches</option>${branchOptions.map(code=>`<option value="${esc(code)}">${esc(code)}</option>`).join("")}`;
 if(branchOptions.includes(selectedBranch))branchFilter.value=selectedBranch;
 const importedSections=academicRecords.sections.filter(item=>item.status.toLowerCase()!=="inactive");
 const sectionSelect=$('#scheduleForm [name="section"]'), timetableSection=$("#sectionFilter"), previousSection=sectionSelect.value;
 const sections=[...new Set([...timetableEvents.map(event=>event.section),...importedSections.map(academicLabel)])].sort();
 sectionSelect.innerHTML=`<option value="">Select section</option>${sections.map(section=>`<option>${esc(section)}</option>`).join("")}`;
 timetableSection.innerHTML=`<option>All sections</option>${sections.map(section=>`<option>${esc(section)}</option>`).join("")}`;
 if(sections.includes(previousSection))sectionSelect.value=previousSection;
 const teacherSelect=$('#scheduleForm [name="teacher"]'),previousTeacher=teacherSelect.value;
 teacherSelect.innerHTML=`<option value="">Select teacher</option>${teachers.map(teacher=>`<option>${esc(teacher.name)}</option>`).join("")}`;
 if(teachers.some(teacher=>teacher.name===previousTeacher))teacherSelect.value=previousTeacher;
 const subjectOptions=[...academicRecords.subjects.filter(item=>item.status?.toLowerCase()!=="inactive").map(item=>({value:item.name,label:[item.code,item.type].filter(Boolean).join(" · ")})),...timetableEvents.map(event=>({value:event.courseCode,label:event.title}))];
 $("#subjectOptions").innerHTML=[...new Map(subjectOptions.filter(item=>item.value&&item.value!=="Unspecified").map(item=>[item.value,item])).values()].map(item=>`<option value="${esc(item.value)}">${esc(item.label)}</option>`).join("");
 const features=academicRecords.features.filter(item=>item.status.toLowerCase()!=="inactive");
 const featureOptions=$("#featureOptions");if(featureOptions&&features.length)featureOptions.innerHTML=features.map(item=>`<label><input type="checkbox" name="features" value="${esc(item.name)}"> ${esc(item.name)}</label>`).join("");
 const versions=academicRecords.timetables,versionFilter=$("#timetableVersionFilter"),selectedVersion=versionFilter.value;
 versionFilter.innerHTML=versions.length?versions.map(item=>`<option value="${esc(item.version)}">${esc(item.version)}</option>`).join(""):`<option value="image-schedules">Image schedules</option>`;
 if(versions.some(item=>item.version===selectedVersion))versionFilter.value=selectedVersion;
 const counts={branches:academicRecords.branches.length,sections:academicRecords.sections.length,subjects:academicRecords.subjects.length,features:academicRecords.features.length,timetables:versions.length};
 Object.entries(counts).forEach(([key,count])=>{const node=$(`#academicCount${key[0].toUpperCase()+key.slice(1)}`);if(node)node.textContent=count?`${count} imported`: ""});
 const roomCount=new Set(timetableEvents.map(event=>event.room).filter(Boolean)).size;
 const facultyCount=new Set(timetableEvents.map(event=>event.teacher).filter(Boolean)).size;
 const classCount=new Set(timetableEvents.map(event=>event.section).filter(Boolean)).size;
 $("#adminCountRoom").textContent=`${roomCount} rooms`;
 $("#adminCountFaculty").textContent=`${facultyCount} faculty`;
 $("#adminCountClass").textContent=`${classCount} classes`;
 renderTimetable();renderTeachers();
}
function academicTable(key){
 const schema=academicSchemas[key],records=academicRecords[key];
 if(!records.length)return `<div class="academic-empty">No ${schema.title.toLowerCase()} imported yet. Download the template to see the expected columns.</div>`;
 return `<div class="academic-table-wrap"><table class="academic-record-table"><thead><tr>${schema.fields.map(([label])=>`<th>${esc(label)}</th>`).join("")}</tr></thead><tbody>${records.slice(0,100).map(record=>`<tr>${schema.fields.map(([,field])=>`<td>${esc(record[field]||"—")}</td>`).join("")}</tr>`).join("")}</tbody></table>${records.length>100?`<p class="academic-empty">Showing the first 100 of ${records.length} records.</p>`:""}</div>`;
}
function downloadAcademicTemplate(key){
 const schema=academicSchemas[key],csv=`${schema.headers.map(value=>`"${value}"`).join(",")}\r\n`;
 const blob=new Blob(["\ufeff",csv],{type:"text/csv;charset=utf-8"}),url=URL.createObjectURL(blob),anchor=document.createElement("a");
 anchor.href=url;anchor.download=`${key}-template.csv`;anchor.click();URL.revokeObjectURL(url);
}
function normalizeHeader(value){return String(value).toLowerCase().replace(/[^a-z0-9]/g,"")}
function parseCsvRows(text){
 const rows=[];let row=[],value="",quoted=false;
 for(let i=0;i<text.length;i++){
  const char=text[i],next=text[i+1];
  if(char==='"'&&quoted&&next==='"'){value+='"';i++}
  else if(char==='"')quoted=!quoted;
  else if(char===","&&!quoted){row.push(value.trim());value=""}
  else if((char==="\n"||char==="\r")&&!quoted){
   if(char==="\r"&&next==="\n")i++;
   row.push(value.trim());if(row.some(cell=>cell!==""))rows.push(row);row=[];value="";
  }else value+=char;
 }
 row.push(value.trim());if(row.some(cell=>cell!==""))rows.push(row);
 if(rows.length<2)return [];
 const headers=rows.shift().map(header=>header.replace(/^\uFEFF/,""));
 return rows.map(cells=>Object.fromEntries(headers.map((header,index)=>[header,cells[index]||""])));
}
function parseAcademicWorkbook(file,key){
 const isCsv=/\.csv$/i.test(file.name);
 if(!isCsv&&!window.XLSX){toast("Excel import needs an internet connection to load the spreadsheet reader. You can download the CSV template and import that instead.","error");return}
 const reader=new FileReader(),schema=academicSchemas[key];
 reader.onerror=()=>toast("The selected spreadsheet could not be read.","error");
 reader.onload=()=>{
  try{
   let rows;
   if(isCsv)rows=parseCsvRows(reader.result);
   else{
    const workbook=XLSX.read(reader.result,{type:"array"}),sheet=workbook.Sheets[workbook.SheetNames[0]];
    if(!sheet)throw new Error("The workbook has no worksheet.");
    rows=XLSX.utils.sheet_to_json(sheet,{defval:"",raw:false});
   }
   if(!rows.length)throw new Error("The first worksheet has no data rows.");
   if(rows.length>5000)throw new Error("A maximum of 5,000 records can be imported at once.");
   const sourceHeaders=Object.keys(rows[0]),mapped={};
   Object.entries(schema.aliases).forEach(([field,aliases])=>{mapped[field]=sourceHeaders.find(header=>aliases.includes(normalizeHeader(header)))});
   const missing=schema.required.filter(field=>!mapped[field]);
   if(missing.length)throw new Error(`Missing required column${missing.length===1?"":"s"}: ${missing.map(field=>schema.fields.find(([,keyName])=>keyName===field)[0]).join(", ")}.`);
   const imported=rows.map((row,index)=>{
    const record={};
    schema.fields.forEach(([,field])=>{record[field]=mapped[field]?String(row[mapped[field]]??"").trim():""});
    schema.required.forEach(field=>{if(!record[field])throw new Error(`Row ${index+2} is missing ${schema.fields.find(([,keyName])=>keyName===field)[0]}.`)});
    if(key==="timetables"&&record.status)record.status=/^published$/i.test(record.status)?"Published":/^archived$/i.test(record.status)?"Archived":"Draft";
    else if(record.status)record.status=/^(inactive|disabled|archived)$/i.test(record.status)?"Inactive":"Active";
    if(key==="branches"&& !record.status)record.status="Active";
    if(key==="sections"&& !record.status)record.status="Active";
    if(key==="features"&& !record.status)record.status="Active";
    if(key==="timetables"&&!record.status)record.status="Draft";
    return record;
   });
   const uniqueField={branches:"code",sections:"section",subjects:"code",features:"name",timetables:"version"}[key];
   const seen=new Set();
   imported.forEach((record,index)=>{
    const identity=key==="sections"?`${record.branch}|${record.section}`:record[uniqueField];
    const normalized=identity.toLowerCase();
    if(seen.has(normalized))throw new Error(`Duplicate ${schema.title.toLowerCase()} value on row ${index+2}: ${identity}.`);
    seen.add(normalized);
   });
   academicRecords[key]=imported;saveAcademicRecords();updateAcademicSurfaces();openAcademicDialog(key);
   toast(`${imported.length} ${schema.title.toLowerCase()} imported and connected to the site.`);
  }catch(error){console.error(`Unable to import ${schema.title.toLowerCase()}.`,error);toast(error.message||"The spreadsheet could not be imported.","error")}
 };
 if(isCsv)reader.readAsText(file);else reader.readAsArrayBuffer(file);
}
function openAcademicDialog(key){
 const schema=academicSchemas[key];
 openDialog(schema.title,`<div class="dialog-content academic-manager">
  <p class="dialog-message">Upload a workbook to replace the current ${schema.title.toLowerCase()} list. Use the template to match the expected columns. The first worksheet is imported.</p>
  <div class="academic-import-actions"><label class="btn btn-primary academic-upload">Choose Excel / CSV file<input type="file" id="academicFile" accept=".xlsx,.xls,.csv" hidden></label><button type="button" class="btn btn-secondary" id="academicTemplate">Download template</button></div>
  <p class="academic-file-hint">Accepted: .xlsx, .xls, .csv · maximum 5,000 rows · saved in this browser</p>
  <div class="academic-records-heading"><strong>Current imported records</strong><span>${academicRecords[key].length} records</span></div>
  ${academicTable(key)}
  <div class="dialog-actions"><button class="btn btn-secondary" data-dialog-close>Close</button></div>
 </div>`);
 $("#appDialog").classList.add("academic-dialog");
 $("#academicTemplate").addEventListener("click",()=>downloadAcademicTemplate(key));
 $("#academicFile").addEventListener("change",event=>{
  const file=event.target.files[0];if(!file)return;
  if(file.size>10*1024*1024){toast("Please choose a spreadsheet smaller than 10 MB.","error");event.target.value="";return}
  if(!/\.(xlsx|xls|csv)$/i.test(file.name)){toast("Choose an .xlsx, .xls, or .csv spreadsheet.","error");event.target.value="";return}
  parseAcademicWorkbook(file,key);
 });
}
$$("[data-academic]").forEach(button=>button.addEventListener("click",()=>openAcademicDialog(({Branches:"branches",Sections:"sections",Subjects:"subjects","Room features":"features",Timetables:"timetables"})[button.dataset.academic])));
const timetableAdminLabels={room:"Room Time Table",faculty:"Faculty Time Table",class:"Class Time Table (Branch & Section)"};
const timetableFieldLabels={day:"Day",start:"Start",duration:"Hours",room:"Room",branch:"Branch",section:"Section",courseCode:"Subject / code",teacher:"Faculty"};
let timetableAdminDraft=null,timetableAdminTouched=new Set(),timetableAdminBaseline=new Map(),timetableAdminMode="room";
function openTimetableAdmin(mode){
 timetableAdminMode=mode;timetableAdminDraft=timetableEvents.map(event=>({...event}));timetableAdminTouched=new Set();
 timetableAdminBaseline=new Map(timetableAdminDraft.map(event=>[event.id,JSON.stringify([event.day,event.start,event.duration,event.room,event.branch,event.section,event.courseCode,event.teacher])]));
 const title=timetableAdminLabels[mode],typeSpecific=mode==="room"?"Review room numbers, occupied slots, weekdays, and times.":mode==="faculty"?"Review faculty names, assigned classes, subjects, weekdays, and times.":"Review subjects, faculty, rooms, days, and time slots across branches and sections.";
 openDialog(title,`<div class="dialog-content academic-manager timetable-admin-manager">
  <p class="dialog-message">${typeSpecific} Upload Excel or a timetable image to extract rows. Imports are appended by default; choose replace only when you intend to replace all current schedule records.</p>
  <div class="academic-import-actions"><label class="btn btn-primary academic-upload">Upload Excel or image<input type="file" id="timetableAdminFile" accept=".xlsx,.xls,.png,.jpg,.jpeg" hidden></label><button type="button" class="btn btn-secondary" id="timetableAddRow">＋ Add row</button><button type="button" class="btn btn-secondary" id="timetableExport">Export Excel</button></div>
  <label class="timetable-replace-option"><input id="timetableReplaceExisting" type="checkbox"> Replace all existing schedule records with the reviewed import</label>
  <p class="academic-file-hint" id="timetableImportStatus">Records are shared across the room, faculty, class, dashboard, and reports views. Changes are saved in this browser.</p>
  <div id="timetableDraftTable"></div>
  <div class="dialog-actions"><button class="btn btn-secondary" data-dialog-close>Cancel</button><button type="button" class="btn btn-primary" id="timetableSave">Save changes</button></div>
 </div>`);
 $("#appDialog").classList.add("academic-dialog");
 renderTimetableAdminDraft();
 $("#timetableAdminFile").addEventListener("change",event=>{const file=event.target.files[0];if(file)handleTimetableUpload(file);event.target.value=""});
 $("#timetableAddRow").addEventListener("click",addTimetableDraftRow);
 $("#timetableSave").addEventListener("click",saveTimetableDraft);
 $("#timetableExport").addEventListener("click",exportTimetableDraft);
}
$$("[data-timetable-admin]").forEach(button=>button.addEventListener("click",()=>openTimetableAdmin(button.dataset.timetableAdmin)));
function timetableDraftInput(field,value,eventId){
 if(field==="day")return `<select data-field="${field}" data-event-id="${esc(eventId)}">${scheduleDays.map((day,index)=>`<option value="${index}" ${Number(value)===index?"selected":""}>${day}</option>`).join("")}</select>`;
 if(field==="start")return `<input data-field="${field}" data-event-id="${esc(eventId)}" type="time" step="3600" min="08:00" max="17:00" value="${String(Number(value)||8).padStart(2,"0")}:00">`;
 if(field==="duration")return `<input data-field="${field}" data-event-id="${esc(eventId)}" type="number" min="1" max="10" value="${Number(value)||1}">`;
 return `<input data-field="${field}" data-event-id="${esc(eventId)}" value="${esc(value||"")}" aria-label="${timetableFieldLabels[field]}">`;
}
function renderTimetableAdminDraft(){
 const target=$("#timetableDraftTable"),fields=timetableAdminMode==="room"?["room","day","start","duration","branch","section","courseCode","teacher"]:timetableAdminMode==="faculty"?["teacher","courseCode","branch","section","room","day","start","duration"]:["branch","section","courseCode","teacher","room","day","start","duration"];
 const records=timetableAdminDraft||[];
 target.innerHTML=`<div class="academic-records-heading"><strong>${esc(timetableAdminLabels[timetableAdminMode])}</strong><span>${records.length} records · editable preview</span></div>${records.length?`<div class="academic-table-wrap timetable-edit-table-wrap"><table class="academic-record-table timetable-edit-table"><thead><tr>${fields.map(field=>`<th>${timetableFieldLabels[field]}</th>`).join("")}<th>Remove</th></tr></thead><tbody>${records.map(event=>`<tr data-admin-row="${esc(event.id)}">${fields.map(field=>`<td>${timetableDraftInput(field,field==="start"?event.start:field==="duration"?event.duration:event[field],event.id)}</td>`).join("")}<td><button type="button" class="timetable-delete-row" data-delete-row="${esc(event.id)}" aria-label="Delete timetable row">Delete</button></td></tr>`).join("")}</tbody></table></div>`:`<div class="academic-empty">No timetable rows yet. Upload a file or add a row.</div>`}`;
 $$("[data-field]",target).forEach(input=>input.addEventListener("change",()=>timetableAdminTouched.add(input.dataset.eventId)));
 $$("[data-delete-row]",target).forEach(button=>button.addEventListener("click",()=>{const rowId=button.dataset.deleteRow;timetableAdminDraft=timetableAdminDraft.filter(event=>event.id!==rowId);timetableAdminTouched.delete(rowId);renderTimetableAdminDraft()}));
}
function addTimetableDraftRow(){
 const id=`draft-${Date.now()}-${Math.random().toString(36).slice(2)}`;
 timetableAdminDraft.push({id,day:0,start:8,duration:1,room:"",branch:"",section:"",courseCode:"",title:"",teacher:"",meta:"",kind:"blue-event",source:"managed"});
 timetableAdminTouched.add(id);renderTimetableAdminDraft();
}
function parseClock(value,allowEnd=false){
 const match=String(value||"").match(/(\d{1,2})(?::(\d{2}))?\s*(am|pm)?/i);if(!match)return null;
 let hour=Number(match[1]),minute=Number(match[2]||0),period=(match[3]||"").toLowerCase();
 if(period==="pm"&&hour<12)hour+=12;if(period==="am"&&hour===12)hour=0;
 if(minute!==0||hour<8||hour>18||hour===18&&!allowEnd)return null;
 return hour;
}
function parseDay(value){
 if(typeof value==="number")return Number.isInteger(value)&&value>=0&&value<5?value:null;
 const day=String(value||"").trim().toLowerCase();if(!day)return null;
 const index=scheduleDays.findIndex(item=>item.toLowerCase().startsWith(day.slice(0,3)));
 return index<0?null:index;
}
function makeTimetableEvent(raw,defaults={}){
 const day=parseDay(raw.day??raw.Day??defaults.day);
 const room=String(raw.room??raw.roomNumber??defaults.room??"").trim().replace(/^room\s*/i,"");
 const courseCode=String(raw.courseCode??raw.subjectCode??raw.subject??raw.title??"").trim();
 const branch=String(raw.branch??"").trim();
 const sectionText=String(raw.section??"").trim(),semester=String(raw.semester??"").trim();
 const section=sectionText?(sectionText.toLowerCase().includes("section")?`${branch?`${branch} · `:""}${sectionText}`:`${branch?`${branch} · `:""}Section ${sectionText}${semester&&!/sem/i.test(sectionText)?` · Semester ${semester}`:""}`):[branch,semester&&`Semester ${semester}`].filter(Boolean).join(" · ");
 const start=parseClock(raw.start??raw.startTime??defaults.start);
 let duration=Number(raw.duration);
 if(!duration){
  const range=parseTimeRange(raw.start??raw.startTime);
  const end=parseClock(raw.end??raw.endTime??defaults.end,true);
  duration=range?.duration||(end!==null&&start!==null?end-start:1);
 }
 const teacher=String(raw.teacher??raw.faculty??raw.facultyName??"").trim();
 const title=String(raw.title??"").trim()||[branch,courseCode].filter(Boolean).join(" · ")||courseCode;
 return {id:raw.id||`import-${Date.now()}-${Math.random().toString(36).slice(2)}`,day,start,duration,room,branch,section,courseCode,title,teacher,meta:[teacher,semester&&`Sem ${semester}`,sectionText&&`Sec ${sectionText.replace(/^section\s*/i,"")}`].filter(Boolean).join(" · "),kind:"blue-event",source:"managed"};
}
const timetableAliases={
 day:["day","weekday"],start:["start","starttime","from","begin"],end:["end","endtime","to","finish"],duration:["duration","hours","length"],
 slot:["timeslot","time","timing","period"],room:["room","roomno","roomnumber","classroom","venue"],
 teacher:["teacher","faculty","facultyname","instructor","staff"],subject:["subject","subjectname","course","coursename","class","classname","subjectcode","coursecode","code"],
 branch:["branch","branchname","department","departmentname"],section:["section","sectionname","sectioncode"],semester:["semester","sem","term"]
};
function timetableHeaderMap(headers){
 const result={};Object.entries(timetableAliases).forEach(([field,aliases])=>{result[field]=headers.find(header=>aliases.includes(normalizeHeader(header)))});
 return result;
}
function parseTimeRange(value){
 const match=String(value||"").match(/(\d{1,2}(?::\d{2})?\s*(?:am|pm)?)\s*[-–—]\s*(\d{1,2}(?::\d{2})?\s*(?:am|pm)?)/i);
 if(!match)return null;const start=parseClock(match[1]),end=parseClock(match[2],true);return start!==null&&end!==null&&end>start?{start,duration:end-start}:null;
}
function inferCellDetails(value){
 const text=String(value||"").replace(/\s+/g," ").trim(),branch=text.match(/^\s*([A-Z]{2,5})\s*[-–]\s*/)?.[1]||"";
 const code=text.match(/\b[A-Z]{2,6}[A-Z0-9]{2,}\b/)?.[0]||"";
 const semester=text.match(/\bsem(?:ester)?\s*[:.-]?\s*(\d+)\b/i)?.[1]||"";
 const section=text.match(/\bsec(?:tion)?\s*[:.-]?\s*([A-Z0-9]+)\b/i)?.[1]||"";
 const teacher=text.replace(/^\s*[A-Z]{2,5}\s*[-–]\s*/,"").replace(code,"").replace(/\bsem(?:ester)?\s*[:.-]?\s*\d+\b/ig,"").replace(/\bsec(?:tion)?\s*[:.-]?\s*[A-Z0-9]+\b/ig,"").replace(/[·,;:-]/g," ").replace(/\s+/g," ").trim();
 return {branch,courseCode:code||text,title:code?[branch,code].filter(Boolean).join(" · "):text,teacher,semester,section};
}
function extractRoomNumber(text,fallback=""){
 return String(text||"").match(/\broom\s*(?:no\.?\s*)?(\d{3,5})\b/i)?.[1]||String(fallback||"").match(/\b(\d{4,5})\b/)?.[1]||"";
}
function parseTimetableSheet(matrix,fileName){
 if(!Array.isArray(matrix)||matrix.length<2)throw new Error("The first worksheet does not contain enough rows.");
 const allText=matrix.flat().join(" "),defaultRoom=extractRoomNumber(allText,fileName);
 const headerIndex=matrix.slice(0,12).findIndex(row=>row.some(cell=>normalizeHeader(cell)==="day")&&row.some(cell=>parseTimeRange(cell)));
 const rows=[];
 if(headerIndex>=0){
  const headers=matrix[headerIndex].map(String),dayColumn=headers.findIndex(header=>["day","weekday"].includes(normalizeHeader(header)));
  const timeColumns=headers.map((header,index)=>({index,range:parseTimeRange(header)})).filter(item=>item.range);
  if(timeColumns.length){
   matrix.slice(headerIndex+1).forEach(row=>{
    const day=parseDay(row[dayColumn]);if(day===null)return;
    timeColumns.forEach(({index,range})=>{
     const value=String(row[index]??"").trim();if(!value)return;
     const details=inferCellDetails(value);
     rows.push(makeTimetableEvent({...details,day,start:range.start,duration:range.duration,room:defaultRoom,section:details.section,semester:details.semester}));
    });
   });
   if(rows.length)return rows;
  }
 }
 let headerRowIndex=matrix.slice(0,12).findIndex(row=>{const map=timetableHeaderMap(row.map(String));return Boolean(map.day&&map.room&&(map.start||map.slot)&&(map.subject||map.teacher))});
 if(headerRowIndex<0)headerRowIndex=0;
 const headers=matrix[headerRowIndex].map(String),map=timetableHeaderMap(headers);
 if(!map.day||(!map.start&&!map.slot))throw new Error("Could not identify timetable columns. Include headers such as Day, Time/Start, Room, Subject, and Faculty.");
 matrix.slice(headerRowIndex+1).forEach(row=>{
  const raw={};Object.entries(map).forEach(([field,header])=>{if(header)raw[field]=row[headers.indexOf(header)]??""});
  if(!raw.start&&raw.slot){const range=parseTimeRange(raw.slot);if(range){raw.start=range.start;raw.duration=range.duration}}
  if(raw.subject&&!raw.teacher){Object.assign(raw,inferCellDetails(raw.subject))}
  const event=makeTimetableEvent(raw,{room:defaultRoom});
  if(event.day!==null&&event.start!==null&&event.room&&event.title)rows.push(event);
 });
 if(!rows.length)throw new Error("No timetable entries could be extracted. Add clear column headings and one class per row.");
 return rows;
}
async function ensureTesseract(){
 if(window.Tesseract)return window.Tesseract;
 await new Promise((resolve,reject)=>{
  const script=document.createElement("script");script.src="https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js";script.onload=resolve;script.onerror=()=>reject(new Error("Could not load the OCR engine. Check your internet connection and try again."));document.head.append(script);
 });
 return window.Tesseract;
}
async function recognizeTimetableImage(file){
 const tesseract=await ensureTesseract(),worker=await tesseract.createWorker("eng");
 try{
  const {data}=await worker.recognize(file),words=(data.words||[]).filter(word=>String(word.text||"").trim());
  const room=extractRoomNumber(data.text,file.name);
  const lines=[];
  words.sort((a,b)=>a.bbox.y0-b.bbox.y0||a.bbox.x0-b.bbox.x0).forEach(word=>{
   const cy=(word.bbox.y0+word.bbox.y1)/2;
   let line=lines.find(item=>Math.abs(item.y-cy)<Math.max(8,(word.bbox.y1-word.bbox.y0)*.7));
   if(!line){line={y:cy,words:[]};lines.push(line)}
   line.words.push(word);
  });
  lines.forEach(line=>line.words.sort((a,b)=>a.bbox.x0-b.bbox.x0));
  const timeSlots=[];
  lines.forEach(line=>{
   const text=line.words.map(word=>word.text).join(" ");
   const range=parseTimeRange(text);
   if(range)timeSlots.push({x:line.words.reduce((sum,word)=>sum+(word.bbox.x0+word.bbox.x1)/2,0)/line.words.length,...range});
   else{
    const matches=text.match(/\b\d{1,2}:\d{2}\b/g)||[];
    if(matches.length>1){
     const timeWords=line.words.filter(word=>/\d{1,2}:\d{2}/.test(word.text));
     for(let i=0;i+1<timeWords.length;i+=2){const start=parseClock(timeWords[i].text),end=parseClock(timeWords[i+1].text);if(start!==null&&end!==null&&end>start)timeSlots.push({x:(timeWords[i].bbox.x0+timeWords[i+1].bbox.x1)/2,start,duration:end-start})}
    }
   }
  });
  const dayWords=words.filter(word=>parseDay(word.text)!==null).map(word=>({day:parseDay(word.text),y:(word.bbox.y0+word.bbox.y1)/2}));
  const uniqueDays=[...new Map(dayWords.map(item=>[item.day,item])).values()].sort((a,b)=>a.y-b.y);
  const uniqueSlots=[...new Map(timeSlots.sort((a,b)=>a.x-b.x).map(slot=>[`${slot.x.toFixed(0)}-${slot.start}`,slot])).values()].sort((a,b)=>a.x-b.x);
  if(uniqueDays.length&&uniqueSlots.length){
   const minX=Math.min(...words.map(word=>word.bbox.x0)),maxX=Math.max(...words.map(word=>word.bbox.x1)),minY=Math.min(...words.map(word=>word.bbox.y0)),maxY=Math.max(...words.map(word=>word.bbox.y1));
   return uniqueDays.flatMap((day,index)=>{
    const previous=uniqueDays[index-1],next=uniqueDays[index+1],top=previous?(previous.y+day.y)/2:Math.max(minY,day.y-(next?next.y-day.y:70)/2),bottom=next?(day.y+next.y)/2:Math.min(maxY,day.y+(previous?day.y-previous.y:70)/2);
    return uniqueSlots.flatMap((slot,slotIndex)=>{
     const left=slotIndex?(uniqueSlots[slotIndex-1].x+slot.x)/2:minX,right=slotIndex<uniqueSlots.length-1?(slot.x+uniqueSlots[slotIndex+1].x)/2:maxX;
     const cell=words.filter(word=>{const x=(word.bbox.x0+word.bbox.x1)/2,y=(word.bbox.y0+word.bbox.y1)/2;return x>=left&&x<right&&y>=top&&y<bottom}).sort((a,b)=>a.bbox.y0-b.bbox.y0||a.bbox.x0-b.bbox.x0).map(word=>word.text).join(" ").trim();
     if(!cell)return [];
     const details=inferCellDetails(cell);
     return [makeTimetableEvent({...details,day:day.day,start:slot.start,duration:slot.duration,room,section:details.section,semester:details.semester})];
    });
   });
  }
  const textLines=(data.text||"").split(/\r?\n/).map(line=>line.trim()).filter(Boolean),detected=[];
  textLines.forEach(line=>{const day=parseDay(line.match(/^(Mon(?:day)?|Tue(?:sday)?|Wed(?:nesday)?|Thu(?:rsday)?|Fri(?:day)?)/i)?.[1]);const range=parseTimeRange(line);if(day!==null&&range){const details=inferCellDetails(line);detected.push(makeTimetableEvent({...details,day,start:range.start,duration:range.duration,room}))}});
  if(!detected.length)throw new Error("OCR read the image but could not confidently map its timetable grid. Try a clearer, straight-on image or import an Excel sheet.");
  return detected;
 }finally{await worker.terminate()}
}
function handleTimetableUpload(file){
 if(file.size>15*1024*1024){toast("Choose a timetable file smaller than 15 MB.","error");return}
 const isImage=/\.(png|jpe?g)$/i.test(file.name),isWorkbook=/\.(xlsx|xls)$/i.test(file.name);
 if(!isImage&&!isWorkbook){toast("Choose an Excel workbook (.xlsx, .xls) or timetable image (.png, .jpg, .jpeg).","error");return}
 const status=$("#timetableImportStatus");status.textContent=isImage?"Reading timetable image with OCR...":"Reading the first worksheet...";
 const process=async()=>{
  try{
   let imported;
   if(isImage)imported=await recognizeTimetableImage(file);
   else{
    if(!window.XLSX)throw new Error("The Excel reader is unavailable. Check your internet connection and reload the page.");
    const buffer=await file.arrayBuffer(),workbook=XLSX.read(buffer,{type:"array"}),sheet=workbook.Sheets[workbook.SheetNames[0]];
    if(!sheet)throw new Error("The workbook has no worksheet.");
    const matrix=XLSX.utils.sheet_to_json(sheet,{header:1,defval:"",raw:false});
    imported=parseTimetableSheet(matrix,file.name);
   }
   if(!imported.length)throw new Error("No schedule records were extracted from this file.");
   if(imported.length>2000)throw new Error("A maximum of 2,000 timetable entries can be imported at once.");
   const replace=$("#timetableReplaceExisting").checked;
   timetableAdminDraft=replace?[...imported]:[...timetableAdminDraft,...imported];
   imported.forEach(event=>timetableAdminTouched.add(event.id));
   renderTimetableAdminDraft();
   status.textContent=`Preview: extracted ${imported.length} rows from ${file.name}. Review and correct them below before saving.`;
  }catch(error){console.error("Unable to extract timetable data.",error);status.textContent=error.message||"Timetable extraction failed.";toast(status.textContent,"error")}
 };
 process();
}
function readTimetableAdminDraft(){
 $$("#timetableDraftTable [data-event-id]").forEach(input=>{
  const event=timetableAdminDraft.find(item=>item.id===input.dataset.eventId);if(!event)return;
  const field=input.dataset.field,value=input.value,nextValue=field==="day"||field==="duration"?Number(value):field==="start"?Number(value.slice(0,2)):value;
  if(event[field]!==nextValue)event[field]=nextValue;
 });
 timetableAdminDraft.forEach(event=>{
  const current=JSON.stringify([event.day,event.start,event.duration,event.room,event.branch,event.section,event.courseCode,event.teacher]);
  if(!timetableAdminBaseline.has(event.id)||timetableAdminBaseline.get(event.id)!==current){timetableAdminTouched.add(event.id);refreshEventDisplayFields(event)}
  else timetableAdminTouched.delete(event.id);
 });
}
function saveTimetableDraft(){
 readTimetableAdminDraft();
 const replace=$("#timetableReplaceExisting").checked;
 const changedIds=replace?new Set(timetableAdminDraft.map(event=>event.id)):timetableAdminTouched;
 const errors=validateTimetableRows(timetableAdminDraft,changedIds);
 if(errors.length){$("#timetableImportStatus").textContent=errors[0];toast(errors[0],"error");return}
 if(replace&&!timetableAdminDraft.length){toast("The replacement table is empty. Add or import records before replacing existing data.","error");return}
 persistManagedTimetable(timetableAdminDraft);$("#appDialog").close();toast("Imported and edited timetable records were saved across the site.");
}
function exportTimetableDraft(){
 readTimetableAdminDraft();
 if(!window.XLSX){toast("Excel export needs an internet connection to load the workbook library.","error");return}
 const headers=["Day","Start","Duration","Room","Branch","Section","Subject / code","Faculty"];
 const rows=timetableAdminDraft.map(event=>[scheduleDays[event.day]||"",`${String(event.start).padStart(2,"0")}:00`,event.duration,event.room,event.branch,event.section,event.courseCode,event.teacher]);
 const workbook=XLSX.utils.book_new(),sheet=XLSX.utils.aoa_to_sheet([headers,...rows]);
 XLSX.utils.book_append_sheet(workbook,sheet,"Timetable");
 XLSX.writeFile(workbook,`${timetableAdminMode}-timetable.xlsx`);
}
$("#timetableVersionFilter").addEventListener("change",updateAcademicSurfaces);
function intervalsOverlap(aStart,aEnd,bStart,bEnd){return aStart<bEnd&&bStart<aEnd}
function saveScheduleAdditions(){
 try{localStorage.setItem(scheduleStorageKey,JSON.stringify(addedScheduleEvents))}
 catch(error){console.error("Unable to save schedule changes.",error);toast("Schedule updated for this session, but browser storage failed.","error")}
}
function resetAvailableRooms(){
 $("#suggestedRooms").innerHTML=`<div class="empty-state"><span>⌕</span><strong>Ready when you are</strong><p>Complete the form to see rooms without a listed conflict.</p></div>`;
}
function renderScheduleActivity(){
 const activity=$("#scheduleActivity");
 if(!activity)return;
 const entries=[...addedScheduleEvents].reverse();
 activity.innerHTML=entries.length?entries.map(event=>{
  const added=event.createdAt?new Date(event.createdAt).toLocaleString():"Previously added";
  return `<article class="schedule-activity-item"><div class="schedule-activity-details"><strong>${esc(event.title)}</strong><span>Room ${esc(event.room)} · ${esc(scheduleDays[event.day])} · ${String(event.start).padStart(2,"0")}:00–${String(event.start+event.duration).padStart(2,"0")}:00</span><small>${esc(event.teacher||"Teacher unspecified")} · ${esc(event.section)}</small><small>Added ${esc(added)}</small></div><button type="button" class="btn btn-secondary schedule-undo" data-undo-schedule="${esc(event.id)}">Undo</button></article>`;
 }).join(""):`<div class="schedule-activity-empty">No schedule changes yet. Added classes will appear here with an undo option.</div>`;
 $$("[data-undo-schedule]",activity).forEach(button=>button.addEventListener("click",()=>undoScheduledClass(button.dataset.undoSchedule)));
}
function undoScheduledClass(id){
 const event=addedScheduleEvents.find(item=>item.id===id);
 if(!event){toast("That schedule change is no longer available to undo.","error");return}
 const previousAdded=addedScheduleEvents.slice();
 addedScheduleEvents=addedScheduleEvents.filter(item=>item.id!==id);
 if(managedTimetableEvents){
  const restored=[...managedTimetableEvents.filter(item=>item.id!==id),...(event.replacedEvents||[])];
  if(!persistManagedTimetable(restored)){addedScheduleEvents=previousAdded;return}
 }
 else{saveScheduleAdditions();rebuildScheduleIndexes();updateAcademicSurfaces();renderRooms();renderDashboard();renderReports();renderScheduleActivity()}
 resetAvailableRooms();
 toast(`Undid ${event.title} in Room ${event.room}.`);
}
function addScheduledClass(event,room){
 const teacherConflict=getTeacherScheduleConflict(event);
 if(teacherConflict){toast(`Cannot schedule: ${event.teacher} is already teaching ${teacherConflict.title} in Room ${teacherConflict.room} from ${String(teacherConflict.start).padStart(2,"0")}:00 to ${String(teacherConflict.start+teacherConflict.duration).padStart(2,"0")}:00.`,"error");return}
 const collision=timetableEvents.find(existing=>existing.day===event.day&&intervalsOverlap(event.start,event.start+event.duration,existing.start,existing.start+existing.duration)&&(existing.room===room||existing.section===event.section));
 if(collision){toast(`Schedule conflict with ${collision.title} in room ${collision.room}.`,"error");return}
 const added={...event,id:`${Date.now()}-${Math.random().toString(36).slice(2)}`,createdAt:new Date().toISOString(),room,source:"local"};
 preferredScheduleRoom="";
 addedScheduleEvents.push(added);
 if(managedTimetableEvents){if(!persistManagedTimetable([...managedTimetableEvents,added])){addedScheduleEvents=addedScheduleEvents.filter(item=>item.id!==added.id);return}}
 else{saveScheduleAdditions();rebuildScheduleIndexes();updateAcademicSurfaces();renderRooms();renderDashboard();renderReports();renderScheduleActivity()}
 $("#suggestedRooms").innerHTML=`<div class="empty-state"><span>✓</span><strong>Class scheduled</strong><p>${esc(event.title)} has been added to Room ${esc(room)} across the site.</p></div>`;
 toast(`Class added to Room ${room}.`);
}
$("#scheduleForm").addEventListener("reset",()=>{preferredScheduleRoom=""});
$("#scheduleForm").addEventListener("submit",e=>{
 e.preventDefault();
 const f=new FormData(e.target),subject=String(f.get("subject")).trim(),section=String(f.get("section")),teacher=String(f.get("teacher")),date=String(f.get("date")),startText=String(f.get("start")),endText=String(f.get("end"));
 const start=Number(startText.slice(0,2)),end=Number(endText.slice(0,2)),day=(new Date(`${date}T00:00:00`).getDay()+6)%7;
 if(day>4){toast("Choose a Monday-to-Friday date to match the supplied timetable.","error");return}
 if(!subject||!section||!teacher){toast("Choose a subject, section, and teacher from the provided data.","error");return}
 if(!/^\d{2}:00$/.test(startText)||!/^\d{2}:00$/.test(endText)||start<8||end>18||end<=start){toast("Choose whole-hour times between 08:00 and 18:00.","error");return}
 const event={day,start,duration:end-start,title:subject.includes(" · ")?subject:`${section.split(" · ")[0]} · ${subject}`,meta:`${teacher} · ${section}`,teacher,section,branch:section.split(" · ")[0]||"Unspecified",courseCode:subject.includes(" · ")?subject.split(" · ").at(-1):subject,kind:"blue-event",source:"local"};
 const teacherConflict=getTeacherScheduleConflict(event);
 const result=$("#suggestedRooms"),dateLabel=new Date(`${date}T00:00:00`).toLocaleDateString(undefined,{weekday:"long",month:"short",day:"numeric"});
 const roomsForSlot=rooms.map(room=>({room,state:getRoomScheduleState(room.number,event)}));
 const teacherConflictMessage=teacherConflict?`<div class="schedule-teacher-conflict" role="alert">Teacher ${esc(teacher)} is unavailable: already teaching ${esc(teacherConflict.title)} in Room ${esc(teacherConflict.room)} from ${String(teacherConflict.start).padStart(2,"0")}:00 to ${String(teacherConflict.start+teacherConflict.duration).padStart(2,"0")}:00.</div>`:"";
 result.innerHTML=roomsForSlot.length?`${teacherConflictMessage}<div class="schedule-results-summary">${dateLabel} · ${startText}–${endText} · ${roomsForSlot.filter(item=>item.state.status==="available").length} available · ${roomsForSlot.filter(item=>item.state.status==="maybe").length} maybe · ${roomsForSlot.filter(item=>item.state.status==="busy").length} busy</div><div class="schedule-room-results">${roomsForSlot.map(({room,state})=>{
  const classList=state.classes.map(item=>item.title).join(", ");
  const action=teacherConflict?`<span class="availability-state state-busy">Teacher unavailable</span>`:state.status==="available"?`<button type="button" class="btn btn-primary room-slot-action" data-select-room="${esc(room.number)}">Schedule here</button>`:`<button type="button" class="btn btn-secondary room-slot-action" data-request-room="${esc(room.number)}">Request this room</button>`;
  const statusLabel=state.status==="available"?"Available":state.status==="maybe"?"Maybe · Semester 7":"Busy";
  const detail=state.classes.length?`Conflicts with: ${esc(classList)}`:"No conflicting class in the timetable";
  return `<article class="suggestion schedule-room-result state-${state.status}"><span class="room-icon">▤</span><div class="suggestion-info"><strong>Room ${esc(room.number)} <span class="availability-state state-${state.status}">${statusLabel}</span></strong><small>${detail}</small></div>${action}</article>`;
 }).join("")}</div>`:`<div class="empty-state"><span>⌕</span><strong>No rooms are listed</strong><p>There are no rooms in the supplied timetable.</p></div>`;
 $$("[data-select-room]").forEach(button=>button.addEventListener("click",()=>addScheduledClass(event,button.dataset.selectRoom)));
 $$("[data-request-room]").forEach(button=>button.addEventListener("click",()=>openRoomRequest(button.dataset.requestRoom,day,start,event)));
 const availableCount=roomsForSlot.filter(item=>item.state.status==="available").length;
 toast(teacherConflict?`Teacher ${teacher} is unavailable during the selected time.`:`${availableCount} room${availableCount===1?" is":"s are"} available; busy and maybe rooms can be requested.`,teacherConflict?"error":"success");
});
function downloadCSV(filename,rows){const csv=rows.map(row=>row.map(v=>`"${String(v).replace(/"/g,'""')}"`).join(",")).join("\r\n");const blob=new Blob(["\ufeff"+csv],{type:"text/csv;charset=utf-8;"});const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download=filename;a.click();URL.revokeObjectURL(url);toast("CSV export prepared.")}
function exportRooms(){const today=new Date(),day=(today.getDay()+6)%7,dayName=today.toLocaleDateString(undefined,{weekday:"long"});downloadCSV("room-directory-today.csv",[["Date",today.toLocaleDateString()],["Room",`Scheduled classes · ${dayName}`,"Busy hourly slots","Available slots","Maybe slots"],...rooms.map(room=>{const events=timetableEvents.filter(event=>event.room===room.number&&event.day===day),counts=countRoomSlotStatuses(room.number);return [room.number,events.length,counts.busy,counts.available,counts.maybe]})])}
$("#exportBtn").addEventListener("click",()=>{const slots=rooms.reduce((sum,room)=>{const count=countRoomSlotStatuses(room.number);return {available:sum.available+count.available,busy:sum.busy+count.busy,maybe:sum.maybe+count.maybe}},{available:0,busy:0,maybe:0});downloadCSV("campus-overview.csv",[["Metric","Value"],["Rooms in provided schedules",rooms.length],["Scheduled class entries",timetableEvents.length],["Teachers in provided schedules",teachers.length],["Available weekly slots",slots.available],["Busy weekly slots",slots.busy],["Maybe weekly slots",slots.maybe],["Room requests saved in this browser",requests.length]])});
$("#roomExport").addEventListener("click",exportRooms);
$("#requestExport").addEventListener("click",()=>downloadCSV("requests.csv",[["Request","Requested by","Date","Day","Start","Room","Status","Note"],...requests.map(request=>[request.request,request.requestedBy,request.date||"",scheduleDays[request.day]||"",`${String(request.start).padStart(2,"0")}:00`,request.room,request.status,request.note||""])]));
$("#reportExport").addEventListener("click",()=>downloadCSV("utilization-report.csv",[["Day","Occupied slots","Utilization"],...scheduleDays.map((day,index)=>{const occupied=new Set(timetableEvents.filter(event=>event.day===index).flatMap(event=>Array.from({length:event.duration},(_,slot)=>`${event.room}:${event.start+slot}`))).size;return [day,occupied,`${rooms.length?Math.round(occupied/(rooms.length*10)*100):0}%`]})]));
$("#globalSearch").addEventListener("keydown",e=>{if(e.key==="Enter"){const q=e.target.value.trim();if(!q)return;go("rooms");$("#roomSearch").value=q;renderRooms()}});
$("#globalSearch").addEventListener("input",e=>{if(e.target.value.length>1){const q=e.target.value.toLowerCase();if(rooms.some(r=>r.number.toLowerCase().includes(q))||timetableEvents.some(event=>`${event.title} ${event.meta} ${event.room}`.toLowerCase().includes(q)))$("#globalSearch").style.borderColor="#9aa9ff";else $("#globalSearch").style.borderColor=""}});
const scheduleTip=$(".tips-panel");if(scheduleTip){scheduleTip.querySelector("p").textContent="Availability is checked against the supplied timetable.";scheduleTip.querySelector("ul").innerHTML="<li>Choose a Monday-to-Friday date.</li><li>Select whole-hour times between 08:00 and 18:00.</li><li>Room, teacher, and section overlaps are checked before adding.</li><li>Capacity and room features were not supplied and are not assumed.</li><li>Schedule additions are saved in this browser.</li>"}
updateAcademicSurfaces();renderRooms();renderRequests();renderTeachers();renderTimetable();renderDashboard();renderReports();renderScheduleActivity();
setInterval(renderDashboard,30_000);setInterval(renderRooms,60_000);
$(".calendar-legend").innerHTML="<span><i class='legend-box semester-legend-3'></i>Semester 3</span><span><i class='legend-box semester-legend-5'></i>Semester 5</span><span><i class='legend-box semester-legend-7'></i>Semester 7</span><span>Blank slots have no listed class</span>";
const scheduleDateLabel=$('#scheduleForm [name="date"]')?.closest("label");if(scheduleDateLabel)scheduleDateLabel.insertAdjacentHTML("beforeend","<small>Only the weekday is used in this weekly view.</small>");
$("#page-rooms .page-heading p").textContent="Today's classes and room status are calculated from the device's system date and the supplied timetable.";
$("#page-teachers .page-heading p").textContent="Teacher names, branches, and course codes found in the supplied schedules.";
$("#page-reports .page-heading p").textContent="Calculated from the same timetable entries shown across the site.";
$("#page-schedule .page-heading p").textContent="Compare every room for the requested weekday and time. Schedule an available room or request a busy/maybe slot.";
$("#roomSearch").placeholder="Search room number...";
$("#page-requests .page-heading h1").textContent="Requests";
// Expose read-only integration hooks for the optional live API bridge.
window.rooms = rooms;
window.renderRooms = renderRooms;
