/* Roomwise integration layer. Loaded AFTER app.js.
   It replaces the localStorage-backed behaviours of the original prototype with API calls while the
   existing markup/CSS/render functions are kept. Role checks below only decide what to SHOW; the server
   enforces every permission. */
(function () {
  const { api, esc } = RW;
  const role = () => RW.user.role;
  const isAdmin = () => role() === "ADMIN";
  const isStaff = () => role() === "ADMIN" || role() === "CR";
  RW.isAdmin = isAdmin;
  const ownsSection = id => isAdmin() || (RW.mySectionIds || []).includes(id);
  const err = e => toast(e.message || "Something went wrong.", "error");
  const pad = n => String(n).padStart(2, "0");
  const dayName = iso => new Date(iso + "T00:00:00").toLocaleDateString(undefined, { weekday: "short", day: "2-digit", month: "short" });

  // ---------------------------------------------------------------- data refresh
  // Rooms come from the ROOM table (not only from rooms that happen to have a class this week).
  const baseRebuild = rebuildScheduleIndexes;
  rebuildScheduleIndexes = function () {
    baseRebuild();
    const nums = new Set([...rooms.map(r => r.number), ...RW.catalog.rooms.filter(r => r.status === "Active").map(r => r.room_number)]);
    rooms = [...nums].sort((a, b) => a.localeCompare(b, undefined, { numeric: true })).map((number, index) => ({ id: index + 1, number }));
    window.rooms = rooms;
  };
  rebuildScheduleIndexes();
  let activeRequestFilter = "All";
  RW.reload = async function (opts = {}) {
    try {
      const events = await RW.loadWeekData(opts.week || RW.weekStart);
      sourceTimetableEvents.length = 0; events.forEach(e => sourceTimetableEvents.push({ ...e }));
      managedTimetableEvents = null; addedScheduleEvents = [];
      requests = await RW.loadRequests();
      rebuildScheduleIndexes(); updateAcademicSurfaces(); renderRooms(); renderRequests(activeRequestFilter);
      renderDashboard(); renderReports(); renderScheduleActivity(); renderTimetable(); renderWeekLabel(); refreshNotifications();
    } catch (e) { err(e); }
  };
  function renderWeekLabel() {
    const mon = new Date(RW.weekStart + "T00:00:00"), fri = new Date(mon); fri.setDate(fri.getDate() + 4);
    const f = d => d.toLocaleDateString(undefined, { day: "numeric", month: "short" });
    $("#weekLabel").textContent = `${f(mon)} – ${f(fri)} ${fri.getFullYear()}`;
  }
  RW.shiftWeek = days => { const d = new Date(RW.weekStart + "T00:00:00"); d.setDate(d.getDate() + days); return RW.reload({ week: RW.iso(d) }); };
  $("#weekPrev").hidden = false; $("#weekNext").hidden = false;
  $("#weekPrev").addEventListener("click", () => RW.shiftWeek(-7));
  $("#weekNext").addEventListener("click", () => RW.shiftWeek(7));
  renderWeekLabel();

  // ---------------------------------------------------------------- small dialogs
  function askReason(title, { required = true, label = "Reason", confirm = "Confirm" } = {}) {
    return new Promise(resolve => {
      let done = false;
      openDialog(title, `<form id="rwReasonForm" class="dialog-content"><label class="field">${esc(label)}<textarea name="reason" rows="3" maxlength="500" ${required ? "required" : ""} placeholder="${required ? "Required" : "Optional"}"></textarea></label><div class="dialog-actions"><button type="button" class="btn btn-secondary" data-dialog-close>Cancel</button><button class="btn btn-primary" type="submit">${esc(confirm)}</button></div></form>`);
      const d = $("#appDialog"); const onClose = () => { if (!done) resolve(null); d.removeEventListener("close", onClose); };
      d.addEventListener("close", onClose);
      $("#rwReasonForm").addEventListener("submit", e => { e.preventDefault(); done = true; const v = new FormData(e.target).get("reason").trim(); d.close(); resolve(v); });
    });
  }

  // ---------------------------------------------------------------- extra-class requests (CR -> CR / ADMIN)
  const sectionId = label => RW.catalog.sections.find(s => s.label === label)?.section_id ?? null;
  const teacherId = name => RW.catalog.teachers.find(t => t.name === name)?.teacher_id ?? null;
  const subjectId = code => RW.catalog.subjects.find(s => s.code.toLowerCase() === String(code).trim().toLowerCase())?.subject_id ?? null;
  const roomId = num => RW.catalog.rooms.find(r => r.room_number === num)?.room_id ?? null;
  const mySections = () => RW.catalog.sections.filter(s => s.status === "Active" && ownsSection(s.section_id));

  openRoomRequest = function (room, day, start, scheduleEvent = null) {
    if (!isStaff()) { toast("Viewer accounts are read-only.", "error"); return; }
    const duration = scheduleEvent?.duration || 1;
    const formDate = $('#scheduleForm [name="date"]').value;
    const date = scheduleEvent ? (scheduleEvent.date || formDate) : RW.iso(new Date());
    if (!date) { toast("Pick a date in the scheduling form first.", "error"); return; }
    const secs = mySections();
    if (!secs.length) { toast("You are not assigned to any section, so you cannot request rooms.", "error"); return; }
    openDialog(`Request Room ${room}`, `<form id="roomRequestForm" class="dialog-content">
      <p class="dialog-message">Your request goes to the CR who owns that slot, or to an administrator if there is none. Conflicts are checked again when it is decided.</p>
      <label class="field">Class / subject code<input name="subject" required list="subjectOptions" value="${esc(scheduleEvent?.courseCode || "")}"></label>
      <label class="field">For section<select name="section" required>${secs.map(s => `<option value="${s.section_id}" ${s.label === scheduleEvent?.section ? "selected" : ""}>${esc(s.label)}</option>`).join("")}</select></label>
      <label class="field">Teacher<select name="teacher"><option value="">Not specified</option>${RW.catalog.teachers.map(t => `<option ${t.name === scheduleEvent?.teacher ? "selected" : ""}>${esc(t.name)}</option>`).join("")}</select></label>
      <label class="field">Purpose<textarea name="note" rows="2" maxlength="500" placeholder="Optional context for the approver"></textarea></label>
      <div class="dialog-list"><div><strong>Slot:</strong> ${esc(dayName(date))}, ${pad(start)}:00–${pad(start + duration)}:00</div><div><strong>Room:</strong> ${esc(room)}</div></div>
      <div class="dialog-actions"><button type="button" class="btn btn-secondary" data-dialog-close>Cancel</button><button class="btn btn-primary" type="submit">Send request</button></div></form>`);
    $("#roomRequestForm").addEventListener("submit", async e => {
      e.preventDefault(); const f = new FormData(e.currentTarget), btn = e.submitter; btn.disabled = true;
      const sid = subjectId(f.get("subject")), rid = roomId(room);
      if (!sid) { toast("Unknown subject code. Pick one from the list (an admin can add subjects).", "error"); btn.disabled = false; return; }
      try {
        const r = await api("/api/requests", { method: "POST", body: { section_id: Number(f.get("section")), subject_id: sid, teacher_id: teacherId(f.get("teacher")), room_id: rid, date, start: `${pad(start)}:00`, end: `${pad(start + duration)}:00`, purpose: String(f.get("note") || "").trim() || null } });
        $("#appDialog").close(); await RW.reload(); toast(`Request #${r.request_id} sent to ${r.routed_to === "CR" ? "the section's CR" : "an administrator"}.`);
      } catch (ex) { err(ex); btn.disabled = false; }
    });
  };

  // ADMIN books directly; CRs are turned into a request (the backend forbids direct CR booking)
  addScheduledClass = async function (event, room) {
    const date = $('#scheduleForm [name="date"]').value;
    if (!isAdmin()) { openRoomRequest(room, event.day, event.start, { ...event, date }); return; }
    const sid = sectionId(event.section), tid = teacherId(event.teacher), sub = subjectId(event.courseCode), rid = roomId(room);
    if (!sid || !sub || !rid) { toast("Choose an existing section and subject code (add new ones under Administration).", "error"); return; }
    try {
      await api("/api/classes", { method: "POST", body: { section_id: sid, subject_id: sub, teacher_id: tid, room_id: rid, date, start: `${pad(event.start)}:00`, end: `${pad(event.start + event.duration)}:00` } });
      await RW.reload(); resetAvailableRooms();
      $("#suggestedRooms").innerHTML = `<div class="empty-state"><span>✓</span><strong>Class scheduled</strong><p>${esc(event.title)} is booked in Room ${esc(room)}.</p></div>`;
      toast(`Class added to Room ${room}.`);
    } catch (ex) { err(ex); }
  };

  // Availability must be computed for the SELECTED date, so load that date's week first, then let the original handler run.
  const form = $("#scheduleForm");
  form.addEventListener("submit", async e => {
    if (form.dataset.ready === "1") { form.dataset.ready = ""; return; }
    e.preventDefault(); e.stopImmediatePropagation();
    const date = form.querySelector('[name="date"]').value; if (!date) return;
    const mon = RW.iso(RW.mondayOf(new Date(date + "T00:00:00")));
    if (mon !== RW.weekStart) await RW.reload({ week: mon });
    form.dataset.ready = "1"; form.requestSubmit();
  }, true);

  // ---------------------------------------------------------------- requests table & decisions
  renderRequests = function (filter = "All") {
    activeRequestFilter = filter;
    const visible = requests.filter(r => filter === "All" || r.type === filter);
    $("#requestsTable").innerHTML = visible.length ? visible.map(r => {
      const sub = [r.type, r.requesterSection && `for ${r.requesterSection}`, r.status === "Pending" ? (r.recipientRole === "CR" ? `awaiting ${r.targetSection || "section"} CR` : "awaiting admin") : (r.decidedBy && `${r.status.toLowerCase()} by ${r.decidedBy}`), r.note, r.decisionReason && `reason: ${r.decisionReason}`].filter(Boolean).join(" · ");
      const actions = r.status !== "Pending" ? `<span class="request-final">${esc(r.status)}</span>`
        : `<div class="request-actions">${r.canDecide ? `<button type="button" class="btn btn-primary request-action" data-accept-request="${esc(r.id)}">Approve</button><button type="button" class="btn btn-secondary request-action" data-reject-request="${esc(r.id)}">Reject</button>` : ""}${r.canWithdraw ? `<button type="button" class="btn btn-secondary request-action" data-withdraw-request="${esc(r.id)}">Withdraw</button>` : ""}${!r.canDecide && !r.canWithdraw ? "<span class=\"request-final\">View only</span>" : ""}</div>`;
      return `<tr><td><strong>${esc(r.request)}</strong><small class="request-subtext">${esc(sub)}</small></td><td>${esc(r.requestedBy)}</td><td>${esc(r.date)} · ${esc(scheduleDays[r.day] || "")} · ${esc(String(r.startTime).slice(0, 5))}–${esc(String(r.endTime).slice(0, 5))}</td><td>${esc(r.room)}</td><td><span class="pill ${r.status === "Pending" ? "pill-pending" : "pill-scheduled"}">${esc(r.status)}</span></td><td>${actions}</td></tr>`;
    }).join("") : `<tr><td colspan="6" class="empty-row">No requests yet.</td></tr>`;
    $("#page-requests .page-heading p").textContent = "Requests routed to you, and requests you sent. Every decision is re-checked against the live schedule.";
    $$("[data-accept-request]").forEach(b => b.addEventListener("click", () => acceptRoomRequest(b.dataset.acceptRequest)));
    $$("[data-reject-request]").forEach(b => b.addEventListener("click", () => rejectRoomRequest(b.dataset.rejectRequest)));
    $$("[data-withdraw-request]").forEach(b => b.addEventListener("click", () => withdrawRequest(b.dataset.withdrawRequest)));
  };
  const findReq = id => requests.find(r => r.id === id);
  acceptRoomRequest = async function (id) {
    const r = findReq(id); if (!r) return;
    const reason = await askReason(`Approve request for Room ${r.room}`, { required: false, label: "Note to requester (optional)", confirm: "Approve" });
    if (reason === null) return;
    try { await api(`/api/requests/${r.kind}/${r.rawId}/decision`, { method: "POST", body: { decision: "approve", reason: reason || null } }); await RW.reload(); toast("Approved. The schedule was updated."); }
    catch (ex) { err(ex); RW.reload(); }
  };
  rejectRoomRequest = async function (id) {
    const r = findReq(id); if (!r) return;
    const reason = await askReason(`Reject request for Room ${r.room}`, { confirm: "Reject" });
    if (!reason) return;
    try { await api(`/api/requests/${r.kind}/${r.rawId}/decision`, { method: "POST", body: { decision: "reject", reason } }); await RW.reload(); toast("Request rejected."); }
    catch (ex) { err(ex); RW.reload(); }
  };
  async function withdrawRequest(id) {
    const r = findReq(id); if (!r) return;
    try { await api(`/api/requests/${r.kind}/${r.rawId}/withdraw`, { method: "POST" }); await RW.reload(); toast("Request withdrawn."); } catch (ex) { err(ex); }
  }
  saveRoomRequests = () => true;
  saveScheduleAdditions = () => {};

  // ---------------------------------------------------------------- cancel / release a class, room change
  async function upcomingClasses() {
    const from = new Date(), to = new Date(); to.setDate(to.getDate() + 21);
    const r = await api(`/api/my/timetable?date_from=${RW.iso(from)}&date_to=${RW.iso(to)}`);
    return r.items.filter(c => c.status === "Scheduled");
  }
  const classLabel = c => `${dayName(c.date)} · ${c.startTime}–${c.endTime} · Room ${c.room} · ${c.courseCode} · ${c.section}`;
  async function cancelDialog() {
    let list; try { list = await upcomingClasses(); } catch (ex) { return err(ex); }
    if (!list.length) return toast("No upcoming classes in your sections.", "error");
    openDialog("Cancel a class", `<form id="rwCancelForm" class="dialog-content"><p class="dialog-message">The class stays in history as <b>Cancelled</b>; its room becomes available immediately and other CRs and admins are notified.</p>
      <label class="field">Class<select name="cls" required>${list.map(c => `<option value="${c.classId}">${esc(classLabel(c))}</option>`).join("")}</select></label>
      <label class="field">Reason (required)<textarea name="reason" rows="3" maxlength="500" required></textarea></label>
      <div class="dialog-actions"><button type="button" class="btn btn-secondary" data-dialog-close>Back</button><button class="btn btn-primary" type="submit">Cancel class &amp; release room</button></div></form>`);
    $("#rwCancelForm").addEventListener("submit", async e => {
      e.preventDefault(); const f = new FormData(e.target), btn = e.submitter; btn.disabled = true;
      try { const r = await api(`/api/classes/${f.get("cls")}/cancel`, { method: "POST", body: { reason: f.get("reason").trim() } }); $("#appDialog").close(); await RW.reload(); toast(`Class cancelled. Room ${r.room_released} is now available.`); }
      catch (ex) { err(ex); btn.disabled = false; }
    });
  }
  async function roomChangeDialog() {
    let list; try { list = await upcomingClasses(); } catch (ex) { return err(ex); }
    if (!list.length) return toast("No upcoming classes in your sections.", "error");
    openDialog("Request a room change", `<form id="rwRcForm" class="dialog-content"><label class="field">Class<select name="cls" required>${list.map(c => `<option value="${c.classId}">${esc(classLabel(c))}</option>`).join("")}</select></label>
      <label class="field">New room<select name="room" required>${RW.catalog.rooms.filter(r => r.status === "Active").map(r => `<option value="${r.room_id}">${esc(r.room_number)} (${r.capacity} seats)</option>`).join("")}</select></label>
      <label class="field">Reason (required)<textarea name="reason" rows="3" maxlength="500" required></textarea></label>
      <div class="dialog-actions"><button type="button" class="btn btn-secondary" data-dialog-close>Back</button><button class="btn btn-primary" type="submit">Send request</button></div></form>`);
    $("#rwRcForm").addEventListener("submit", async e => {
      e.preventDefault(); const f = new FormData(e.target), btn = e.submitter; btn.disabled = true;
      try { await api("/api/requests/room-change", { method: "POST", body: { class_id: Number(f.get("cls")), requested_room_id: Number(f.get("room")), reason: f.get("reason").trim() } }); $("#appDialog").close(); await RW.reload(); toast("Room-change request sent."); }
      catch (ex) { err(ex); btn.disabled = false; }
    });
  }
  if (isStaff()) {
    const bar = $("#page-timetable .heading-actions");
    bar.insertAdjacentHTML("afterbegin", `<button class="btn btn-secondary" id="rwCancelBtn">Cancel a class</button><button class="btn btn-secondary" id="rwRoomChangeBtn">Request room change</button>`);
    $("#rwCancelBtn").addEventListener("click", cancelDialog); $("#rwRoomChangeBtn").addEventListener("click", roomChangeDialog);
  }

  renderScheduleActivity = function () {
    const box = $("#scheduleActivity"); if (!box) return;
    const sub = $(".schedule-activity-panel .panel-heading p"); if (sub) sub.textContent = "Extra classes booked this week";
    const extras = timetableEvents.filter(e => e.origin === "Extra");
    box.innerHTML = extras.length ? extras.map(e => `<article class="schedule-activity-item"><div class="schedule-activity-details"><strong>${esc(e.title)}</strong><span>Room ${esc(e.room)} · ${esc(e.date)} · ${esc(e.startTime)}–${esc(e.endTime)}</span><small>${esc(e.teacher || "Teacher unspecified")} · ${esc(e.section)}</small></div>${ownsSection(e.sectionId) && isStaff() ? `<button type="button" class="btn btn-secondary schedule-undo" data-cancel-class="${e.classId}">Cancel</button>` : ""}</article>`).join("")
      : `<div class="schedule-activity-empty">No extra classes this week.</div>`;
    $$("[data-cancel-class]", box).forEach(b => b.addEventListener("click", () => undoScheduledClass(b.dataset.cancelClass)));
  };
  undoScheduledClass = async function (id) {
    const reason = await askReason("Cancel this class", { confirm: "Cancel class" }); if (!reason) return;
    try { await api(`/api/classes/${id}/cancel`, { method: "POST", body: { reason } }); await RW.reload(); toast("Class cancelled; the room is available again."); } catch (ex) { err(ex); }
  };

  // ---------------------------------------------------------------- ADMIN timetable edit / import -> validated API calls
  persistManagedTimetable = function (rows) {
    if (!isAdmin()) { toast("Only administrators can change the timetable.", "error"); return false; }
    RW.syncRows(rows).then(errors => { if (errors.length) toast(errors[0] + (errors.length > 1 ? ` (+${errors.length - 1} more)` : ""), "error"); })
      .catch(err).finally(() => RW.reload());
    return true;
  };
  RW.syncRows = async function (rows) {
    const errors = [], current = new Map(timetableEvents.map(e => [e.id, e]));
    const mon = new Date(RW.weekStart + "T00:00:00");
    const dateFor = day => { const d = new Date(mon); d.setDate(d.getDate() + day); return RW.iso(d); };
    const body = e => ({ section_id: sectionId(e.section), subject_id: subjectId(e.courseCode), teacher_id: teacherId(e.teacher), room_id: roomId(e.room), date: dateFor(e.day), start: `${pad(e.start)}:00`, end: `${pad(e.start + e.duration)}:00` });
    const complete = (e, b) => { if (!b.section_id) errors.push(`Unknown section "${e.section}".`); else if (!b.subject_id) errors.push(`Unknown subject "${e.courseCode}".`); else if (!b.room_id) errors.push(`Unknown room "${e.room}".`); else return true; };
    const keep = new Set(rows.map(r => r.id));
    for (const [id, e] of current) if (!keep.has(id)) {
      try { await api(`/api/classes/${id}/cancel`, { method: "POST", body: { reason: "Removed by administrator (timetable edit)" } }); } catch (ex) { errors.push(`${e.title}: ${ex.message}`); }
    }
    for (const r of rows) {
      const old = current.get(r.id), b = body(r); if (!complete(r, b)) continue;
      try {
        if (!old) await api("/api/classes", { method: "POST", body: b });
        else if (["room", "day", "start", "duration", "section", "teacher", "courseCode"].some(k => old[k] !== r[k])) await api(`/api/classes/${id_(old)}`, { method: "PUT", body: b });
      } catch (ex) { errors.push(`${r.title || r.courseCode}: ${ex.message}`); }
    }
    return errors;
  };
  const id_ = e => e.classId;

  // ---------------------------------------------------------------- dropdowns fed from the database
  const baseSurfaces = updateAcademicSurfaces;
  updateAcademicSurfaces = function () {
    baseSurfaces();
    const sec = $('#scheduleForm [name="section"]'), prev = sec.value;
    const labels = mySections().map(s => s.label);
    sec.innerHTML = `<option value="">Select section</option>${labels.map(l => `<option>${esc(l)}</option>`).join("")}`;
    if (labels.includes(prev)) sec.value = prev;
    $("#subjectOptions").innerHTML = RW.catalog.subjects.filter(s => s.code !== "UNSPECIFIED").map(s => `<option value="${esc(s.code)}">${esc(s.name)}</option>`).join("");
    $('#scheduleForm [name="teacher"]').innerHTML = `<option value="">Select teacher</option>${RW.catalog.teachers.map(t => `<option>${esc(t.name)}</option>`).join("")}`;
  };

  // ---------------------------------------------------------------- notifications + user chip
  async function refreshNotifications() {
    try { const n = await api("/api/notifications?limit=1"); const b = $("#rwBellCount"); b.textContent = n.unread; b.hidden = !n.unread; } catch (_) { /* transient */ }
  }
  async function openNotifications() {
    try {
      const n = await api("/api/notifications?limit=50");
      openDialog("Notifications", `<div class="rw-notes">${n.items.length ? n.items.map(i => `<div class="rw-note ${i.is_read ? "" : "unread"}"><small>${esc(new Date(i.created_at + "Z").toLocaleString())} · ${esc(i.type.replace(/_/g, " ").toLowerCase())}</small><p>${esc(i.message)}</p></div>`).join("") : "<p class=\"dialog-message\">Nothing yet.</p>"}</div><div class="dialog-actions"><button class="btn btn-secondary" data-dialog-close>Close</button><button class="btn btn-primary" id="rwReadAll">Mark all read</button></div>`);
      $("#rwReadAll").addEventListener("click", async () => { await api("/api/notifications/read-all", { method: "POST" }); $("#appDialog").close(); refreshNotifications(); });
    } catch (ex) { err(ex); }
  }
  const top = $(".top-actions"), status = $("#apiStatus");
  status.textContent = "Live · MySQL"; status.title = "Data is stored in the shared MySQL database";
  top.insertAdjacentHTML("beforeend", `<button class="rw-bell" id="rwBell" aria-label="Notifications" title="Notifications">🔔<b id="rwBellCount" hidden>0</b></button><div class="rw-user"><span><strong>${esc(RW.user.full_name)}</strong><small>${esc(role())}${RW.sections.length ? " · " + RW.sections.length + " section" + (RW.sections.length > 1 ? "s" : "") : ""}</small></span><button class="btn btn-secondary" id="rwLogout">Sign out</button></div>`);
  $("#rwBell").addEventListener("click", openNotifications); $("#rwLogout").addEventListener("click", RW.logout);
  document.body.classList.add("role-" + role().toLowerCase());
  setInterval(refreshNotifications, 60000); refreshNotifications();

  // ---------------------------------------------------------------- role-aware chrome (display only)
  if (!isStaff()) { ["requests", "schedule"].forEach(p => $(`.nav-item[data-page="${p}"]`)?.remove()); }
  if (!isAdmin()) { $(`.nav-item[data-page="academics"]`)?.remove(); $("#timetableEditToggle").hidden = true; }
  $("#page-schedule .page-heading p").textContent = isAdmin() ? "Compare every room for a date and time, then book directly." : "Compare rooms for a date and time, then send a request to the owning CR.";

  // ---------------------------------------------------------------- ADMIN console (validated DML only; no SQL box)
  if (isAdmin()) buildAdmin();
  function buildAdmin() {
    $$(".nav")[1].insertAdjacentHTML("afterbegin", `<button class="nav-item" data-page="admin"><span class="nav-icon">⚙</span>Administration</button>`);
    $(".content").insertAdjacentHTML("beforeend", `<section class="page" id="page-admin"><div class="page-heading"><div><div class="eyebrow">ADMINISTRATION</div><h1>Manage operational data</h1><p>Every change is validated by the server and written to the audit log. Schema changes are done by migration scripts, not here.</p></div></div><div class="request-tabs" id="rwAdminTabs"></div><section class="panel"><div class="panel-heading"><div><h2 id="rwAdminTitle"></h2></div><button class="btn btn-primary" id="rwAdminAdd">＋ Add</button></div><div class="table-wrap"><table><thead id="rwAdminHead"></thead><tbody id="rwAdminBody"></tbody></table></div></section></section>`);
    $(`.nav-item[data-page="admin"]`).addEventListener("click", () => { go("admin"); openTab(currentTab); });
    const f = (name, label, type = "text", options) => ({ name, label, type, options });
    const brOpts = () => RW.catalog.branches.map(b => [b.branch_id, b.code]);
    const refreshCatalog = async () => { await RW.loadCatalog(); updateAcademicSurfaces(); };
    const TABS = {
      rooms: { label: "Rooms", load: async () => (await api("/api/rooms?limit=200")).items, cols: [["room_number", "Room"], ["block", "Block"], ["room_type", "Type"], ["capacity", "Seats"], ["status", "Status"], ["features", "Features"]],
        fields: () => [f("block", "Block"), f("room_number", "Room number"), f("capacity", "Capacity", "number"), f("room_type", "Type", "select", ["Classroom", "Laboratory", "Seminar Hall"]), f("status", "Status", "select", ["Active", "Maintenance", "Inactive"])], create: "/api/admin/rooms",
        actions: [["Edit", row => form_("Edit room " + row.room_number, [f("capacity", "Capacity", "number"), f("status", "Status", "select", ["Active", "Maintenance", "Inactive"])], row, b => api(`/api/admin/rooms/${row.room_id}`, { method: "PATCH", body: b }))],
          ["Features", async row => { const have = (row.features || "").split(", "); openFeatures(row, have); }]] },
      features: { label: "Features", load: async () => (await api("/api/features")).items, cols: [["name", "Feature"]], fields: () => [f("name", "Name")], create: "/api/admin/features" },
      branches: { label: "Branches", load: async () => (await api("/api/branches")).items, cols: [["code", "Code"], ["name", "Name"]], fields: () => [f("code", "Code"), f("name", "Name")], create: "/api/admin/branches" },
      sections: { label: "Sections", load: async () => (await api("/api/sections")).items, cols: [["label", "Section"], ["branch", "Branch"], ["semester", "Sem"], ["strength", "Students"], ["status", "Status"]],
        fields: () => [f("branch_id", "Branch", "select", brOpts()), f("semester", "Semester", "number"), f("section_no", "Section number", "number"), f("strength", "Students", "number")], create: "/api/admin/sections",
        actions: [["Edit", row => form_("Edit " + row.label, [f("strength", "Students", "number"), f("status", "Status", "select", ["Active", "Inactive"])], row, b => api(`/api/admin/sections/${row.section_id}`, { method: "PATCH", body: b }))]] },
      subjects: { label: "Subjects", load: async () => (await api("/api/subjects")).items, cols: [["code", "Code"], ["name", "Name"]], fields: () => [f("code", "Code"), f("name", "Name"), f("branch_id", "Branch", "select", [["", "—"], ...brOpts()])], create: "/api/admin/subjects" },
      teachers: { label: "Teachers", load: async () => (await api("/api/teachers")).items, cols: [["name", "Name"]], fields: () => [f("name", "Name"), f("email", "Email (optional)")], create: "/api/admin/teachers" },
      assignments: { label: "CR assignments", load: async () => (await api("/api/admin/cr-assignments")).items, cols: [["full_name", "User"], ["username", "Username"], ["section", "Section"], ["assigned_by", "Assigned by"], ["assigned_at", "Since"]],
        fields: async () => { const users = (await api("/api/admin/users?limit=200")).items.filter(u => u.role !== "ADMIN" && u.is_active); return [f("user_id", "User", "select", users.map(u => [u.user_id, `${u.full_name} (${u.username})`])), f("section_id", "Section", "select", RW.catalog.sections.map(s => [s.section_id, s.label]))]; }, create: "/api/admin/cr-assignments",
        actions: [["Revoke", async row => { if (confirm(`Revoke ${row.username} from ${row.section}?`)) { await api(`/api/admin/cr-assignments/${row.assignment_id}`, { method: "DELETE" }); openTab("assignments"); toast("CR assignment revoked."); } }]] },
      users: { label: "Users", load: async () => (await api("/api/admin/users?limit=200")).items, cols: [["username", "Username"], ["full_name", "Name"], ["email", "Email"], ["role", "Role"], ["is_active", "Active"], ["last_login_at", "Last login"]],
        actions: [["Enable/Disable", async row => { await api(`/api/admin/users/${row.user_id}`, { method: "PATCH", body: { is_active: !row.is_active } }); openTab("users"); }],
          ["Make ADMIN", async row => { if (confirm(`Grant ADMIN to ${row.username}?`)) { await api(`/api/admin/users/${row.user_id}`, { method: "PATCH", body: { role: "ADMIN" } }); openTab("users"); } }]] },
      timetables: { label: "Timetables", load: async () => (await api("/api/admin/timetables")).items, cols: [["name", "Name"], ["status", "Status"], ["effective_from", "From"], ["effective_to", "To"], ["slots", "Slots"]],
        fields: () => [f("name", "Name"), f("effective_from", "Effective from", "date"), f("effective_to", "Effective to", "date")], create: "/api/admin/timetables",
        actions: [["Publish", async row => { await api(`/api/admin/timetables/${row.timetable_id}/publish`, { method: "POST" }); openTab("timetables"); toast("Published and validated."); }],
          ["Archive", async row => { await api(`/api/admin/timetables/${row.timetable_id}/archive`, { method: "POST" }); openTab("timetables"); }]] },
      audit: { label: "Audit log", load: async () => (await api("/api/admin/audit?limit=100")).items.map(a => ({ ...a, details: a.details ? JSON.stringify(a.details).slice(0, 90) : "" })), cols: [["created_at", "When"], ["actor", "Actor"], ["action", "Action"], ["entity_type", "Entity"], ["entity_id", "Id"], ["details", "Details"]] },
    };
    let currentTab = "rooms";
    $("#rwAdminTabs").innerHTML = Object.entries(TABS).map(([k, t]) => `<button data-tab="${k}">${t.label}</button>`).join("");
    $$("#rwAdminTabs button").forEach(b => b.addEventListener("click", () => openTab(b.dataset.tab)));
    async function openTab(key) {
      currentTab = key; const t = TABS[key];
      $$("#rwAdminTabs button").forEach(b => b.classList.toggle("active", b.dataset.tab === key));
      $("#rwAdminTitle").textContent = t.label; $("#rwAdminAdd").hidden = !t.create;
      $("#rwAdminHead").innerHTML = `<tr>${t.cols.map(c => `<th>${esc(c[1].toUpperCase())}</th>`).join("")}${t.actions ? "<th></th>" : ""}</tr>`;
      $("#rwAdminBody").innerHTML = `<tr><td colspan="9" class="empty-row">Loading…</td></tr>`;
      try {
        const rows = await t.load();
        $("#rwAdminBody").innerHTML = rows.length ? rows.map((r, i) => `<tr>${t.cols.map(c => `<td>${esc(typeof r[c[0]] === "boolean" ? (r[c[0]] ? "yes" : "no") : r[c[0]] === 1 && c[0] === "is_active" ? "yes" : r[c[0]] === 0 && c[0] === "is_active" ? "no" : r[c[0]] ?? "—")}</td>`).join("")}${t.actions ? `<td>${t.actions.map((a, j) => `<button class="row-more" data-row="${i}" data-act="${j}">${esc(a[0])}</button>`).join(" ")}</td>` : ""}</tr>`).join("") : `<tr><td colspan="9" class="empty-row">Nothing here yet.</td></tr>`;
        $$("#rwAdminBody [data-act]").forEach(b => b.addEventListener("click", async () => { try { await t.actions[b.dataset.act][1](rows[b.dataset.row]); } catch (ex) { err(ex); } }));
      } catch (ex) { $("#rwAdminBody").innerHTML = `<tr><td colspan="9" class="empty-row">${esc(ex.message)}</td></tr>`; }
    }
    $("#rwAdminAdd").addEventListener("click", async () => {
      const t = TABS[currentTab], fields = await t.fields();
      form_(`Add — ${t.label}`, fields, {}, b => api(t.create, { method: "POST", body: b }), async () => { await refreshCatalog(); openTab(currentTab); });
    });
    function form_(title, fields, initial, submit, after) {
      openDialog(title, `<form id="rwAdminForm" class="dialog-content">${fields.map(fl => `<label class="field">${esc(fl.label)}${fl.type === "select"
        ? `<select name="${fl.name}">${fl.options.map(o => { const [v, l] = Array.isArray(o) ? o : [o, o]; return `<option value="${esc(v)}" ${String(initial[fl.name] ?? "") === String(v) ? "selected" : ""}>${esc(l)}</option>`; }).join("")}</select>`
        : `<input name="${fl.name}" type="${fl.type}" value="${esc(initial[fl.name] ?? "")}">`}</label>`).join("")}<div class="dialog-actions"><button type="button" class="btn btn-secondary" data-dialog-close>Cancel</button><button class="btn btn-primary" type="submit">Save</button></div></form>`);
      $("#rwAdminForm").addEventListener("submit", async e => {
        e.preventDefault(); const body = {};
        fields.forEach(fl => { let v = new FormData(e.target).get(fl.name); if (v === "" || v === null) return; if (fl.type === "number" || /_id$/.test(fl.name)) v = Number(v); body[fl.name] = v; });
        try { await submit(body); $("#appDialog").close(); toast("Saved."); await (after ? after() : (refreshCatalog(), openTab(currentTab))); } catch (ex) { err(ex); }
      });
    }
    function openFeatures(row, have) {
      const all = RW.catalog.features;
      openDialog(`Features — room ${row.room_number}`, `<form id="rwFeatForm" class="dialog-content">${all.map(x => `<label class="field" style="flex-direction:row;gap:8px"><input type="checkbox" name="f" value="${x.feature_id}" ${have.includes(x.name) ? "checked" : ""}> ${esc(x.name)}</label>`).join("")}<div class="dialog-actions"><button type="button" class="btn btn-secondary" data-dialog-close>Cancel</button><button class="btn btn-primary" type="submit">Save</button></div></form>`);
      $("#rwFeatForm").addEventListener("submit", async e => { e.preventDefault(); try { await api(`/api/admin/rooms/${row.room_id}/features`, { method: "PUT", body: { feature_ids: new FormData(e.target).getAll("f").map(Number) } }); $("#appDialog").close(); await refreshCatalog(); openTab("rooms"); toast("Features saved."); } catch (ex) { err(ex); } });
    }
  }

  // ---------------------------------------------------------------- cosmetic text that referred to browser storage
  $(".prototype-note")?.remove();
  const tips = $(".tips-panel"); if (tips) tips.querySelector("ul").innerHTML = "<li>Pick the date: availability is read from the live database for that week.</li><li>Room, teacher and section clashes, capacity and room status are checked on the server.</li>";
  updateAcademicSurfaces(); renderScheduleActivity(); renderRequests();
})();
