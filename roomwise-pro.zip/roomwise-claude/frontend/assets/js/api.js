/* Roomwise API bridge: session auth, CSRF, data bootstrap. Loaded BEFORE app.js.
   Identity/role shown here is for display only - the server re-checks everything on each request. */
(function () {
  const RW = (window.RW = { user: null, csrf: null, sections: [], mySectionIds: null, catalog: {}, weekStart: null });
  const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  RW.esc = esc;

  RW.api = async function (path, { method = "GET", body } = {}) {
    const headers = {};
    if (body !== undefined) headers["Content-Type"] = "application/json";
    if (RW.csrf && method !== "GET") headers["X-CSRF-Token"] = RW.csrf;
    let res;
    try { res = await fetch(path, { method, headers, credentials: "same-origin", body: body === undefined ? undefined : JSON.stringify(body) }); }
    catch (e) { const err = new Error("Cannot reach the server. Is the backend running?"); err.network = true; throw err; }
    let data = null;
    try { data = await res.json(); } catch (_) { /* empty body */ }
    if (!res.ok) {
      const err = new Error(data?.error?.message || `Request failed (${res.status})`);
      err.status = res.status; err.details = data?.error?.details;
      if (data?.error?.code === "validation_error" && Array.isArray(data.error.details))
        err.message = data.error.details.map(d => `${d.field}: ${d.message}`).join("; ");
      if (res.status === 401 && !path.startsWith("/api/auth/")) RW.showLogin("Your session has expired. Please sign in again.");
      throw err;
    }
    return data;
  };

  function adopt(session) {
    RW.user = session.user; RW.csrf = session.csrf_token;
    RW.sections = session.assigned_sections || [];
  }

  RW.showLogin = function (notice) {
    return new Promise(resolve => {
      document.getElementById("rwAuth")?.remove();
      const el = document.createElement("div");
      el.id = "rwAuth"; el.className = "rw-auth";
      el.innerHTML = `<div class="rw-auth-card" role="dialog" aria-modal="true" aria-label="Sign in">
        <div class="brand"><div class="brand-mark"><span></span><span></span><span></span><span></span></div><div><strong>roomwise</strong><small>Campus operations</small></div></div>
        <h2 id="rwAuthTitle">Sign in</h2>
        <p class="rw-auth-note" id="rwAuthNote">${esc(notice || "Sign in to view timetables and room availability.")}</p>
        <form id="rwAuthForm" novalidate>
          <label class="field" data-signup hidden>Full name<input name="full_name" autocomplete="name" maxlength="120"></label>
          <label class="field">Username<input name="username" required autocomplete="username" maxlength="50"></label>
          <label class="field" data-signup hidden>Email<input name="email" type="email" autocomplete="email" maxlength="255"></label>
          <label class="field">Password<input name="password" type="password" required autocomplete="current-password" maxlength="128"></label>
          <div class="rw-auth-error" id="rwAuthError" role="alert"></div>
          <button class="btn btn-primary" type="submit" id="rwAuthSubmit">Sign in</button>
        </form>
        <button class="rw-auth-switch" id="rwAuthSwitch" type="button">New here? Create a viewer account</button>
        <small class="rw-auth-foot">New accounts are read-only viewers. Only an administrator can grant CR access.</small></div>`;
      document.body.append(el);
      let signup = false;
      const form = el.querySelector("#rwAuthForm"), err = el.querySelector("#rwAuthError");
      const sync = () => {
        el.querySelectorAll("[data-signup]").forEach(n => (n.hidden = !signup));
        el.querySelector("#rwAuthTitle").textContent = signup ? "Create viewer account" : "Sign in";
        el.querySelector("#rwAuthSubmit").textContent = signup ? "Create account" : "Sign in";
        el.querySelector("#rwAuthSwitch").textContent = signup ? "Have an account? Sign in" : "New here? Create a viewer account";
        form.password.autocomplete = signup ? "new-password" : "current-password";
        err.textContent = "";
      };
      el.querySelector("#rwAuthSwitch").onclick = () => { signup = !signup; sync(); };
      form.onsubmit = async e => {
        e.preventDefault(); err.textContent = "";
        const f = Object.fromEntries(new FormData(form));
        const btn = el.querySelector("#rwAuthSubmit"); btn.disabled = true;
        try {
          const session = signup
            ? await RW.api("/api/auth/signup", { method: "POST", body: { username: f.username, email: f.email, full_name: f.full_name, password: f.password } })
            : await RW.api("/api/auth/login", { method: "POST", body: { username: f.username, password: f.password } });
          adopt(session); el.remove();
          if (RW.booted) location.reload(); else resolve();
        } catch (ex) { err.textContent = ex.message; btn.disabled = false; }
      };
      form.username.focus();
    });
  };

  RW.logout = async function () {
    try { await RW.api("/api/auth/logout", { method: "POST" }); } catch (_) { /* already gone */ }
    location.reload();
  };

  RW.mondayOf = function (d) {
    const x = new Date(d.getFullYear(), d.getMonth(), d.getDate()); x.setDate(x.getDate() - ((x.getDay() + 6) % 7)); return x;
  };
  RW.iso = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;

  // ---- request rows from the API -> the shape the existing Requests table renders
  RW.mapRequest = r => ({
    id: `${r.kind}-${r.id}`, kind: r.kind, rawId: r.id, request: r.title, requestedBy: r.requested_by, requesterSection: r.requester_section,
    targetSection: r.target_section, recipientRole: r.recipient_role, date: r.date, day: (new Date(r.date + "T00:00:00").getDay() + 6) % 7,
    start: Number(String(r.start_time).slice(0, 2)), startTime: r.start_time, endTime: r.end_time, room: r.room, status: r.status,
    note: r.note || "", decisionReason: r.decision_reason || "", decidedBy: r.decided_by || "", type: r.type, canDecide: r.can_decide,
    canWithdraw: r.can_withdraw, createdAt: r.created_at,
  });

  RW.loadWeekData = async function (weekStartIso) {
    const q = weekStartIso ? `?week_start=${weekStartIso}` : "";
    const data = await RW.api("/api/events" + q);
    RW.weekStart = data.week_start; RW.cancelledThisWeek = data.cancelled || [];
    return data.events;
  };

  RW.loadCatalog = async function () {
    const [sec, sub, tea, rooms, feats, br] = await Promise.all([
      RW.api("/api/sections"), RW.api("/api/subjects"), RW.api("/api/teachers"), RW.api("/api/rooms?limit=200"),
      RW.api("/api/features"), RW.api("/api/branches")]);
    RW.catalog = { sections: sec.items, subjects: sub.items, teachers: tea.items, rooms: rooms.items, features: feats.items, branches: br.items };
    RW.mySectionIds = sec.my_section_ids;      // null => ADMIN (all)
  };

  RW.loadRequests = async function () {
    if (!RW.user || RW.user.role === "VIEWER") return [];
    return (await RW.api("/api/requests?limit=200")).items.map(RW.mapRequest);
  };

  RW.loadScripts = function (list) {
    return list.reduce((p, src) => p.then(() => new Promise((ok, fail) => {
      const s = document.createElement("script"); s.src = src; s.onload = ok; s.onerror = () => fail(new Error("Failed to load " + src)); document.body.append(s);
    })), Promise.resolve());
  };

  RW.start = async function () {
    try { adopt(await RW.api("/api/auth/me")); }
    catch (e) {
      if (e.network) { document.body.insertAdjacentHTML("beforeend", `<div class="rw-auth"><div class="rw-auth-card"><h2>Backend unreachable</h2><p class="rw-auth-note">${esc(e.message)} Start it with <code>uvicorn app.main:app</code> and open the site from that address.</p></div></div>`); throw e; }
      await RW.showLogin();
    }
    await RW.loadCatalog();
    window.RW_BOOT = { events: await RW.loadWeekData(), requests: await RW.loadRequests(), user: RW.user };
    RW.booted = true;
  };
})();
