/* Roomwise: Daily Schedule + Pending Rescheduling. Loaded AFTER integration.js; reuses its globals ($, $$, go, toast, openDialog)
   and the existing page/nav/table/pill conventions. Role checks here only decide what to SHOW; the server enforces every permission
   (POST /api/displaced-classes/{id}/reschedule re-validates room, teacher and section conflicts and the caller's section). */
(function () {
  const { api, esc } = RW;
  const role = () => RW.user.role;
  const isStaff = () => role() === "ADMIN" || role() === "CR";
  const ownsSection = id => role() === "ADMIN" || (RW.mySectionIds || []).includes(id);
  const err = e => toast(e.message || "Something went wrong.", "error");
  const t5 = v => String(v || "").slice(0, 5);
  const longDate = iso => new Date(iso + "T00:00:00").toLocaleDateString(undefined, { weekday: "long", day: "numeric", month: "long", year: "numeric" });
  const shortDate = iso => new Date(iso + "T00:00:00").toLocaleDateString(undefined, { weekday: "short", day: "2-digit", month: "short" });
  const PILL = { scheduled: ["pill-scheduled", "Scheduled"], cancelled: ["pill-cancelled", "Cancelled"], displaced: ["pill-displaced", "Displaced"], rescheduled: ["pill-rescheduled", "Rescheduled"], completed: ["pill-completed", "Completed"] };

  // ---------------------------------------------------------------- shell: nav items + pages
  $(`.nav-item[data-page="timetable"]`).insertAdjacentHTML("afterend", `<button class="nav-item" data-page="daily"><span class="nav-icon">◷</span>Daily schedule</button>`);
  if (isStaff()) $(`.nav-item[data-page="requests"]`)?.insertAdjacentHTML("afterend",
    `<button class="nav-item" data-page="pending"><span class="nav-icon">↺</span>Pending rescheduling<span class="dot-count" id="rwPendingCount" hidden>0</span></button>`);
  $$(`.nav-item[data-page="daily"], .nav-item[data-page="pending"]`).forEach(b => b.addEventListener("click", () => {
    go(b.dataset.page); $("#breadcrumbCurrent").textContent = b.dataset.page === "daily" ? "Daily schedule" : "Pending rescheduling";   // the badge text must not leak into the breadcrumb
    b.dataset.page === "daily" ? loadDaily() : loadPending();
  }));

  $(".content").insertAdjacentHTML("beforeend", `
    <section class="page" id="page-daily">
      <div class="page-heading"><div><div class="eyebrow"><span class="live-dot"></span> LIVE DAILY UPDATES</div><h1>Daily schedule</h1>
        <p>The actual schedule for one date: original classes, cancellations, displaced and rescheduled classes, extra classes and room changes. The weekly timetable itself is never changed by these.</p></div>
        <div class="heading-actions"><button class="btn btn-secondary" id="dlyPrev" aria-label="Previous day">←</button><input type="date" id="dlyDate" class="dly-date" aria-label="Date"><button class="btn btn-secondary" id="dlyNext" aria-label="Next day">→</button><button class="btn btn-secondary" id="dlyToday">Today</button></div></div>
      <section class="panel directory-panel">
        <div class="filter-bar"><strong id="dlyTitle" class="dly-title"></strong><select id="dlySection" aria-label="Filter by section"></select><span class="dly-counts" id="dlyCounts"></span></div>
        <div class="table-wrap"><table><thead><tr><th>TIME</th><th>ROOM</th><th>SECTION</th><th>SUBJECT</th><th>TEACHER</th><th>STATUS</th><th></th></tr></thead><tbody id="dlyBody"></tbody></table></div>
        <div class="calendar-legend"><span><i class="legend-box dly-k-scheduled"></i>Scheduled</span><span><i class="legend-box dly-k-cancelled"></i>Cancelled</span><span><i class="legend-box dly-k-displaced"></i>Displaced / awaiting rescheduling</span><span><i class="legend-box dly-k-rescheduled"></i>Rescheduled</span><span><i class="legend-box dly-k-completed"></i>Completed</span></div>
      </section>
    </section>
    ${isStaff() ? `<section class="page" id="page-pending">
      <div class="page-heading"><div><div class="eyebrow">WORKFLOW MANAGEMENT</div><h1>Pending rescheduling</h1>
        <p>Classes that lost their room to an approved request. Find a free room for the exact same date and time and reschedule. The original class stays on record as cancelled.</p></div></div>
      <div class="request-tabs" id="pendTabs"><button class="active" data-pend="Awaiting">Awaiting rescheduling</button><button data-pend="Rescheduled">Rescheduled</button><button data-pend="Dismissed">Dismissed</button></div>
      <section class="panel requests-table-panel"><div class="table-wrap"><table><thead><tr><th>ORIGINAL CLASS</th><th>DATE &amp; TIME</th><th>ORIGINAL ROOM</th><th>REASON</th><th>STATUS</th><th>ACTION</th></tr></thead><tbody id="pendBody"></tbody></table></div></section>
    </section>` : ""}`);

  // ---------------------------------------------------------------- Daily Schedule
  let dailyDate = RW.iso(new Date()), dailySection = "", dailyItems = [];
  const dateInput = $("#dlyDate"); dateInput.value = dailyDate;
  const secOpts = () => (role() === "CR" ? RW.catalog.sections.filter(s => ownsSection(s.section_id)) : RW.catalog.sections.filter(s => s.status === "Active"));
  function fillSections() {
    $("#dlySection").innerHTML = `<option value="">${role() === "CR" ? "My sections" : "All sections"}</option>` + secOpts().map(s => `<option value="${s.section_id}">${esc(s.label)}</option>`).join("");
    $("#dlySection").value = dailySection;
  }
  fillSections();
  const shift = n => { const d = new Date(dailyDate + "T00:00:00"); d.setDate(d.getDate() + n); dailyDate = RW.iso(d); dateInput.value = dailyDate; loadDaily(); };
  $("#dlyPrev").addEventListener("click", () => shift(-1)); $("#dlyNext").addEventListener("click", () => shift(1));
  $("#dlyToday").addEventListener("click", () => { dailyDate = RW.iso(new Date()); dateInput.value = dailyDate; loadDaily(); });
  dateInput.addEventListener("change", () => { if (dateInput.value) { dailyDate = dateInput.value; loadDaily(); } });
  $("#dlySection").addEventListener("change", e => { dailySection = e.target.value; loadDaily(); });

  async function loadDaily() {
    $("#dlyTitle").textContent = longDate(dailyDate);
    try {
      const data = await api(`/api/daily-schedule?date=${dailyDate}${dailySection ? `&section_id=${dailySection}` : ""}`);
      if (data.date !== dailyDate) return;                                  // a newer request already replaced this one
      $("#dlyCounts").innerHTML = Object.entries(PILL).map(([k, [cls, label]]) => `<span class="pill ${cls}">${esc(label)} ${data.counts[k] || 0}</span>`).join(" ");
      dailyItems = data.items;
      $("#dlyBody").innerHTML = data.items.length ? data.items.map(row).join("") : `<tr><td colspan="7" class="empty-row">No classes on this date${role() === "CR" ? " for your sections" : ""}.</td></tr>`;
      $$("[data-dly-reschedule]").forEach(b => b.addEventListener("click", () => openReschedule(Number(b.dataset.dlyReschedule))));
    } catch (e) { $("#dlyBody").innerHTML = `<tr><td colspan="7" class="empty-row">${esc(e.message)}</td></tr>`; }
  }
  function row(r) {
    const [cls, label] = PILL[r.status] || PILL.scheduled;
    const dim = r.status === "cancelled" || r.status === "displaced" ? " dly-dim" : "";
    const act = r.status === "displaced" && r.displaced_state === "Awaiting" && isStaff() && ownsSection(r.section_id)
      ? `<button type="button" class="btn btn-primary request-action" data-dly-reschedule="${r.displaced_id}">Find a room</button>` : "";
    return `<tr class="dly-row dly-${esc(r.status)}" data-class-id="${esc(r.class_id)}" tabindex="0" role="button" aria-label="Class details: ${esc(r.subject_code)} ${esc(t5(r.start_time))}"><td><strong>${esc(t5(r.start_time))}–${esc(t5(r.end_time))}</strong></td>
      <td><span class="room-pill">${esc(r.room_number)}</span></td><td>${esc(r.section_label)}</td>
      <td class="${dim.trim()}"><strong>${esc(r.subject_code)}</strong><small class="request-subtext">${esc(r.subject_name || "")}</small></td>
      <td>${esc(r.teacher_name || "—")}</td>
      <td><span class="pill ${cls}">${esc(r.status === "displaced" ? r.status_label : label)}</span>${r.note ? `<small class="request-subtext">${esc(r.note)}</small>` : ""}</td><td>${act}</td></tr>`;
  }

  // ---- click / Enter on a row -> class details (buttons inside the row keep their own action)
  const openRow = el => { const r = dailyItems.find(x => String(x.class_id) === el.dataset.classId); if (r) classDetails(r); };
  $("#dlyBody").addEventListener("click", e => { const tr = e.target.closest("tr[data-class-id]"); if (tr && !e.target.closest("button")) openRow(tr); });
  $("#dlyBody").addEventListener("keydown", e => { if ((e.key === "Enter" || e.key === " ") && e.target.matches("tr[data-class-id]")) { e.preventDefault(); openRow(e.target); } });
  // The SERVER decides: can_cancel mirrors workflow.cancel_class (ADMIN/CR, CR only in own section, DB status Scheduled - which includes a rescheduled
  // booking - and not a past date). POST /api/classes/{id}/cancel re-checks everything anyway.
  const canCancel = r => r.can_cancel === true;
  function classDetails(r) {
    const line = (k, v) => `<div><strong>${k}:</strong> ${esc(v)}</div>`;
    openDialog("Class details", `<div class="dialog-content"><div class="dialog-list" id="clsInfo">
      ${line("Subject", `${r.subject_code}${r.subject_name ? " · " + r.subject_name : ""}`)}${line("Section", r.section_label)}${line("Teacher", r.teacher_name || "—")}
      ${line("Room", r.room_number)}${line("Date", longDate(r.class_date))}${line("Time", `${t5(r.start_time)}–${t5(r.end_time)}`)}${line("Status", r.status_label)}${r.note ? line("Note", r.note) : ""}</div>
      <div class="dialog-actions"><button class="btn btn-secondary" data-dialog-close>Close</button>${canCancel(r) ? `<button class="btn btn-primary" id="clsCancel">Cancel class</button>` : ""}</div></div>`);
    $("#clsCancel")?.addEventListener("click", () => {
      $("#dialogBody").innerHTML = `<form class="dialog-content" id="clsCancelForm"><p class="dialog-message">${esc(r.subject_code)} · ${esc(r.section_label)} · Room ${esc(r.room_number)} · ${esc(shortDate(r.class_date))} ${esc(t5(r.start_time))}. The class stays on record as cancelled and the room is free for that date and time.</p>
        <label class="field">Reason (required)<textarea name="reason" id="clsReason" rows="3" required minlength="3" maxlength="500"></textarea></label>
        <div class="dialog-actions"><button type="button" class="btn btn-secondary" data-dialog-close>Keep class</button><button class="btn btn-primary" id="clsCancelGo">Cancel class</button></div></form>`;
      $$("#dialogBody [data-dialog-close]").forEach(b => b.addEventListener("click", () => $("#appDialog").close()));
      $("#clsCancelForm").addEventListener("submit", async e => {
        e.preventDefault(); const reason = $("#clsReason").value.trim();
        if (reason.length < 3) return toast("Please give a reason for the cancellation.", "error");
        $("#clsCancelGo").disabled = true;
        try {
          await api(`/api/classes/${r.class_id}/cancel`, { method: "POST", body: { reason } });          // existing endpoint: auth + notifications live there
          $("#appDialog").close(); toast("Class cancelled. The room is free for that date and time.");
          await Promise.all([loadDaily(), loadPending(), refreshBell()]);
        } catch (er) { err(er); $("#clsCancelGo").disabled = false; loadDaily(); }
      });
    });
  }

  // ---------------------------------------------------------------- Pending Rescheduling
  let pendFilter = "Awaiting";
  $$("#pendTabs button").forEach(b => b.addEventListener("click", () => { pendFilter = b.dataset.pend; $$("#pendTabs button").forEach(x => x.classList.toggle("active", x === b)); loadPending(); }));
  async function refreshPendingBadge() {
    if (!isStaff()) return;
    try { const n = (await api("/api/displaced-classes?status=Awaiting&limit=200")).items.length; const b = $("#rwPendingCount"); b.textContent = n; b.hidden = !n; } catch (_) { /* transient */ }
  }
  async function loadPending() {
    if (!isStaff()) return;
    try {
      const items = (await api(`/api/displaced-classes?status=${pendFilter}&limit=200`)).items;
      $("#pendBody").innerHTML = items.length ? items.map(i => `<tr>
        <td><strong>${esc(i.subject_code)}</strong><small class="request-subtext">${esc(i.section_label)}${i.teacher_name ? " · " + esc(i.teacher_name) : ""}</small></td>
        <td>${esc(shortDate(i.class_date))} · ${esc(t5(i.start_time))}–${esc(t5(i.end_time))}</td>
        <td><span class="room-pill">${esc(i.original_room)}</span></td>
        <td class="dly-reason">${esc(i.reason)}<small class="request-subtext">Requested by ${esc(i.requested_by)} (${esc(i.requesting_section)})</small></td>
        <td><span class="pill ${{ Awaiting: "pill-displaced", Rescheduled: "pill-rescheduled", Dismissed: "pill-cancelled" }[i.displacement_status]}">${esc(i.status_label)}</span>${i.new_room ? `<small class="request-subtext">Now in room ${esc(i.new_room)}</small>` : ""}${i.displacement_status === "Dismissed" ? `<small class="request-subtext">by ${esc(i.dismissed_by || "a user")} · ${esc(String(i.dismissed_at || "").replace("T", " ").slice(0, 16))}</small>` : ""}</td>
        <td>${i.displacement_status !== "Awaiting" ? `<span class="request-final">${i.displacement_status === "Dismissed" ? "Dismissed" : "Done"}</span>`
          : `<div class="request-actions">${i.can_reschedule ? `<button type="button" class="btn btn-primary request-action" data-reschedule="${i.displacement_id}">Find available rooms</button>` : `<span class="request-final">Date has passed</span>`}${i.can_dismiss ? `<button type="button" class="btn btn-secondary request-action" data-dismiss="${i.displacement_id}">Dismiss</button>` : ""}</div>`}</td></tr>`).join("")
        : `<tr><td colspan="6" class="empty-row">${{ Awaiting: "Nothing is waiting to be rescheduled.", Rescheduled: "No rescheduled classes yet.", Dismissed: "No dismissed classes." }[pendFilter]}</td></tr>`;
      $$("[data-reschedule]").forEach(b => b.addEventListener("click", () => openReschedule(Number(b.dataset.reschedule))));
      $$("[data-dismiss]").forEach(b => b.addEventListener("click", () => openDismiss(Number(b.dataset.dismiss), items.find(x => x.displacement_id === Number(b.dataset.dismiss)))));
    } catch (e) { $("#pendBody").innerHTML = `<tr><td colspan="6" class="empty-row">${esc(e.message)}</td></tr>`; }
    refreshPendingBadge();
  }

  // ---------------------------------------------------------------- find rooms for the SAME date/time -> reschedule
  async function openReschedule(id) {
    let av, info;
    try {
      [av, info] = await Promise.all([api(`/api/displaced-classes/${id}/available-rooms`),
        api("/api/displaced-classes?limit=200").then(r => r.items.find(x => x.displacement_id === id))]);
    } catch (e) { return err(e); }
    const head = info ? `<p class="dialog-message"><strong>${esc(info.subject_code)}</strong> · ${esc(info.section_label)}<br>${esc(longDate(av.date))}, ${esc(av.start)}–${esc(av.end)}<br>Original room ${esc(info.original_room)} was allocated to ${esc(info.requesting_section)}.</p>`
      : `<p class="dialog-message">${esc(longDate(av.date))}, ${esc(av.start)}–${esc(av.end)}</p>`;
    const list = av.rooms.length
      ? `<div class="dialog-list">${av.rooms.map(r => `<div class="dly-room"><span><strong>Room ${esc(r.room_number)}</strong><small>${esc(r.block)} · ${esc(r.room_type)} · seats ${esc(r.capacity)}</small></span><button type="button" class="btn btn-primary" data-pick-room="${r.room_id}">Reschedule here</button></div>`).join("")}</div>`
      : `<p class="dialog-message">No room is free for this exact date and time.${av.blockers.length ? " " + esc(av.blockers.join(" ")) : ""}</p>`;
    openDialog("Reschedule displaced class", `<div class="dialog-content">${head}${list}<div class="dialog-actions"><button class="btn btn-secondary" data-dialog-close>Close</button></div></div>`);
    $$("[data-pick-room]").forEach(b => b.addEventListener("click", async () => {
      $$("[data-pick-room]").forEach(x => (x.disabled = true));                       // one click = one request (the server also refuses duplicates)
      try {
        await api(`/api/displaced-classes/${id}/reschedule`, { method: "POST", body: { room_id: Number(b.dataset.pickRoom) } });
        $("#appDialog").close(); toast("Class rescheduled. The original cancellation stays on record.");
        await Promise.all([loadPending(), loadDaily(), refreshBell()]);
      } catch (e) { err(e); $$("[data-pick-room]").forEach(x => (x.disabled = false)); loadPending(); }
    }));
  }
  RW.openReschedule = openReschedule;
  function openDismiss(id, i) {
    openDialog("Dismiss displaced class", `<div class="dialog-content"><p class="dialog-message">${i ? `<strong>${esc(i.subject_code)}</strong> · ${esc(i.section_label)}<br>${esc(longDate(i.class_date))}, ${esc(t5(i.start_time))}–${esc(t5(i.end_time))}<br>` : ""}Dismissing means this class will <strong>not</strong> be rescheduled. The class, its cancellation and the history stay on record, and the relevant people are notified.</p>
      <div class="dialog-actions"><button class="btn btn-secondary" data-dialog-close>Back</button><button class="btn btn-primary" id="dismissGo">Dismiss</button></div></div>`);
    $("#dismissGo").addEventListener("click", async e => {
      e.target.disabled = true;
      try { await api(`/api/displaced-classes/${id}/dismiss`, { method: "POST" }); $("#appDialog").close(); toast("Dismissed. It will not be rescheduled."); await Promise.all([loadPending(), loadDaily(), refreshBell()]); }
      catch (er) { err(er); e.target.disabled = false; loadPending(); }
    });
  }
  async function refreshBell() { try { const n = await api("/api/notifications?limit=1"); const b = $("#rwBellCount"); b.textContent = n.unread; b.hidden = !n.unread; } catch (_) { /* transient */ } }

  // ---------------------------------------------------------------- keep everything current
  const baseReload = RW.reload;
  RW.reload = async function (opts) { await baseReload(opts); refreshPendingBadge(); if ($("#page-daily").classList.contains("active")) loadDaily(); };
  setInterval(() => { if (!document.hidden) { refreshPendingBadge(); if ($("#page-daily").classList.contains("active")) loadDaily(); if ($("#page-pending")?.classList.contains("active")) loadPending(); } }, 30000);
  refreshPendingBadge();

  // a "class displaced" notification gets a shortcut to the page where the action is
  new MutationObserver(() => {
    const box = $("#dialogBody .rw-notes");
    if (!box || !isStaff() || $("#dialogBody [data-goto-pending]") || !/displaced/i.test(box.textContent)) return;
    $("#dialogBody .dialog-actions")?.insertAdjacentHTML("afterbegin", `<button class="btn btn-secondary" data-goto-pending>Open pending rescheduling</button>`);
    $("[data-goto-pending]")?.addEventListener("click", () => { $("#appDialog").close(); go("pending"); $("#breadcrumbCurrent").textContent = "Pending rescheduling"; loadPending(); });
  }).observe($("#dialogBody"), { childList: true });
})();
