"""Offline tests for the displacement workflow (no MySQL, no FastAPI needed). Run:  python -m unittest tests.test_displacement_unit -v
The same behaviour against a real MySQL 8 is in test_displacement_integration.py (RW_INTEGRATION=1)."""
import re, sys, pathlib, types, unittest, datetime as dt
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
from tests._isolation import offline_imports
with offline_imports():            # fakes live only inside this block; sys.modules (incl. app.*) is restored on exit
    from app import displacement as dsp, scheduling as sch
    from app.errors import ApiError

APP = pathlib.Path(__file__).resolve().parent.parent / "app"
ROOT = APP.parent.parent

class Script:
    """Cursor double: records SQL, returns queued results in order."""
    def __init__(self, *results): self.q, self.sql, self.args, self.cur, self.lastrowid, self.rowcount = list(results), [], [], None, 77, 1
    def execute(self, sql, args=()): self.sql.append(" ".join(sql.split())); self.args.append(args); self.cur = self.q.pop(0) if self.q else []
    def fetchall(self): return self.cur if isinstance(self.cur, list) else [self.cur]
    def fetchone(self):
        if isinstance(self.cur, list): return self.cur[0] if self.cur else None
        return self.cur

class DisplayStatus(unittest.TestCase):
    def test_four_states_are_distinguishable(self):
        self.assertEqual(dsp.display_status("Scheduled", None, False)[0], "scheduled")
        self.assertEqual(dsp.display_status("Cancelled", None, False)[0], "cancelled")
        self.assertEqual(dsp.display_status("Cancelled", "Awaiting", False), ("displaced", "Displaced - awaiting rescheduling"))
        self.assertEqual(dsp.display_status("Cancelled", "Rescheduled", False), ("displaced", "Displaced - rescheduled"))
        self.assertEqual(dsp.display_status("Scheduled", None, True)[0], "rescheduled")
    def test_completed_class_is_not_shown_as_scheduled_or_rescheduled(self):
        self.assertEqual(dsp.display_status("Completed", None, False)[0], "completed")
        self.assertEqual(dsp.display_status("Completed", None, True)[0], "completed")
    def test_a_plain_cancellation_is_never_shown_as_displaced(self):
        self.assertEqual(dsp.display_status("Cancelled", None, False)[0], "cancelled")
    def test_reason_text_names_room_and_requesting_section(self):
        t = dsp.displacement_reason("301", "CS Sem 5 Sec 2", 9)
        self.assertIn("301", t); self.assertIn("CS Sem 5 Sec 2", t); self.assertIn("#9", t)

class RecordDisplacement(unittest.TestCase):
    ORIGINAL = {"class_id": 5, "section_id": 10, "section_label": "Section A", "subject_code": "DBMS", "room_number": "301",
                "class_date": dt.date(2027, 11, 5), "start_time": dt.timedelta(hours=10), "end_time": dt.timedelta(hours=11)}
    def run_record(self, crs):
        c = Script([], {"label": "Section B"}, {"code": "OS"}, crs)
        did = dsp.record(c, {"user_id": 2, "role": "CR"}, original=self.ORIGINAL, request_id=9, requester_section_id=11,
                         request_subject_id=3, displacing_class_id=8)
        return did, c
    def test_inserts_one_displacement_with_all_three_links(self):
        did, c = self.run_record([{"user_id": 2}])
        self.assertEqual(did, 77)
        self.assertTrue(c.sql[0].startswith("INSERT INTO CLASS_DISPLACEMENT"))
        self.assertEqual(c.args[0], (5, 9, 8))
    def test_every_cr_of_the_displaced_section_is_notified_exactly_once_including_the_approver(self):
        _, c = self.run_record([{"user_id": 2}, {"user_id": 4}, {"user_id": 2}])           # a duplicate row must not double-notify
        notes = [a for s, a in zip(c.sql, c.args) if s.startswith("INSERT INTO NOTIFICATION")]
        self.assertEqual(sorted(a[0] for a in notes), [2, 4])
        self.assertTrue(all(a[1] == "CLASS_DISPLACED" for a in notes))
    def test_message_has_date_time_room_requesting_section_and_subject(self):
        _, c = self.run_record([{"user_id": 2}])
        msg = [a for s, a in zip(c.sql, c.args) if s.startswith("INSERT INTO NOTIFICATION")][0][2]
        for needle in ("2027-11-05", "10:00-11:00", "room 301", "Section B", "OS", "DBMS", "Section A"):
            self.assertIn(needle, msg)
        self.assertLessEqual(len(msg), 500)

class FakeUser(dict): pass

class Authority(unittest.TestCase):
    ROW = {"displacement_id": 1, "section_id": 10, "displacement_status": "Awaiting", "class_date": dt.date(2099, 1, 5)}
    def load(self, user, scope_rows):
        c = Script(dict(self.ROW), scope_rows)
        return dsp._load_authorised(c, user, 1)
    def test_viewer_is_rejected_before_any_query(self):
        c = Script()
        with self.assertRaises(ApiError) as cm: dsp._load_authorised(c, {"user_id": 4, "role": "VIEWER"}, 1)
        self.assertEqual(cm.exception.status, 403); self.assertEqual(c.sql, [])
    def test_unrelated_cr_is_forbidden(self):
        with self.assertRaises(ApiError) as cm: self.load({"user_id": 3, "role": "CR"}, [{"section_id": 11}])
        self.assertEqual(cm.exception.status, 403)
    def test_assigned_cr_and_admin_are_allowed(self):
        self.assertEqual(self.load({"user_id": 2, "role": "CR"}, [{"section_id": 10}])["section_id"], 10)
        self.assertEqual(self.load({"user_id": 1, "role": "ADMIN"}, [])["section_id"], 10)
    def test_missing_displacement_is_404(self):
        with self.assertRaises(ApiError) as cm: dsp._load_authorised(Script(None), {"user_id": 1, "role": "ADMIN"}, 99)
        self.assertEqual(cm.exception.status, 404)
    def test_second_reschedule_is_refused_with_409_before_any_booking(self):
        row = {**self.ROW, "displacement_status": "Rescheduled"}
        c = Script(row, [{"section_id": 10}])
        with self.assertRaises(ApiError) as cm: dsp.reschedule(c, {"user_id": 2, "role": "CR"}, 1, 5)
        self.assertEqual(cm.exception.status, 409)
        self.assertFalse(any(s.startswith("INSERT INTO CLASS_SCHEDULE") for s in c.sql))
    def test_lock_is_taken_on_the_displacement_row(self):
        c = Script(None)
        with self.assertRaises(ApiError): dsp._load_authorised(c, {"user_id": 1, "role": "ADMIN"}, 1, lock=True)
        self.assertIn("FOR UPDATE OF d", c.sql[0])

class PermanentTimetableIsUntouched(unittest.TestCase):
    """Static guard: the new modules never write to TIMETABLE / TIMETABLE_SLOT; the approval path doesn't either."""
    WRITE = re.compile(r"\b(INSERT\s+(IGNORE\s+)?INTO|UPDATE|DELETE\s+FROM|REPLACE\s+INTO|ALTER\s+TABLE|TRUNCATE(\s+TABLE)?)\s+TIMETABLE(_SLOT)?\b", re.I)
    def test_no_write_to_weekly_template_in_displacement_flow(self):
        for f in (APP / "displacement.py", APP / "workflow.py", APP / "routers" / "daily.py", ROOT / "db" / "006_displaced_classes.sql"):
            text = f.read_text(encoding="utf-8")
            self.assertIsNone(self.WRITE.search(text), f"{f.name} writes to the recurring timetable")
    def test_materialisation_is_the_only_slot_reader_and_it_only_inserts_class_rows(self):
        src = (APP / "scheduling.py").read_text(encoding="utf-8")
        self.assertIsNone(self.WRITE.search(re.sub(r"INSERT IGNORE INTO CLASS_SCHEDULE.*?TIMETABLE_SLOT s", "", src, flags=re.S)))

class Mysql8Safe(unittest.TestCase):
    def test_no_select_distinct_with_order_by(self):
        for py in (APP / "displacement.py", APP / "routers" / "daily.py"):
            for m in re.finditer(r'"""(.*?)"""|"((?:[^"\\\n]|\\.)*)"', py.read_text(encoding="utf-8"), re.S):
                sql = " ".join((m.group(1) or m.group(2) or "").split())
                self.assertFalse(re.search(r"SELECT DISTINCT", sql, re.I) and re.search(r"ORDER BY", sql, re.I), sql[:80])
    def test_migration_keeps_check_columns_off_set_null_actions(self):
        sql = (ROOT / "db" / "006_displaced_classes.sql").read_text(encoding="utf-8")
        for col in ("original_class_id", "displacing_class_id", "rescheduled_class_id", "status", "rescheduled_at"):
            self.assertNotRegex(sql, rf"FOREIGN KEY \({col}\)[^,]*ON DELETE (SET NULL|CASCADE)")
    def test_migration_never_drops_or_alters_existing_tables(self):
        sql = re.sub(r"--.*", "", (ROOT / "db" / "006_displaced_classes.sql").read_text(encoding="utf-8"))
        self.assertNotRegex(sql, r"(?i)\b(DROP|ALTER|TRUNCATE)\b|\bDELETE\s+FROM\b")

if __name__ == "__main__":
    unittest.main()


class DailyScopeAndFilter(unittest.TestCase):
    def run_daily(self, role, section_id):
        from unittest import mock
        c = Script([])
        with mock.patch.object(dsp.sch, "ensure_materialized", lambda *a, **k: None), \
             mock.patch.object(dsp.common, "assigned_sections", lambda cur, u: {10}):
            dsp.daily_schedule(c, {"user_id": 2, "role": role}, "2099-01-05", section_id)
        return c.sql[-1], c.args[-1]
    def test_section_filter_keeps_the_class_that_displaced_that_section(self):
        sql, args = self.run_daily("CR", 10)
        self.assertIn("(c.section_id=%s OR dc.section_id=%s)", sql)
        self.assertEqual(args.count(10), 4)          # 2x scope + 2x filter
    def test_cr_scope_includes_displacing_class_without_filter(self):
        sql, _ = self.run_daily("CR", None)
        self.assertIn("dc.section_id IN", sql)
