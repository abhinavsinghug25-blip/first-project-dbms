"""Guards the whole suite: no unit-test module may leave a fake PyMySQL/FastAPI (or app.* built on one) in sys.modules.
Runs against the state left AFTER collection of every other test module, so a leaking file makes this fail loudly."""
import sys, unittest


class NoLeakedFakes(unittest.TestCase):
    def test_pymysql_is_real_or_absent(self):
        pm = sys.modules.get("pymysql")
        if pm is not None:
            self.assertTrue(hasattr(pm, "connect"), "a fake 'pymysql' module leaked into sys.modules (use tests._isolation.offline_imports)")

    def test_app_modules_not_built_on_fakes(self):
        db = sys.modules.get("app.db")
        if db is not None and sys.modules.get("pymysql") is not None:
            self.assertIs(getattr(db, "pymysql", sys.modules["pymysql"]), sys.modules["pymysql"])
