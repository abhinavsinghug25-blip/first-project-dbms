"""Pure-logic tests: need no database and no web framework.  Run:  python -m unittest discover -s tests -v"""
import datetime as dt, unittest, sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))

# No DB driver / web framework needed: fakes are scoped to this block and removed afterwards (see tests/_isolation.py).
# workflow is imported here too (not lazily in a test) so nothing re-imports `app` against the real driver later.
from tests._isolation import offline_imports
with offline_imports():
    from app import scheduling as sch, timeutil as tu, common, workflow as _workflow
    from app.errors import ApiError

class Overlap(unittest.TestCase):
    def test_overlapping(self):
        self.assertTrue(sch.overlaps(540, 600, 570, 630))
    def test_adjacent_is_not_overlap(self):               # half-open [start,end)
        self.assertFalse(sch.overlaps(540, 600, 600, 660))
        self.assertFalse(sch.overlaps(600, 660, 540, 600))
    def test_contained_and_identical(self):
        self.assertTrue(sch.overlaps(540, 720, 600, 660))
        self.assertTrue(sch.overlaps(540, 600, 540, 600))
    def test_disjoint(self):
        self.assertFalse(sch.overlaps(480, 540, 600, 660))

class Times(unittest.TestCase):
    def codes(self, s, e): return [v.code for v in sch.check_times(s, e)]
    def test_ok(self):          self.assertEqual(self.codes(9 * 60, 10 * 60), [])
    def test_start_after_end(self): self.assertIn("bad_time_range", self.codes(10 * 60, 9 * 60))
    def test_zero_length(self): self.assertIn("bad_time_range", self.codes(600, 600))
    def test_before_opening(self): self.assertIn("outside_hours", self.codes(7 * 60, 9 * 60))
    def test_after_closing(self):  self.assertIn("outside_hours", self.codes(17 * 60, 19 * 60))
    def test_edges_allowed(self):  self.assertEqual(self.codes(8 * 60, 18 * 60), [])

class Replacement(unittest.TestCase):
    def test_only_target_may_be_replaced(self):
        self.assertEqual(sch.unexpected_overlaps([5], [5]), [])
    def test_other_class_in_room_is_a_clash(self):      # "room taken meanwhile"
        self.assertEqual(sch.unexpected_overlaps([5, 9], [5]), [9])
    def test_no_target_any_class_is_a_clash(self):
        self.assertEqual(sch.unexpected_overlaps([9], [None]), [9])

class TimeUtil(unittest.TestCase):
    def test_parse(self):
        self.assertEqual(tu.to_min("09:30"), 570); self.assertEqual(tu.to_min("09:30:00"), 570)
        self.assertEqual(tu.to_min(dt.timedelta(hours=9, minutes=30)), 570); self.assertEqual(tu.to_min(dt.time(9, 30)), 570)
    def test_invalid(self):
        for bad in ("9:30", "24:00", "ab", "09:60"):
            with self.assertRaises(ValueError): tu.to_min(bad)
    def test_format(self):
        self.assertEqual(tu.fmt(570), "09:30"); self.assertEqual(tu.sql_time(570), "09:30:00")
    def test_monday(self):
        self.assertEqual(tu.monday_of(dt.date(2026, 11, 5)), dt.date(2026, 11, 2))
    def test_serialize(self):
        out = tu.serialize({"t": dt.timedelta(hours=9), "d": dt.date(2026, 1, 2), "n": 3})
        self.assertEqual(out, {"t": "09:00", "d": "2026-01-02", "n": 3})

class FakeCur:
    def __init__(self, rows): self.rows = rows
    def execute(self, *a): pass
    def fetchall(self): return self.rows

class Authority(unittest.TestCase):
    """can_decide / scope rules without a database."""
    def setUp(self):
        self.wf = _workflow
    req = {"requester_user_id": 7, "recipient_role": "CR", "target_section_id": 10}
    def test_requester_cannot_decide_own_even_if_admin(self):
        self.assertFalse(self.wf.can_decide(FakeCur([]), {"user_id": 7, "role": "ADMIN"}, self.req))
        self.assertFalse(self.wf.can_decide(FakeCur([{"section_id": 10}]), {"user_id": 7, "role": "CR"}, self.req))
    def test_admin_can_decide_others(self):
        self.assertTrue(self.wf.can_decide(FakeCur([]), {"user_id": 1, "role": "ADMIN"}, self.req))
    def test_cr_of_target_section_can_decide(self):
        self.assertTrue(self.wf.can_decide(FakeCur([{"section_id": 10}]), {"user_id": 2, "role": "CR"}, self.req))
    def test_cr_of_other_section_cannot(self):
        self.assertFalse(self.wf.can_decide(FakeCur([{"section_id": 11}]), {"user_id": 3, "role": "CR"}, self.req))
    def test_cr_cannot_decide_admin_routed_request(self):
        r = {**self.req, "recipient_role": "ADMIN", "target_section_id": None}
        self.assertFalse(self.wf.can_decide(FakeCur([{"section_id": 10}]), {"user_id": 2, "role": "CR"}, r))
    def test_viewer_never(self):
        self.assertFalse(self.wf.can_decide(FakeCur([]), {"user_id": 4, "role": "VIEWER"}, self.req))
    def test_require_section(self):
        common.require_section(FakeCur([{"section_id": 10}]), {"user_id": 2, "role": "CR"}, 10)
        with self.assertRaises(ApiError) as cm:
            common.require_section(FakeCur([{"section_id": 10}]), {"user_id": 2, "role": "CR"}, 99)
        self.assertEqual(cm.exception.status, 403)
        common.require_section(FakeCur([]), {"user_id": 1, "role": "ADMIN"}, 99)            # admin: any section
        with self.assertRaises(ApiError):
            common.require_section(FakeCur([]), {"user_id": 4, "role": "VIEWER"}, 10)        # viewer: none

if __name__ == "__main__":
    unittest.main()
