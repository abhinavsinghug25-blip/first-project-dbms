"""MySQL 8 integration tests: approval -> displacement -> Pending rescheduling -> reschedule -> Daily Schedule.
Enable:  RW_INTEGRATION=1 python -m pytest tests/test_displacement_integration.py -v      (needs db/006_displaced_classes.sql applied)

Naming: the REQUESTER is CR 'cra' (sections[0]); the HOLDER is CR 'crb' (sections[1]) whose class currently occupies the slot;
'crc' (sections[2]) is an unrelated CR. Same isolation rules as test_api_integration.py: every test claims its own empty far-future
weekday, so nothing here can touch your real timetable, and the recurring timetable is additionally snapshot-compared in each flow.
"""
import sys, pathlib, threading, unittest
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
from tests.test_api_integration import IntegrationBase, skip_unless_enabled


@skip_unless_enabled
class DisplacementFlow(IntegrationBase, unittest.TestCase):
    # ---------------------------------------------------------------- helpers
    def weekly(self):
        with self.db.transaction() as cur:
            return (self.db.all_(cur, "SELECT * FROM TIMETABLE ORDER BY timetable_id"),
                    self.db.all_(cur, "SELECT * FROM TIMETABLE_SLOT ORDER BY slot_id"))

    def decide(self, who, rid, decision="approve", kind="extra"):
        return self.client(who).post(f"/api/requests/{kind}/{rid}/decision", json={"decision": decision})

    def displace(self, start="10:00", end="11:00", approver="crb"):
        """HOLDER's class occupies the room; REQUESTER asks for it; HOLDER's CR approves. Returns (holder_class_id, request_id, displacement_id)."""
        holder = self.mk_class(self.sections[1], start, end)
        r = self.req("cra", self.sections[0], start, end)
        self.assertEqual(r.status_code, 201, r.text)
        self.assertEqual(r.json()["routed_to"], "CR")
        rid = r.json()["request_id"]
        d = self.decide(approver, rid)
        self.assertEqual(d.status_code, 200, d.text)
        with self.db.transaction() as cur:
            disp = self.db.one(cur, "SELECT displacement_id FROM CLASS_DISPLACEMENT WHERE original_class_id=%s", (holder,))
        self.assertIsNotNone(disp, "approval must record a displacement")
        return holder, rid, disp["displacement_id"]

    def q(self, sql, args=()):
        with self.db.transaction() as cur:
            return self.db.all_(cur, sql, args)

    def scheduled_in(self, room, start="10:00:00"):
        return self.q("SELECT class_id,section_id FROM CLASS_SCHEDULE WHERE room_id=%s AND class_date=%s AND start_time=%s AND status='Scheduled'",
                      (room, self.day, start))

    def daily(self, who, day=None, **params):
        qs = "&".join([f"date={day or self.day}"] + [f"{k}={v}" for k, v in params.items()])
        r = self.client(who).get(f"/api/daily-schedule?{qs}")
        self.assertEqual(r.status_code, 200, r.text)
        return r.json()

    def resched(self, who, did, room):
        return self.client(who).post(f"/api/displaced-classes/{did}/reschedule", json={"room_id": room})

    # ---------------------------------------------------------------- 1-5, 15: approval and displacement
    def test_01_to_05_approval_cancels_only_that_slot_books_requester_and_notifies_holder(self):
        before = self.weekly()
        other_day = self.claim_day()                                            # a different date: must stay untouched
        other = self.client("admin").post("/api/classes", json={"section_id": self.sections[1], "subject_id": self.subject, "room_id": self.room,
                                                               "date": other_day, "start": "10:00", "end": "11:00"})
        self.assertEqual(other.status_code, 201, other.text); other_id = other.json()["class_id"]
        holder, rid, did = self.displace()
        rows = {r["class_id"]: r for r in self.q("SELECT * FROM CLASS_SCHEDULE WHERE class_id IN (%s,%s)", (holder, other_id))}
        self.assertEqual(rows[holder]["status"], "Cancelled")                    # 3: cancelled for that date ...
        self.assertEqual(rows[other_id]["status"], "Scheduled")                  # 14: ... and only that date
        new = self.scheduled_in(self.room)
        self.assertEqual([(c["section_id"]) for c in new], [self.sections[0]])   # 4: requester's class now holds the slot
        req = self.q("SELECT status,resulting_class_id,decided_by_user_id,decision_reason FROM EXTRA_CLASS_REQUEST WHERE request_id=%s", (rid,))[0]
        self.assertEqual((req["status"], req["resulting_class_id"], req["decided_by_user_id"]), ("Approved", new[0]["class_id"], self.ids["crb"]))
        # 5: exactly one displacement notification to the holder's CR, with date/time/room/requesting section/subject
        n = self.q("SELECT message,entity_type,entity_id FROM NOTIFICATION WHERE user_id=%s AND type='CLASS_DISPLACED' AND entity_id=%s", (self.ids["crb"], str(did)))
        self.assertEqual(len(n), 1)
        room_no = self.q("SELECT room_number FROM ROOM WHERE room_id=%s", (self.room,))[0]["room_number"]
        req_label = self.q("SELECT label FROM SECTION WHERE section_id=%s", (self.sections[0],))[0]["label"]
        subj = self.q("SELECT code FROM SUBJECT WHERE subject_id=%s", (self.subject,))[0]["code"]
        for needle in (self.day, "10:00-11:00", f"room {room_no}", req_label, subj):
            self.assertIn(needle, n[0]["message"])
        self.assertEqual((n[0]["entity_type"], n[0]["entity_id"]), ("CLASS_DISPLACEMENT", str(did)))
        self.assertEqual(self.notes(self.ids["cra"], "REQUEST_APPROVED", rid), 1)          # requester told, once
        self.assertEqual(self.notes(self.ids["crc"], "CLASS_DISPLACED", did), 0)           # unrelated CR is not
        self.assertEqual(self.weekly(), before)                                            # 13: weekly template byte-for-byte unchanged

    def test_only_target_cr_or_admin_can_approve(self):
        self.mk_class(self.sections[1], "10:00", "11:00")
        rid = self.req("cra", self.sections[0], "10:00", "11:00").json()["request_id"]
        self.assertEqual(self.decide("cra", rid).status_code, 403)               # requester cannot approve their own request
        self.assertEqual(self.decide("crc", rid).status_code, 403)               # unrelated CR
        self.assertEqual(self.decide("viewer", rid).status_code, 403)            # viewer
        self.assertEqual(self.q("SELECT COUNT(*) n FROM CLASS_DISPLACEMENT d JOIN EXTRA_CLASS_REQUEST q ON q.request_id=d.request_id WHERE q.request_id=%s", (rid,))[0]["n"], 0)
        self.assertEqual(self.decide("admin", rid).status_code, 200)             # ADMIN may

    def test_failed_approval_rolls_back_completely(self):
        holder = self.mk_class(self.sections[1], "10:00", "11:00")
        rid = self.req("cra", self.sections[0], "10:00", "11:00").json()["request_id"]
        self.mk_class(self.sections[0], "10:00", "11:00", room=self.room2)      # requester's own section becomes busy before the decision
        shown = self.notes(self.ids["crb"], "CLASS_DISPLACED")                   # CRs are shared across tests => compare before/after
        d = self.decide("crb", rid)
        self.assertEqual(d.status_code, 409, d.text); self.assertIn("section_conflict", str(d.json()))
        self.assertEqual(self.q("SELECT status FROM CLASS_SCHEDULE WHERE class_id=%s", (holder,))[0]["status"], "Scheduled")   # not cancelled
        self.assertEqual(self.q("SELECT COUNT(*) n FROM CLASS_DISPLACEMENT WHERE original_class_id=%s", (holder,))[0]["n"], 0)
        self.assertEqual(self.q("SELECT status FROM EXTRA_CLASS_REQUEST WHERE request_id=%s", (rid,))[0]["status"], "Pending")
        self.assertEqual(self.q("SELECT COUNT(*) n FROM CLASS_CANCELLATION WHERE class_id=%s", (holder,))[0]["n"], 0)
        self.assertEqual(self.notes(self.ids["crb"], "CLASS_DISPLACED"), shown)
        self.assertEqual(self.notes(self.ids["cra"], "REQUEST_APPROVED", rid), 0)

    def test_request_routed_to_admin_notifies_admin_and_admin_can_reschedule(self):
        import random
        a = self.client("admin")
        br = self.q("SELECT branch_id FROM BRANCH ORDER BY branch_id LIMIT 1")[0]["branch_id"]
        for _ in range(20):
            sec = a.post("/api/admin/sections", json={"branch_id": br, "semester": 10, "section_no": random.randint(1, 250), "strength": 30})
            if sec.status_code == 201: break
        self.assertEqual(sec.status_code, 201, sec.text)
        empty = sec.json()["section_id"]; self.created["sections"].append(empty)     # a section nobody is CR of
        holder = self.mk_class(empty, "10:00", "11:00")
        r = self.req("cra", self.sections[0], "10:00", "11:00"); rid = r.json()["request_id"]
        self.assertEqual(r.json()["routed_to"], "ADMIN")
        self.assertEqual(self.notes(self.ids["admin"], "REQUEST_RECEIVED", rid), 1)           # 7: ADMIN, exactly once
        self.assertEqual(self.decide("crc", rid).status_code, 403)
        self.assertEqual(self.decide("admin", rid).status_code, 200)
        did = self.q("SELECT displacement_id FROM CLASS_DISPLACEMENT WHERE original_class_id=%s", (holder,))[0]["displacement_id"]
        listed = a.get("/api/displaced-classes?status=Awaiting").json()["items"]
        self.assertIn(did, [i["displacement_id"] for i in listed])                            # ADMIN sees every section's displaced classes
        self.assertEqual(self.resched("admin", did, self.room2).status_code, 200)

    # ---------------------------------------------------------------- 6: Pending Rescheduling
    def test_06_displaced_class_appears_under_pending_rescheduling_for_its_cr_only(self):
        holder, rid, did = self.displace()
        items = self.client("crb").get("/api/displaced-classes").json()["items"]
        mine = [i for i in items if i["displacement_id"] == did]
        self.assertEqual(len(mine), 1); i = mine[0]
        self.assertEqual((i["displacement_status"], i["status_label"], i["can_reschedule"]), ("Awaiting", "Awaiting rescheduling", True))
        self.assertEqual((i["original_class_id"], i["section_id"], i["class_date"]), (holder, self.sections[1], self.day))
        self.assertEqual((i["start_time"], i["end_time"]), ("10:00", "11:00"))
        for key in ("subject_code", "section_label", "original_room", "reason", "requesting_section", "request_id"):
            self.assertTrue(i[key], key)
        self.assertNotIn(did, [x["displacement_id"] for x in self.client("cra").get("/api/displaced-classes").json()["items"]])   # requester: not theirs
        self.assertNotIn(did, [x["displacement_id"] for x in self.client("crc").get("/api/displaced-classes").json()["items"]])   # unrelated CR
        self.assertEqual(self.client("viewer").get("/api/displaced-classes").status_code, 403)

    # ---------------------------------------------------------------- 7, 8, 9, 10, 11: rescheduling
    def test_07_cr_reschedules_into_another_available_room(self):
        before = self.weekly()
        holder, rid, did = self.displace()
        av = self.client("crb").get(f"/api/displaced-classes/{did}/available-rooms")
        self.assertEqual(av.status_code, 200, av.text)
        ids = [r["room_id"] for r in av.json()["rooms"]]
        self.assertIn(self.room2, ids); self.assertNotIn(self.room, ids)         # exact same date/time; the taken room is not offered
        self.assertEqual((av.json()["date"], av.json()["start"], av.json()["end"]), (self.day, "10:00", "11:00"))
        r = self.resched("crb", did, self.room2); self.assertEqual(r.status_code, 200, r.text)
        d = self.q("SELECT * FROM CLASS_DISPLACEMENT WHERE displacement_id=%s", (did,))[0]
        self.assertEqual((d["status"], d["rescheduled_by_user_id"]), ("Rescheduled", self.ids["crb"])); self.assertIsNotNone(d["rescheduled_at"])
        new = self.q("SELECT * FROM CLASS_SCHEDULE WHERE class_id=%s", (d["rescheduled_class_id"],))[0]
        self.assertEqual((new["room_id"], new["section_id"], new["subject_id"], str(new["class_date"]), str(new["start_time"]), str(new["end_time"]), new["status"]),
                         (self.room2, self.sections[1], self.subject, self.day, "10:00:00", "11:00:00", "Scheduled"))
        self.assertNotEqual(new["class_id"], holder)                              # a NEW dated record; the original is preserved below
        self.assertEqual(self.q("SELECT status FROM CLASS_SCHEDULE WHERE class_id=%s", (holder,))[0]["status"], "Cancelled")
        self.assertEqual(self.q("SELECT COUNT(*) n FROM CLASS_CANCELLATION WHERE class_id=%s", (holder,))[0]["n"], 1)
        self.assertEqual(self.notes(self.ids["crb"], "CLASS_RESCHEDULED", did), 1)   # 7: success notification, once
        listed = self.client("crb").get("/api/displaced-classes").json()["items"]
        self.assertEqual([x for x in listed if x["displacement_id"] == did][0]["status_label"], "Rescheduled")
        self.assertEqual(self.weekly(), before)

    def test_08_cannot_reschedule_into_an_occupied_room(self):
        holder, rid, did = self.displace()
        self.mk_class(self.sections[2], "10:00", "11:00", room=self.room2)       # room2 is taken at that time
        av = self.client("crb").get(f"/api/displaced-classes/{did}/available-rooms").json()
        self.assertNotIn(self.room2, [r["room_id"] for r in av["rooms"]])
        r = self.resched("crb", did, self.room2)
        self.assertEqual(r.status_code, 409, r.text); self.assertIn("room_conflict", str(r.json()))
        self.assertEqual(self.resched("crb", did, self.room).status_code, 409)   # the room the requester now holds is occupied too
        self.assertEqual(self.q("SELECT status FROM CLASS_DISPLACEMENT WHERE displacement_id=%s", (did,))[0]["status"], "Awaiting")   # nothing changed
        self.assertEqual(len(self.scheduled_in(self.room2)), 1); self.assertEqual(len(self.scheduled_in(self.room)), 1)
        self.assertEqual(self.notes(self.ids["crb"], "CLASS_RESCHEDULED", did), 0)

    def test_08b_reschedule_revalidates_section_conflicts(self):
        holder, rid, did = self.displace()
        self.mk_class(self.sections[1], "10:00", "11:00", room=self.room2)       # the displaced section got another class at that time
        r = self.resched("crb", did, self.room2)
        self.assertEqual(r.status_code, 409, r.text); self.assertIn("section_conflict", str(r.json()))

    def test_09_unrelated_cr_cannot_reschedule(self):
        holder, rid, did = self.displace()
        for who in ("crc", "cra"):                                                # unrelated CR and the requesting CR
            self.assertEqual(self.resched(who, did, self.room2).status_code, 403, who)
            self.assertEqual(self.client(who).get(f"/api/displaced-classes/{did}/available-rooms").status_code, 403, who)
        self.assertEqual(self.q("SELECT status FROM CLASS_DISPLACEMENT WHERE displacement_id=%s", (did,))[0]["status"], "Awaiting")
        self.assertEqual(len(self.scheduled_in(self.room2)), 0)

    def test_10_viewer_cannot_reschedule(self):
        holder, rid, did = self.displace()
        self.assertEqual(self.resched("viewer", did, self.room2).status_code, 403)
        self.assertEqual(self.client("viewer").get(f"/api/displaced-classes/{did}/available-rooms").status_code, 403)
        self.assertEqual(self.TC(self.app).post(f"/api/displaced-classes/{did}/reschedule", json={"room_id": self.room2}).status_code, 401)   # anonymous
        self.assertEqual(len(self.scheduled_in(self.room2)), 0)

    def test_11_class_cannot_be_rescheduled_twice(self):
        holder, rid, did = self.displace()
        self.assertEqual(self.resched("crb", did, self.room2).status_code, 200)
        self.assertEqual(self.resched("crb", did, self.room2).status_code, 409)
        self.assertEqual(self.resched("admin", did, self.room2).status_code, 409)
        self.assertEqual(self.client("crb").get(f"/api/displaced-classes/{did}/available-rooms").status_code, 409)
        self.assertEqual(len(self.scheduled_in(self.room2)), 1)
        self.assertEqual(self.notes(self.ids["crb"], "CLASS_RESCHEDULED", did), 1)
        self.assertEqual(self.q("SELECT COUNT(*) n FROM CLASS_DISPLACEMENT WHERE rescheduled_class_id IS NOT NULL AND original_class_id=%s", (holder,))[0]["n"], 1)

    # ---------------------------------------------------------------- 12: Daily Schedule
    def test_12_daily_schedule_reflects_every_change_and_is_role_scoped(self):
        plain = self.mk_class(self.sections[2], "12:00", "13:00"); self.cancel_as("crc", plain, "teacher unwell")       # ordinary cancellation
        moved = self.mk_class(self.sections[2], "14:00", "15:00")                                                     # room change
        rc = self.client("crc").post("/api/requests/room-change", json={"class_id": moved, "requested_room_id": self.room2, "reason": "projector"})
        self.assertEqual(rc.status_code, 201, rc.text)
        self.assertEqual(self.decide("admin", rc.json()["change_id"], kind="room-change").status_code, 200)
        holder, rid, did = self.displace()
        by_id = lambda who: {i["class_id"]: i for i in self.daily(who)["items"]}
        a = by_id("admin")
        self.assertEqual(a[holder]["status"], "displaced"); self.assertEqual(a[holder]["displaced_state"], "Awaiting")
        self.assertIn("awaiting rescheduling", a[holder]["status_label"])
        new_id = self.scheduled_in(self.room)[0]["class_id"]
        self.assertEqual(a[new_id]["status"], "scheduled"); self.assertIn("Replaced", a[new_id]["note"])               # newly approved extra class
        self.assertEqual(a[plain]["status"], "cancelled"); self.assertIn("teacher unwell", a[plain]["note"])         # visible, not removed
        self.assertEqual((a[moved]["status"], a[moved]["room_id"]), ("scheduled", self.room2)); self.assertIn("Room changed", a[moved]["note"])
        self.assertEqual(self.resched("crb", did, self.room2).status_code, 200)
        a = by_id("admin")
        self.assertEqual((a[holder]["status"], a[holder]["displaced_state"]), ("displaced", "Rescheduled"))            # original still shown
        resched_ids = [i["class_id"] for i in a.values() if i["status"] == "rescheduled"]
        self.assertEqual(len(resched_ids), 1); self.assertEqual(a[resched_ids[0]]["room_id"], self.room2)
        self.assertEqual(a[resched_ids[0]]["section_id"], self.sections[1])
        counts = self.daily("admin")["counts"]
        self.assertEqual((counts["displaced"], counts["rescheduled"], counts["cancelled"]), (1, 1, 1))
        # roles
        self.assertEqual(set(by_id("viewer")), set(a))                                                               # VIEWER: everything, read-only
        crb = by_id("crb")
        self.assertIn(holder, crb); self.assertIn(new_id, crb); self.assertIn(resched_ids[0], crb)                    # own class, what replaced it, new booking
        self.assertNotIn(plain, crb); self.assertNotIn(moved, crb)
        crc = by_id("crc"); self.assertEqual(set(crc), {plain, moved})                                                # another CR never sees section 1's changes
        self.assertEqual(self.client("crc").get(f"/api/daily-schedule?date={self.day}&section_id={self.sections[1]}").status_code, 403)
        self.assertEqual(self.client("crb").get("/api/daily-schedule?date=not-a-date").status_code, 400)

    # ---------------------------------------------------------------- 13, 14, 15: nothing else moves, history intact
    def test_13_14_15_recurring_timetable_future_dates_and_history_are_intact(self):
        before = self.weekly()
        future = self.claim_day()
        fut = self.client("admin").post("/api/classes", json={"section_id": self.sections[1], "subject_id": self.subject, "room_id": self.room,
                                                             "date": future, "start": "10:00", "end": "11:00"}).json()["class_id"]
        holder, rid, did = self.displace()
        self.assertEqual(self.resched("crb", did, self.room2).status_code, 200)
        self.assertEqual(self.weekly(), before)                                                                       # TIMETABLE + TIMETABLE_SLOT identical
        self.assertEqual(self.q("SELECT status,room_id FROM CLASS_SCHEDULE WHERE class_id=%s", (fut,))[0], {"status": "Scheduled", "room_id": self.room})
        self.assertEqual(self.q("SELECT COUNT(*) n FROM CLASS_SCHEDULE WHERE class_date=%s", (future,))[0]["n"], 1)
        self.assertEqual(self.q("SELECT COUNT(*) n FROM CLASS_SCHEDULE WHERE class_date=%s AND timetable_slot_id IS NOT NULL", (self.day,))[0]["n"], 0)
        c = self.q("SELECT cancelled_by_user_id,reason FROM CLASS_CANCELLATION WHERE class_id=%s", (holder,))
        self.assertEqual(len(c), 1); self.assertEqual(c[0]["cancelled_by_user_id"], self.ids["crb"]); self.assertIn(f"request #{rid}", c[0]["reason"])
        self.assertEqual(self.q("SELECT status,decided_by_user_id FROM EXTRA_CLASS_REQUEST WHERE request_id=%s", (rid,))[0], {"status": "Approved", "decided_by_user_id": self.ids["crb"]})
        actions = {r["action"] for r in self.q("SELECT action FROM AUDIT_LOG WHERE (entity_type='CLASS_SCHEDULE' AND entity_id=%s) OR (entity_type='CLASS_DISPLACEMENT' AND entity_id=%s)"
                                               " OR (entity_type='EXTRA_CLASS_REQUEST' AND entity_id=%s)", (str(holder), str(did), str(rid)))}
        self.assertTrue({"CLASS_RELEASED_FOR_REQUEST", "CLASS_DISPLACED", "CLASS_RESCHEDULED", "REQUEST_APPROVED"} <= actions, actions)

    # ---------------------------------------------------------------- 16: concurrency
    def test_16a_concurrent_reschedule_creates_exactly_one_booking(self):
        holder, rid, did = self.displace()
        out, cl = [], {w: self.client(w) for w in ("crb", "admin")}
        go = lambda who: out.append(cl[who].post(f"/api/displaced-classes/{did}/reschedule", json={"room_id": self.room2}).status_code)
        ts = [threading.Thread(target=go, args=(w,)) for w in ("crb", "admin")]
        [t.start() for t in ts]; [t.join() for t in ts]
        self.assertEqual(sorted(out), [200, 409], out)
        self.assertEqual(len(self.scheduled_in(self.room2)), 1)
        self.assertEqual(self.q("SELECT COUNT(*) n FROM CLASS_SCHEDULE WHERE section_id=%s AND class_date=%s AND status='Scheduled' AND start_time='10:00:00'", (self.sections[1], self.day))[0]["n"], 1)
        self.assertEqual(self.notes(self.ids["crb"], "CLASS_RESCHEDULED", did), 1)

    def test_16b_concurrent_approvals_for_one_slot_displace_once_and_book_once(self):
        holder = self.mk_class(self.sections[1], "10:00", "11:00")
        r1 = self.req("cra", self.sections[0], "10:00", "11:00").json()["request_id"]
        r2 = self.req("crc", self.sections[2], "10:00", "11:00").json()["request_id"]
        out, cl = [], [self.client("admin"), self.client("admin")]
        go = lambda i, rid: out.append(cl[i].post(f"/api/requests/extra/{rid}/decision", json={"decision": "approve"}).status_code)
        ts = [threading.Thread(target=go, args=(i, r)) for i, r in enumerate((r1, r2))]
        [t.start() for t in ts]; [t.join() for t in ts]
        self.assertEqual(sorted(out), [200, 409], out)
        self.assertEqual(len(self.scheduled_in(self.room)), 1)                                                         # no double booking
        self.assertEqual(self.q("SELECT COUNT(*) n FROM CLASS_DISPLACEMENT WHERE original_class_id=%s", (holder,))[0]["n"], 1)
        did = self.q("SELECT displacement_id FROM CLASS_DISPLACEMENT WHERE original_class_id=%s", (holder,))[0]["displacement_id"]
        self.assertEqual(self.notes(self.ids["crb"], "CLASS_DISPLACED", did), 1)
        self.assertEqual(self.q("SELECT COUNT(*) n FROM EXTRA_CLASS_REQUEST WHERE request_id IN (%s,%s) AND status='Approved'", (r1, r2))[0]["n"], 1)


if __name__ == "__main__":
    unittest.main()
