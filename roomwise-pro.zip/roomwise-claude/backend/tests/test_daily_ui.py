"""Browser tests for the Daily Schedule dialog, cancellation and Dismiss UI. They load the REAL frontend/assets/js/daily.js into a small
harness page whose RW.api is a recording fake (no server, no MySQL). Skipped automatically if Playwright/Chromium is unavailable.
Run:  python -m unittest tests.test_daily_ui -v        (needs: pip install playwright && playwright install chromium)"""
import json, pathlib, unittest, datetime as dt
try:
    from playwright.sync_api import sync_playwright
except Exception:                                                   # pragma: no cover
    sync_playwright = None

JS = (pathlib.Path(__file__).resolve().parent.parent.parent / "frontend" / "assets" / "js" / "daily.js")
TODAY = dt.date.today().isoformat()
FUTURE = (dt.date.today() + dt.timedelta(days=3)).isoformat()
PAST = (dt.date.today() - dt.timedelta(days=3)).isoformat()

def item(cid, status, **kw):
    base = {"class_id": cid, "class_date": FUTURE, "start_time": "10:00", "end_time": "11:00", "section_id": 10, "section_label": "CS Sem 5 Sec 1",
            "room_number": "5217", "subject_code": "DBMS", "subject_name": "Database Systems", "teacher_name": "A. Verma", "status": status,
            "status_label": status.capitalize(), "note": None, "displaced_id": None, "displaced_state": None,
            "can_cancel": status in ("scheduled", "rescheduled")}
    return {**base, **kw}

HARNESS = """<!doctype html><meta charset=utf-8><body>
<button class="nav-item" data-page="timetable"></button><button class="nav-item" data-page="requests"></button><span id="breadcrumbCurrent"></span><span id="rwBellCount"></span>
<main class="content"></main><dialog id="appDialog"><h2 id="dialogTitle"></h2><div id="dialogBody"></div></dialog>
<script>
window.CALLS = []; window.TOASTS = [];
window.$ = (q, r = document) => r.querySelector(q); window.$$ = (q, r = document) => [...r.querySelectorAll(q)];
window.go = p => { $$(".page").forEach(x => x.classList.toggle("active", x.id === "page-" + p)); };
window.toast = (m, t) => TOASTS.push([m, t || "success"]);
window.openDialog = (title, html) => { $("#dialogTitle").textContent = title; $("#dialogBody").innerHTML = html; const d = $("#appDialog"); if (!d.open) d.showModal();
  $$("[data-dialog-close]", d).forEach(b => b.onclick = () => d.close()); };
const pad = n => String(n).padStart(2, "0");
window.RW = { esc: s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])),
  iso: d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`, user: __USER__, mySectionIds: __SECTIONS__, catalog: { sections: [] }, reload: async () => {},
  api: async (path, opts = {}) => { CALLS.push([opts.method || "GET", path, opts.body || null]); const f = window.FAKE(path, opts); if (f instanceof Error) throw f; return f; } };
window.FAKE = () => ({});
</script></body>"""

@unittest.skipUnless(sync_playwright, "playwright not installed")
class DailyUi(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pw = sync_playwright().start()
        try: cls.browser = cls.pw.chromium.launch()
        except Exception as e:
            cls.pw.stop(); raise unittest.SkipTest(f"Chromium unavailable: {e}")
    @classmethod
    def tearDownClass(cls): cls.browser.close(); cls.pw.stop()

    def page(self, role="CR", sections=(10,), items=(), pending=None):
        p = self.browser.new_page()
        p.set_content(HARNESS.replace("__USER__", json.dumps({"role": role})).replace("__SECTIONS__", json.dumps(list(sections))))
        data = {"items": list(items), "pending": pending or {}}
        p.evaluate("""d => { window.D = d; window.FAKE = (path, opts) => {
            if (path.startsWith("/api/daily-schedule")) return { date: new URL("http://x" + path).searchParams.get("date"), items: D.items, counts: {} };
            if (path.startsWith("/api/displaced-classes?")) { const s = new URL("http://x" + path).searchParams.get("status"); return { items: D.pending[s] || [] }; }
            if (path.startsWith("/api/notifications")) return { unread: 0 };
            return { ok: true }; }; }""", data)
        p.add_script_tag(path=str(JS)); p.wait_for_timeout(150)
        p.evaluate("""() => { window.go("daily"); }""")
        p.evaluate("d => { document.querySelector('#dlyDate').value = d; document.querySelector('#dlyDate').dispatchEvent(new Event('change')); }", FUTURE)
        p.wait_for_selector("#dlyBody tr")
        return p
    def calls(self, p): return p.evaluate("CALLS")

    def test_clicking_a_row_opens_class_details(self):
        p = self.page(items=[item(1, "scheduled")])
        p.click("#dlyBody tr[data-class-id='1'] td:nth-child(3)")
        txt = p.inner_text("#dialogBody")
        for needle in ("DBMS", "Database Systems", "CS Sem 5 Sec 1", "A. Verma", "5217", "10:00–11:00", "Scheduled"):
            self.assertIn(needle, txt)
        self.assertTrue(p.is_visible("#appDialog")); p.close()

    def test_keyboard_enter_also_opens_details(self):
        p = self.page(items=[item(1, "scheduled")])
        p.focus("#dlyBody tr[data-class-id='1']"); p.keyboard.press("Enter")
        self.assertIn("Class details", p.inner_text("#dialogTitle")); p.close()

    def test_row_action_button_keeps_its_own_action_and_does_not_open_details(self):
        p = self.page(items=[item(2, "displaced", displaced_id=7, displaced_state="Awaiting", status_label="Displaced - awaiting rescheduling")])
        p.click("[data-dly-reschedule='7']")
        self.assertNotIn("Class details", p.inner_text("#dialogTitle")); p.close()

    def test_cancel_action_follows_the_servers_can_cancel_flag(self):
        cases = [("scheduled", True, True), ("rescheduled", True, True), ("scheduled", False, False), ("completed", False, False),
                 ("cancelled", False, False), ("displaced", False, False), ("rescheduled", None, False)]      # flag missing => never offered
        for status, flag, expect in cases:
            it = item(1, status)
            if flag is None: del it["can_cancel"]
            else: it["can_cancel"] = flag
            p = self.page(items=[it])
            p.click("#dlyBody tr[data-class-id='1'] td:nth-child(3)")
            self.assertEqual(p.locator("#clsCancel").count() == 1, expect, (status, flag)); p.close()

    def test_cancel_requires_reason_then_calls_existing_endpoint_and_refreshes(self):
        p = self.page(items=[item(1, "scheduled")])
        p.click("#dlyBody tr[data-class-id='1'] td:nth-child(3)"); p.click("#clsCancel")
        p.click("#clsCancelGo")                                                         # empty reason: blocked, no request
        self.assertFalse(any(c[0] == "POST" for c in self.calls(p)))
        p.fill("#clsReason", "teacher unwell"); before = len(self.calls(p)); p.click("#clsCancelGo"); p.wait_for_timeout(200)
        posts = [c for c in self.calls(p) if c[0] == "POST"]
        self.assertEqual(posts, [["POST", "/api/classes/1/cancel", {"reason": "teacher unwell"}]])      # reuses the existing endpoint
        self.assertTrue(any(c[1].startswith("/api/daily-schedule") for c in self.calls(p)[before:]))     # Daily Schedule refreshed
        self.assertFalse(p.is_visible("#appDialog")); p.close()

    def test_server_refusal_is_shown_and_dialog_stays_usable(self):
        p = self.page(items=[item(1, "scheduled")])
        p.evaluate("""() => { const f = window.FAKE; window.FAKE = (path, o) => (o.method === "POST" ? new Error("Past classes cannot be cancelled.") : f(path, o)); }""")
        p.click("#dlyBody tr[data-class-id='1'] td:nth-child(3)"); p.click("#clsCancel"); p.fill("#clsReason", "x y z"); p.click("#clsCancelGo"); p.wait_for_timeout(200)
        self.assertIn(["Past classes cannot be cancelled.", "error"], p.evaluate("TOASTS")); self.assertFalse(p.is_disabled("#clsCancelGo")); p.close()

    def test_pending_page_has_three_tabs_and_dismiss_calls_endpoint(self):
        awaiting = {"displacement_id": 5, "displacement_status": "Awaiting", "status_label": "Awaiting rescheduling", "subject_code": "DBMS", "section_label": "Sec 1",
                    "class_date": FUTURE, "start_time": "10:00", "end_time": "11:00", "original_room": "301", "reason": "r", "requested_by": "x", "requesting_section": "Sec 2",
                    "can_reschedule": True, "can_dismiss": True}
        p = self.page(pending={"Awaiting": [awaiting], "Dismissed": [{**awaiting, "displacement_id": 6, "displacement_status": "Dismissed", "status_label": "Dismissed",
                                                                      "can_reschedule": False, "can_dismiss": False, "dismissed_by": "Ada", "dismissed_at": "2099-01-01T10:00:00"}]})
        p.evaluate("""() => { document.querySelector('#page-pending')?.classList.add('active'); }""")
        self.assertEqual([b.strip() for b in p.locator("#pendTabs button").all_inner_texts()], ["Awaiting rescheduling", "Rescheduled", "Dismissed"])
        p.click("#pendTabs button[data-pend='Awaiting']"); p.wait_for_selector("[data-dismiss='5']")
        self.assertEqual(p.locator("[data-reschedule='5']").count(), 1)                 # Dismiss sits alongside Find available rooms
        p.click("[data-dismiss='5']"); p.click("#dismissGo"); p.wait_for_timeout(200)
        self.assertIn(["POST", "/api/displaced-classes/5/dismiss", None], self.calls(p))
        p.click("#pendTabs button[data-pend='Dismissed']"); p.wait_for_selector("#pendBody tr")
        body = p.inner_text("#pendBody"); self.assertIn("Dismissed", body); self.assertIn("Ada", body)
        self.assertEqual(p.locator("#pendBody [data-reschedule], #pendBody [data-dismiss]").count(), 0)   # no actions on a dismissed item
        p.close()

if __name__ == "__main__":
    unittest.main()
