"""Scoped stubs for OFFLINE unit tests (no PyMySQL / FastAPI installed).

Why: `sys.modules.setdefault("pymysql", fake)` at import time leaks the fake into every other test module collected afterwards,
and the app modules imported against it (app.db, ...) stay cached, so real MySQL integration tests then fail with
"module 'pymysql' has no attribute 'connect'".

Use (module level of a unit-test file):
    from tests._isolation import offline_imports
    with offline_imports():
        from app import displacement as dsp
`patch.dict(sys.modules)` restores sys.modules exactly on exit, which also DROPS every `app.*` module that was imported while
the fakes were installed, so the integration tests re-import `app` against the real PyMySQL. Names bound in the unit-test
module keep working (they hold direct references).
"""
import sys, types, contextlib
from unittest import mock


def _fake_pymysql():
    pm, cur = types.ModuleType("pymysql"), types.ModuleType("pymysql.cursors")
    cur.DictCursor = object
    pm.cursors, pm.err = cur, types.SimpleNamespace(IntegrityError=Exception, OperationalError=Exception)
    return {"pymysql": pm, "pymysql.cursors": cur}


def _fake_fastapi():
    f = types.ModuleType("fastapi"); f.Request = object
    fr = types.ModuleType("fastapi.responses"); fr.JSONResponse = object
    fe = types.ModuleType("fastapi.exceptions"); fe.RequestValidationError = Exception
    return {"fastapi": f, "fastapi.responses": fr, "fastapi.exceptions": fe}


@contextlib.contextmanager
def offline_imports(fake_pymysql=True, fake_fastapi=True):
    """Install fakes ONLY for modules that are genuinely not importable, and only for the duration of the `with` block."""
    fakes = {}
    if fake_pymysql:
        try:
            import pymysql, pymysql.cursors  # noqa: F401  real driver present -> keep it
        except ModuleNotFoundError:
            fakes.update(_fake_pymysql())
    if fake_fastapi:
        try:
            import fastapi  # noqa: F401
        except ModuleNotFoundError:
            fakes.update(_fake_fastapi())
    with mock.patch.dict(sys.modules, fakes):
        # force a fresh `app` import against the fakes, without disturbing a real one already cached
        saved = {k: sys.modules.pop(k) for k in [k for k in sys.modules if k == "app" or k.startswith("app.")]}
        try:
            yield
        finally:
            for k in [k for k in sys.modules if k == "app" or k.startswith("app.")]:
                sys.modules.pop(k, None)
            sys.modules.update(saved)
