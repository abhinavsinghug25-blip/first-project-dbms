"""End-to-end API tests against a REAL MySQL 8 (seeded with db/001 + 002).
Enable:  RW_INTEGRATION=1 python -m pytest tests/test_api_integration.py -v      (Routing only: add  -k Routing)

ISOLATION RULES (so tests never depend on, or disturb, your timetable):
  * Rooms, sections and the subject are chosen DYNAMICALLY from the database (never fixed numbers).
  * Every test claims its OWN calendar date via claim_day(): a weekday that has no CLASS_SCHEDULE rows, no requests, and
    is not covered by any published timetable. Nothing else can occupy that date, so any room/hour is genuinely free.
    (Production conflict detection is untouched; tests just stop colliding with each other.)
  * Everything a test creates is recorded. Optional cleanup removes ONLY those records (see tearDownClass).

CLEANUP: the runtime account is least-privilege by design (no DELETE on USER_ACCOUNT / CLASS_CANCELLATION / AUDIT_LOG), so
cleanup needs a privileged account. Set RW_TEST_CLEANUP_USER / RW_TEST_CLEANUP_PASSWORD to enable it. Without them the test
rows stay (users are named t_*_<hex>, dates are far-future, nothing existing is touched) and a note is printed.
"""
import datetime as dt, os, random, secrets, threading, unittest, sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))

ENABLED = os.environ.get("RW_INTEGRATION") == "1"
skip_unless_enabled = unittest.skipUnless(ENABLED, "set RW_INTEGRATION=1 with a seeded MySQL 8")


class IntegrationBase:
    """Fixture mixin (not a TestCase, so pytest does not collect it and subclasses do not re-run each other's tests)."""
    PW = "Test-pass-12345"

    @classmethod
    def setUpClass(cls):
        from fastapi.testclient import TestClient
        from app.main import app
        from app import db, security
        cls.TC, cls.app, cls.db = TestClient, app, db
        cls.sfx = secrets.token_hex(3)
        cls.created = {"users": [], "sections": [], "rooms": [], "dates": []}
        with db.transaction() as cur:
            # 3 active sections, 2 active rooms big enough for them, 1 subject with no feature requirement - discovered, never assumed
            secs = db.all_(cur, "SELECT section_id,strength FROM SECTION WHERE status='Active' ORDER BY section_id LIMIT 3")
            need = max([s["strength"] or 0 for s in secs] + [1])
            rooms = db.all_(cur, "SELECT room_id,room_number FROM ROOM WHERE status='Active' AND capacity>=%s ORDER BY room_id LIMIT 2", (need,))
            subj = db.one(cur, "SELECT subject_id FROM SUBJECT WHERE required_feature_id IS NULL ORDER BY subject_id LIMIT 1")
            if len(secs) < 3 or len(rooms) < 2 or not subj:
                raise unittest.SkipTest("need >=3 active sections, >=2 active rooms and a feature-free subject in the database")
            cls.sections = [s["section_id"] for s in secs]
            cls.room, cls.room2 = rooms[0]["room_id"], rooms[1]["room_id"]
            cls.subject = subj["subject_id"]
            ids = {}
            for name, role in (("admin", "ADMIN"), ("cra", "VIEWER"), ("crb", "VIEWER"), ("crc", "VIEWER"), ("viewer", "VIEWER")):
                cur.execute("INSERT INTO USER_ACCOUNT(username,email,full_name,password_hash,role) VALUES(%s,%s,%s,%s,%s)",
                            (f"t_{name}_{cls.sfx}", f"t_{name}_{cls.sfx}@example.invalid", f"T {name}", security.hash_password(cls.PW), role))
                ids[name] = cur.lastrowid
                cls.created["users"].append(cur.lastrowid)
            for who, sec in (("cra", cls.sections[0]), ("crb", cls.sections[1]), ("crc", cls.sections[2])):
                cur.execute("INSERT INTO SECTION_CR_ASSIGNMENT(user_id,section_id,assigned_by_user_id) VALUES(%s,%s,%s)", (ids[who], sec, ids["admin"]))
                cur.execute("UPDATE USER_ACCOUNT SET role='CR' WHERE user_id=%s", (ids[who],))
        cls.ids = ids

    # ---------------------------------------------------------------- isolation
    def setUp(self):
        self.day = self.claim_day()

    @classmethod
    def claim_day(cls):
        """A weekday with no classes, no requests and no published timetable coverage => every room/hour is genuinely free."""
        start = max(dt.date.today(), dt.date(2027, 1, 4))
        for _ in range(500):
            d = start + dt.timedelta(days=random.randint(7, 3000))
            if d.weekday() > 4 or d.isoformat() in cls.created["dates"]:
                continue
            with cls.db.transaction() as cur:
                busy = cls.db.one(cur, """SELECT (SELECT COUNT(*) FROM CLASS_SCHEDULE WHERE class_date=%s)
                    + (SELECT COUNT(*) FROM EXTRA_CLASS_REQUEST WHERE request_date=%s)
                    + (SELECT COUNT(*) FROM TIMETABLE WHERE status='Published' AND %s BETWEEN effective_from AND effective_to) AS n""", (d, d, d))["n"]
            if busy == 0:
                cls.created["dates"].append(d.isoformat())
                return d.isoformat()
        raise unittest.SkipTest("could not find an empty calendar date")

    # ---------------------------------------------------------------- helpers
    def client(self, name):
        c = self.TC(self.app)
        r = c.post("/api/auth/login", json={"username": f"t_{name}_{self.sfx}", "password": self.PW})
        self.assertEqual(r.status_code, 200, r.text)
        c.headers["X-CSRF-Token"] = r.json()["csrf_token"]
        return c

    def mk_class(self, section, start="10:00", end="11:00", room=None):
        r = self.client("admin").post("/api/classes", json={"section_id": section, "subject_id": self.subject, "room_id": room or self.room,
                                                            "date": self.day, "start": start, "end": end})
        self.assertEqual(r.status_code, 201, r.text)
        return r.json()["class_id"]

    def req(self, who, section, start="10:00", end="11:00", room=None):
        return self.client(who).post("/api/requests", json={"section_id": section, "subject_id": self.subject, "room_id": room or self.room,
                                                            "date": self.day, "start": start, "end": end, "purpose": "test"})

    def cancel_as(self, who, class_id, reason="released"):
        r = self.client(who).post(f"/api/classes/{class_id}/cancel", json={"reason": reason})
        self.assertEqual(r.status_code, 200, r.text)

    def new_cr(self, section, tag):
        from app import security
        with self.db.transaction() as cur:
            cur.execute("INSERT INTO USER_ACCOUNT(username,email,full_name,password_hash,role) VALUES(%s,%s,%s,%s,'CR')",
                        (f"t_{tag}_{self.sfx}", f"t_{tag}_{self.sfx}@example.invalid", f"T {tag}", security.hash_password(self.PW)))
            uid = cur.lastrowid
            cur.execute("INSERT INTO SECTION_CR_ASSIGNMENT(user_id,section_id,assigned_by_user_id) VALUES(%s,%s,%s)", (uid, section, self.ids["admin"]))
        self.created["users"].append(uid)
        self.ids[tag] = uid
        return uid

    def notes(self, uid, type_="REQUEST_RECEIVED", entity_id=None):
        with self.db.transaction() as cur:
            q = "SELECT COUNT(*) n FROM NOTIFICATION WHERE user_id=%s AND type=%s" + (" AND entity_id=%s" if entity_id else "")
            return self.db.one(cur, q, (uid, type_) + ((str(entity_id),) if entity_id else ()))["n"]

    def released_slot(self, section, start):
        """Admin books a class for `section`, then cancels it => the slot is released. Returns (start, end)."""
        end = f"{int(start[:2]) + 1:02d}:00"
        self.cancel_as("admin", self.mk_class(section, start, end), "setup")
        return start, end

    # ---------------------------------------------------------------- scoped cleanup
    @classmethod
    def tearDownClass(cls):
        user = os.environ.get("RW_TEST_CLEANUP_USER")
        if not user:
            print("\n[integration] cleanup skipped (set RW_TEST_CLEANUP_USER/PASSWORD to remove this run's t_* test records; "
                  "the least-privilege runtime account cannot delete users, cancellations or audit rows).")
            return
        import pymysql
        from app import config
        conn = pymysql.connect(host=config.DB["host"], port=config.DB["port"], user=user, password=os.environ.get("RW_TEST_CLEANUP_PASSWORD", ""),
                               database=config.DB["database"], charset="utf8mb4")
        try:
            with conn.cursor() as cur:
                cls._cleanup(cur)
            conn.commit()
        finally:
            conn.close()

    @classmethod
    def _cleanup(cls, cur):
        users, dates = cls.created["users"], cls.created["dates"]
        if not users:
            return
        ph = lambda xs: ",".join(["%s"] * len(xs))
        def col(sql, args):
            cur.execute(sql, args)
            return [r[0] for r in cur.fetchall()]
        reqs = col(f"SELECT request_id FROM EXTRA_CLASS_REQUEST WHERE requester_user_id IN ({ph(users)})", users)
        chgs = col(f"SELECT change_id FROM ROOM_CHANGE_REQUEST WHERE requester_user_id IN ({ph(users)})", users)
        classes = col(f"SELECT class_id FROM CLASS_SCHEDULE WHERE class_date IN ({ph(dates)})", dates) if dates else []
        # displacement ids created by THIS run (found via our classes/requests, before those rows are removed). CR users of existing
        # sections may have been notified about them, and those notifications belong to users we do not delete.
        disp = []
        if classes:
            disp += col(f"SELECT displacement_id FROM CLASS_DISPLACEMENT WHERE original_class_id IN ({ph(classes)}) OR displacing_class_id IN ({ph(classes)})"
                        f" OR rescheduled_class_id IN ({ph(classes)})", classes * 3)
        if reqs:
            disp += col(f"SELECT displacement_id FROM CLASS_DISPLACEMENT WHERE request_id IN ({ph(reqs)})", reqs)
        disp = sorted(set(disp))
        # notifications pointing at records WE created (type+id matched together; ids alone could collide across tables)
        for etype, ids_ in (("EXTRA_CLASS_REQUEST", reqs), ("ROOM_CHANGE_REQUEST", chgs), ("CLASS_SCHEDULE", classes), ("SECTION", cls.created["sections"]), ("CLASS_DISPLACEMENT", disp)):
            if ids_:
                cur.execute(f"DELETE FROM NOTIFICATION WHERE entity_type=%s AND entity_id IN ({ph(ids_)})", (etype, *map(str, ids_)))
        cur.execute(f"DELETE FROM NOTIFICATION WHERE user_id IN ({ph(users)})", users)
        # CLASS_DISPLACEMENT (migration 006) references classes + requests with ON DELETE RESTRICT: remove this run's rows first
        if classes:
            cur.execute(f"DELETE FROM CLASS_DISPLACEMENT WHERE original_class_id IN ({ph(classes)}) OR displacing_class_id IN ({ph(classes)})"
                        f" OR rescheduled_class_id IN ({ph(classes)})", classes * 3)
        if reqs:
            cur.execute(f"DELETE FROM CLASS_DISPLACEMENT WHERE request_id IN ({ph(reqs)})", reqs)
        if chgs:
            cur.execute(f"DELETE FROM ROOM_CHANGE_REQUEST WHERE change_id IN ({ph(chgs)})", chgs)
        if reqs:
            cur.execute(f"DELETE FROM EXTRA_CLASS_REQUEST WHERE request_id IN ({ph(reqs)})", reqs)
        if classes:
            cur.execute(f"DELETE FROM CLASS_CANCELLATION WHERE class_id IN ({ph(classes)})", classes)
            cur.execute(f"DELETE FROM CLASS_SCHEDULE WHERE class_id IN ({ph(classes)})", classes)
        cur.execute(f"DELETE FROM AUDIT_LOG WHERE actor_user_id IN ({ph(users)})", users)
        cur.execute(f"DELETE FROM SECTION_CR_ASSIGNMENT WHERE user_id IN ({ph(users)})", users)
        if cls.created["sections"]:
            cur.execute(f"DELETE FROM SECTION_CR_ASSIGNMENT WHERE section_id IN ({ph(cls.created['sections'])})", cls.created["sections"])
            cur.execute(f"DELETE FROM SECTION WHERE section_id IN ({ph(cls.created['sections'])})", cls.created["sections"])
        if cls.created["rooms"]:
            cur.execute(f"DELETE FROM ROOM WHERE room_id IN ({ph(cls.created['rooms'])})", cls.created["rooms"])
        cur.execute(f"DELETE FROM USER_ACCOUNT WHERE user_id IN ({ph(users)})", users)   # sessions cascade
        print(f"\n[integration] cleaned {len(users)} users, {len(reqs)+len(chgs)} requests, {len(classes)} classes, "
              f"{len(cls.created['sections'])} sections, {len(cls.created['rooms'])} rooms created by this run.")


@skip_unless_enabled
class ApiFlow(IntegrationBase, unittest.TestCase):
    # ---- authentication / authorisation
    def test_signup_is_viewer_and_rejects_role_field(self):
        c = self.TC(self.app); u = f"su_{secrets.token_hex(3)}"
        r = c.post("/api/auth/signup", json={"username": u, "email": f"{u}@example.invalid", "full_name": "S", "password": self.PW, "role": "ADMIN"})
        self.assertEqual(r.status_code, 422)                          # mass assignment blocked
        r = c.post("/api/auth/signup", json={"username": u, "email": f"{u}@example.invalid", "full_name": "S", "password": self.PW})
        self.assertEqual(r.status_code, 201); self.assertEqual(r.json()["user"]["role"], "VIEWER")
        self.created["users"].append(r.json()["user"]["user_id"])

    def test_unauthenticated_rejected(self):
        self.assertEqual(self.TC(self.app).get("/api/rooms").status_code, 401)

    def test_csrf_required(self):
        c = self.client("admin"); c.headers.pop("X-CSRF-Token")
        self.assertEqual(c.post("/api/classes/1/cancel", json={"reason": "x"}).status_code, 403)

    def test_viewer_cannot_write(self):
        v = self.client("viewer"); body = {"section_id": self.sections[0], "subject_id": self.subject, "room_id": self.room, "date": self.day, "start": "10:00", "end": "11:00"}
        self.assertEqual(v.get("/api/rooms").status_code, 200)
        self.assertEqual(v.post("/api/classes", json=body).status_code, 403)
        self.assertEqual(v.post("/api/requests", json=body).status_code, 403)
        self.assertEqual(v.get("/api/requests").status_code, 403)
        self.assertEqual(v.post("/api/admin/rooms", json={"block": "X", "room_number": "1", "capacity": 10}).status_code, 403)

    def test_cr_cannot_use_admin_or_self_promote(self):
        c = self.client("cra")
        self.assertEqual(c.post("/api/admin/cr-assignments", json={"user_id": self.ids["cra"], "section_id": self.sections[1]}).status_code, 403)
        self.assertEqual(c.patch(f"/api/admin/users/{self.ids['cra']}", json={"role": "ADMIN"}).status_code, 403)
        self.assertEqual(c.post("/api/classes", json={"section_id": self.sections[0], "subject_id": self.subject, "room_id": self.room,
                                                      "date": self.day, "start": "12:00", "end": "13:00"}).status_code, 403)

    # ---- cancellation / release
    def test_cancel_scope_reason_and_release(self):
        cid = self.mk_class(self.sections[0], "08:00", "09:00")
        self.assertEqual(self.client("crb").post(f"/api/classes/{cid}/cancel", json={"reason": "x"}).status_code, 403)   # cross-section
        self.assertEqual(self.client("cra").post(f"/api/classes/{cid}/cancel", json={"reason": ""}).status_code, 422)     # reason required
        state = lambda: [r for r in self.client("viewer").get(f"/api/availability?date={self.day}&start=08:00&end=09:00").json()["rooms"] if r["room_id"] == self.room][0]
        self.assertEqual(state()["state"], "busy")
        self.assertEqual(self.client("cra").post(f"/api/classes/{cid}/cancel", json={"reason": "sick"}).status_code, 200)
        row = state(); self.assertEqual(row["state"], "available"); self.assertTrue(row["released_classes"])     # derived, not a flag
        self.assertEqual(self.client("cra").post(f"/api/classes/{cid}/cancel", json={"reason": "again"}).status_code, 409)
        with self.db.transaction() as cur:                                                                        # history kept, not deleted
            self.assertEqual(self.db.one(cur, "SELECT status FROM CLASS_SCHEDULE WHERE class_id=%s", (cid,))["status"], "Cancelled")
            self.assertTrue(self.db.one(cur, "SELECT 1 FROM CLASS_CANCELLATION WHERE class_id=%s AND cancelled_by_user_id=%s", (cid, self.ids["cra"])))
            self.assertTrue(self.db.one(cur, "SELECT 1 FROM AUDIT_LOG WHERE entity_type='CLASS_SCHEDULE' AND entity_id=%s AND action='CLASS_CANCELLED'", (str(cid),)))

    # ---- CR-to-CR workflow
    def test_request_approve_flow_self_approval_and_stale(self):
        cid = self.mk_class(self.sections[0], "11:00", "12:00"); self.cancel_as("cra", cid)
        r = self.req("crb", self.sections[1], "11:00", "12:00"); self.assertEqual(r.status_code, 201, r.text)
        self.assertEqual(r.json()["routed_to"], "CR"); rid = r.json()["request_id"]
        dec = lambda who: self.client(who).post(f"/api/requests/extra/{rid}/decision", json={"decision": "approve"})
        self.assertEqual(dec("crb").status_code, 403)                                                                    # self-approval
        self.assertEqual(dec("crc").status_code, 403)                                                                    # unrelated CR
        self.assertEqual(self.client("crb").post("/api/requests", json={"section_id": self.sections[0], "subject_id": self.subject, "room_id": self.room,
                                                                         "date": self.day, "start": "15:00", "end": "16:00"}).status_code, 403)  # not own section
        d = dec("cra"); self.assertEqual(d.status_code, 200, d.text)
        self.assertEqual(dec("cra").status_code, 409)                                                                    # stale
        with self.db.transaction() as cur:
            q = self.db.one(cur, "SELECT status,resulting_class_id,decided_by_user_id FROM EXTRA_CLASS_REQUEST WHERE request_id=%s", (rid,))
            self.assertEqual((q["status"], q["decided_by_user_id"]), ("Approved", self.ids["cra"]))
            self.assertEqual(self.db.one(cur, "SELECT status FROM CLASS_SCHEDULE WHERE class_id=%s", (q["resulting_class_id"],))["status"], "Scheduled")
            self.assertEqual(self.db.one(cur, "SELECT status FROM CLASS_SCHEDULE WHERE class_id=%s", (cid,))["status"], "Cancelled")      # old record preserved
            self.assertTrue(self.db.one(cur, "SELECT 1 FROM NOTIFICATION WHERE user_id=%s AND type='REQUEST_APPROVED'", (self.ids["crb"],)))

    def test_reject_requires_reason_and_keeps_schedule(self):
        cid = self.mk_class(self.sections[0], "13:00", "14:00"); self.cancel_as("cra", cid, "r")
        rid = self.req("crb", self.sections[1], "13:00", "14:00").json()["request_id"]
        url = f"/api/requests/extra/{rid}/decision"
        self.assertEqual(self.client("cra").post(url, json={"decision": "reject"}).status_code, 400)
        self.assertEqual(self.client("cra").post(url, json={"decision": "reject", "reason": "need it"}).status_code, 200)
        with self.db.transaction() as cur:
            self.assertEqual(self.db.one(cur, "SELECT COUNT(*) n FROM CLASS_SCHEDULE WHERE room_id=%s AND class_date=%s AND status='Scheduled' AND start_time='13:00:00'", (self.room, self.day))["n"], 0)

    def test_occupied_slot_replaced_on_approval(self):
        cid = self.mk_class(self.sections[0], "14:00", "15:00")
        rid = self.req("crb", self.sections[1], "14:00", "15:00").json()["request_id"]
        self.assertEqual(self.client("cra").post(f"/api/requests/extra/{rid}/decision", json={"decision": "approve"}).status_code, 200)
        with self.db.transaction() as cur:
            self.assertEqual(self.db.one(cur, "SELECT status FROM CLASS_SCHEDULE WHERE class_id=%s", (cid,))["status"], "Cancelled")

    def test_section_clash_blocks_request(self):
        self.mk_class(self.sections[1], "16:00", "17:00", room=self.room2)       # requester's own section is busy in another room
        r = self.req("crb", self.sections[1], "16:00", "17:00")                  # target room is free, but the section is not
        self.assertEqual(r.status_code, 409); self.assertIn("section_conflict", str(r.json()))

    def test_concurrent_approvals_only_one_wins(self):
        cid = self.mk_class(self.sections[0], "09:00", "10:00"); self.cancel_as("cra", cid, "r")
        r1 = self.req("crb", self.sections[1], "09:00", "10:00").json()["request_id"]
        r2 = self.req("crc", self.sections[2], "09:00", "10:00").json()["request_id"]
        a, b = self.client("admin"), self.client("admin"); out = []
        def go(c, rid): out.append(c.post(f"/api/requests/extra/{rid}/decision", json={"decision": "approve"}).status_code)
        ts = [threading.Thread(target=go, args=(a, r1)), threading.Thread(target=go, args=(b, r2))]
        [t.start() for t in ts]; [t.join() for t in ts]
        self.assertEqual(sorted(out), [200, 409], out)                           # exactly one booking; the loser failed cleanly
        with self.db.transaction() as cur:
            n = self.db.one(cur, "SELECT COUNT(*) n FROM CLASS_SCHEDULE WHERE room_id=%s AND class_date=%s AND start_time='09:00:00' AND status='Scheduled'", (self.room, self.day))["n"]
            self.assertEqual(n, 1)

    def test_room_change_flow_and_original_preserved_on_failure(self):
        cid = self.mk_class(self.sections[0], "12:00", "13:00")
        r = self.client("cra").post("/api/requests/room-change", json={"class_id": cid, "requested_room_id": self.room2, "reason": "projector"})
        self.assertEqual(r.status_code, 201, r.text); chg = r.json()["change_id"]
        url = f"/api/requests/room-change/{chg}/decision"
        self.assertEqual(self.client("cra").post(url, json={"decision": "approve"}).status_code, 403)             # requester cannot approve
        self.assertEqual(self.client("admin").post(url, json={"decision": "approve"}).status_code, 200)
        with self.db.transaction() as cur:
            self.assertEqual(self.db.one(cur, "SELECT room_id FROM CLASS_SCHEDULE WHERE class_id=%s", (cid,))["room_id"], self.room2)

    def test_admin_can_manage_and_audit_visible(self):
        a = self.client("admin"); block = f"T{self.sfx}"
        r = a.post("/api/admin/rooms", json={"block": block, "room_number": "1", "capacity": 40}); self.assertEqual(r.status_code, 201, r.text)
        self.created["rooms"].append(r.json()["room_id"])
        self.assertEqual(a.post("/api/admin/rooms", json={"block": block, "room_number": "1", "capacity": 40}).status_code, 409)   # unique block+number
        self.assertEqual(a.post("/api/admin/rooms", json={"block": "x", "room_number": "2", "capacity": 0}).status_code, 422)       # capacity > 0
        self.assertTrue(a.get("/api/admin/audit?entity_type=ROOM").json()["items"])


@skip_unless_enabled
class Routing(IntegrationBase, unittest.TestCase):
    """Regression for MySQL 8 error 3065 on POST /api/requests + routing / notification / authorisation."""
    def test_post_requests_no_longer_fails_with_3065(self):
        s, e = self.released_slot(self.sections[0], "08:00")
        r = self.req("crb", self.sections[1], s, e)
        self.assertEqual(r.status_code, 201, r.text)                              # was HTTP 503 'backend unavailable' (3065)

    def test_one_cr_assigned_gets_exactly_one_notification(self):
        s, e = self.released_slot(self.sections[0], "09:00")
        rid = self.req("crb", self.sections[1], s, e).json()["request_id"]
        self.assertEqual(self.notes(self.ids["cra"], entity_id=rid), 1)
        self.assertEqual(self.notes(self.ids["crb"], entity_id=rid), 0)           # requester is never a recipient
        self.assertEqual(self.notes(self.ids["crc"], entity_id=rid), 0)           # unrelated CR is not notified

    def test_multiple_crs_each_notified_once_primary_is_oldest(self):
        second = self.new_cr(self.sections[0], f"cra2{secrets.token_hex(2)}")
        s, e = self.released_slot(self.sections[0], "10:00")
        r = self.req("crb", self.sections[1], s, e); self.assertEqual(r.status_code, 201, r.text); rid = r.json()["request_id"]
        with self.db.transaction() as cur:
            q = self.db.one(cur, "SELECT recipient_role,recipient_user_id FROM EXTRA_CLASS_REQUEST WHERE request_id=%s", (rid,))
            # expected primary = oldest ACTIVE CR assignment on the section, excluding the requester - derived from the DB so
            # pre-existing real CRs on this section cannot make the test fail
            oldest = self.db.one(cur, """SELECT a.user_id FROM SECTION_CR_ASSIGNMENT a JOIN USER_ACCOUNT u ON u.user_id=a.user_id
                WHERE a.section_id=%s AND a.is_active=1 AND u.is_active=1 AND u.role='CR' AND a.user_id<>%s
                GROUP BY a.user_id ORDER BY MIN(a.assignment_id) LIMIT 1""", (self.sections[0], self.ids["crb"]))["user_id"]
        self.assertEqual((q["recipient_role"], q["recipient_user_id"]), ("CR", oldest))
        self.assertEqual(self.notes(self.ids["cra"], entity_id=rid), 1)
        self.assertEqual(self.notes(second, entity_id=rid), 1)                    # nobody missed, nobody doubled

    def test_duplicate_active_assignment_is_impossible(self):
        r = self.client("admin").post("/api/admin/cr-assignments", json={"user_id": self.ids["cra"], "section_id": self.sections[0]})
        self.assertEqual(r.status_code, 409)                                      # API guard
        import pymysql
        with self.assertRaises(pymysql.err.IntegrityError):                       # DB guard (uq_active_assignment)
            with self.db.transaction() as cur:
                cur.execute("INSERT INTO SECTION_CR_ASSIGNMENT(user_id,section_id,assigned_by_user_id) VALUES(%s,%s,%s)",
                            (self.ids["cra"], self.sections[0], self.ids["admin"]))

    def test_no_cr_in_target_section_routes_to_admin(self):
        a = self.client("admin")
        with self.db.transaction() as cur:
            br = self.db.one(cur, "SELECT branch_id FROM BRANCH ORDER BY branch_id LIMIT 1")["branch_id"]
        for _ in range(20):                                                       # a section nobody is CR of; retry on label collision
            sec = a.post("/api/admin/sections", json={"branch_id": br, "semester": 10, "section_no": random.randint(1, 250), "strength": 30})
            if sec.status_code == 201:
                break
        self.assertEqual(sec.status_code, 201, sec.text)
        empty = sec.json()["section_id"]; self.created["sections"].append(empty)
        s, e = self.released_slot(empty, "11:00")
        r = self.req("crb", self.sections[1], s, e); self.assertEqual(r.status_code, 201, r.text)
        self.assertEqual(r.json()["routed_to"], "ADMIN"); rid = r.json()["request_id"]
        self.assertEqual(self.notes(self.ids["admin"], entity_id=rid), 1)
        for cr in ("cra", "crb", "crc"):
            self.assertEqual(self.notes(self.ids[cr], entity_id=rid), 0)
        url = f"/api/requests/extra/{rid}/decision"
        self.assertEqual(self.client("cra").post(url, json={"decision": "approve"}).status_code, 403)        # a CR cannot decide an ADMIN-routed request
        self.assertEqual(self.client("admin").post(url, json={"decision": "approve"}).status_code, 200)

    def test_admin_create_returns_the_new_rows_own_id(self):
        """Regression: POST /api/admin/sections used to return AUDIT_LOG's auto-increment id (cursor.lastrowid is overwritten by the
        audit INSERT). That id pointed at a different/non-existent section, so later class creation failed with 409 section_missing."""
        a = self.client("admin")
        with self.db.transaction() as cur:
            br = self.db.one(cur, "SELECT branch_id FROM BRANCH ORDER BY branch_id LIMIT 1")["branch_id"]
        for _ in range(20):
            r = a.post("/api/admin/sections", json={"branch_id": br, "semester": 10, "section_no": random.randint(1, 250), "strength": 30})
            if r.status_code == 201:
                break
        self.assertEqual(r.status_code, 201, r.text)
        sid = r.json()["section_id"]; self.created["sections"].append(sid)
        with self.db.transaction() as cur:
            row = self.db.one(cur, "SELECT label FROM SECTION WHERE section_id=%s", (sid,))
            audit = self.db.one(cur, "SELECT entity_id FROM AUDIT_LOG WHERE action='SECTION_CREATED' AND entity_type='SECTION' "
                                     "ORDER BY audit_id DESC LIMIT 1")
        self.assertIsNotNone(row, f"returned section_id {sid} does not exist in SECTION")
        self.assertEqual(row["label"], r.json()["label"])                          # the returned id is the section we just created
        self.assertEqual(str(sid), audit["entity_id"])                             # ...and agrees with the audit trail

    def test_authorisation_on_routed_request(self):
        s, e = self.released_slot(self.sections[0], "12:00")
        rid = self.req("crb", self.sections[1], s, e).json()["request_id"]
        url, body = f"/api/requests/extra/{rid}/decision", {"decision": "approve"}
        self.assertEqual(self.client("crb").post(url, json=body).status_code, 403)       # requester
        self.assertEqual(self.client("crc").post(url, json=body).status_code, 403)       # unrelated CR
        self.assertEqual(self.client("viewer").post(url, json=body).status_code, 403)    # viewer
        self.assertEqual(self.client("cra").post(url, json=body).status_code, 200)       # the section's CR


if __name__ == "__main__":
    unittest.main()
