"""MySQL 8 integration tests: cancellation from the Daily Schedule, room release, Dismiss, and that existing rescheduling still works.
Enable:  RW_INTEGRATION=1 python -m pytest tests/test_displacement_dismiss_integration.py -v     (needs db/006 and db/007 applied)

Same isolation rules as test_displacement_integration.py (own far-future weekday per test, weekly template snapshot-compared).
The helpers are borrowed from DisplacementFlow by assignment, so none of ITS tests are collected a second time."""
import sys, pathlib, unittest
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
from tests.test_api_integration import IntegrationBase, skip_unless_enabled
from tests.test_displacement_integration import DisplacementFlow as _F


@skip_unless_enabled
class DismissAndCancel(IntegrationBase, unittest.TestCase):
    weekly, decide, displace, q, scheduled_in, daily, resched = (_F.weekly, _F.decide, _F.displace, _F.q, _F.scheduled_in, _F.daily, _F.resched)

    def dismiss(self, who, did): return self.client(who).post(f"/api/displaced-classes/{did}/dismiss")
    def status(self, did): return self.q("SELECT status FROM CLASS_DISPLACEMENT WHERE displacement_id=%s", (did,))[0]["status"]
    def listed(self, who, status): return [i["displacement_id"] for i in self.client(who).get(f"/api/displaced-classes?status={status}").json()["items"]]

    # ---------------------------------------------------------------- cancellation from the Daily Schedule
    def test_daily_schedule_row_has_everything_the_details_dialog_shows(self):
        cid = self.mk_class(self.sections[0], "09:00", "10:00")
        row = {i["class_id"]: i for i in self.daily("cra")["items"]}[cid]
        for key in ("class_id", "subject_code", "section_label", "teacher_name", "room_number", "class_date", "start_time", "end_time", "status", "status_label", "section_id"):
            self.assertIn(key, row)
        self.assertEqual((row["status"], row["class_date"], row["section_id"]), ("scheduled", self.day, self.sections[0]))

    def test_cancel_releases_exactly_that_date_and_time_and_keeps_history(self):
        before = self.weekly()
        cid = self.mk_class(self.sections[0], "09:00", "10:00")
        other = self.mk_class(self.sections[0], "11:00", "12:00")                       # another slot, same day and room
        free = lambda: [r for r in self.client("viewer").get(f"/api/availability?date={self.day}&start=09:00&end=10:00").json()["rooms"] if r["room_id"] == self.room][0]
        self.assertEqual(free()["state"], "busy")
        self.assertEqual(self.client("cra").post(f"/api/classes/{cid}/cancel", json={"reason": "teacher unwell"}).status_code, 200)
        self.assertEqual(free()["state"], "available")                                  # cancelled classes do not occupy the room
        self.assertEqual(self.q("SELECT status FROM CLASS_SCHEDULE WHERE class_id=%s", (other,))[0]["status"], "Scheduled")   # only that slot
        again = self.mk_class(self.sections[1], "09:00", "10:00")                       # the freed slot can be booked straight away
        self.assertTrue(again)
        self.assertEqual(self.q("SELECT COUNT(*) n FROM CLASS_CANCELLATION WHERE class_id=%s", (cid,))[0]["n"], 1)   # history kept
        self.assertEqual(self.q("SELECT status FROM CLASS_SCHEDULE WHERE class_id=%s", (cid,))[0]["status"], "Cancelled")
        self.assertEqual(self.weekly(), before)                                         # weekly template untouched
        cancelled = {i["class_id"]: i for i in self.daily("cra")["items"]}[cid]
        self.assertEqual(cancelled["status"], "cancelled")                              # Daily Schedule shows it after refresh

    def test_cancel_permissions_and_reason(self):
        cid = self.mk_class(self.sections[0], "09:00", "10:00")
        post = lambda who, body=None: self.client(who).post(f"/api/classes/{cid}/cancel", json=body if body is not None else {"reason": "x y"})
        self.assertEqual(post("crb").status_code, 403)                                  # CR of another section
        self.assertEqual(post("viewer").status_code, 403)
        self.assertEqual(self.TC(self.app).post(f"/api/classes/{cid}/cancel", json={"reason": "x y"}).status_code, 401)
        self.assertEqual(post("cra", {"reason": ""}).status_code, 422)                  # reason required
        self.assertEqual(self.q("SELECT status FROM CLASS_SCHEDULE WHERE class_id=%s", (cid,))[0]["status"], "Scheduled")
        self.assertEqual(post("admin").status_code, 200)                                # ADMIN may cancel any section
        self.assertEqual(post("cra").status_code, 409)                                  # already cancelled
        self.assertEqual(self.notes(self.ids["crb"], "CLASS_CANCELLED", cid), 1)        # existing notification logic still fires

    # ---------------------------------------------------------------- dismiss
    def test_dismiss_records_who_and_when_and_keeps_every_record(self):
        before = self.weekly()
        holder, rid, did = self.displace()
        r = self.dismiss("crb", did); self.assertEqual(r.status_code, 200, r.text)
        d = self.q("SELECT * FROM CLASS_DISPLACEMENT WHERE displacement_id=%s", (did,))[0]
        self.assertEqual((d["status"], d["dismissed_by_user_id"]), ("Dismissed", self.ids["crb"])); self.assertIsNotNone(d["dismissed_at"])
        self.assertIsNone(d["rescheduled_class_id"])
        self.assertEqual(self.q("SELECT status FROM CLASS_SCHEDULE WHERE class_id=%s", (holder,))[0]["status"], "Cancelled")       # nothing deleted
        self.assertEqual(self.q("SELECT COUNT(*) n FROM CLASS_CANCELLATION WHERE class_id=%s", (holder,))[0]["n"], 1)
        self.assertEqual(self.q("SELECT status FROM EXTRA_CLASS_REQUEST WHERE request_id=%s", (rid,))[0]["status"], "Approved")
        actions = {x["action"] for x in self.q("SELECT action FROM AUDIT_LOG WHERE entity_type='CLASS_DISPLACEMENT' AND entity_id=%s", (str(did),))}
        self.assertTrue({"CLASS_DISPLACED", "CLASS_DISPLACEMENT_DISMISSED"} <= actions)    # earlier audit rows survive, new one added
        self.assertEqual(self.notes(self.ids["admin"], "CLASS_DISPLACEMENT_DISMISSED", did), 1)    # relevant users told ...
        self.assertEqual(self.notes(self.ids["crb"], "CLASS_DISPLACEMENT_DISMISSED", did), 0)      # ... except the actor
        self.assertEqual(self.notes(self.ids["crc"], "CLASS_DISPLACEMENT_DISMISSED", did), 0)      # unrelated CR is not
        self.assertEqual(self.weekly(), before)

    def test_dismiss_permissions(self):
        holder, rid, did = self.displace()
        self.assertEqual(self.dismiss("viewer", did).status_code, 403)
        self.assertEqual(self.dismiss("crc", did).status_code, 403)                    # unrelated CR
        self.assertEqual(self.dismiss("cra", did).status_code, 403)                    # the requesting CR is not the affected section's CR
        self.assertEqual(self.TC(self.app).post(f"/api/displaced-classes/{did}/dismiss").status_code, 401)
        self.assertEqual(self.status(did), "Awaiting")
        self.assertEqual(self.dismiss("admin", did).status_code, 200)                  # ADMIN may

    def test_dismissed_disappears_from_pending_and_shows_under_dismissed(self):
        holder, rid, did = self.displace()
        self.assertIn(did, self.listed("crb", "Awaiting"))
        self.assertEqual(self.dismiss("crb", did).status_code, 200)
        self.assertNotIn(did, self.listed("crb", "Awaiting")); self.assertNotIn(did, self.listed("admin", "Awaiting"))
        self.assertIn(did, self.listed("crb", "Dismissed")); self.assertNotIn(did, self.listed("crb", "Rescheduled"))
        item = [i for i in self.client("crb").get("/api/displaced-classes?status=Dismissed").json()["items"] if i["displacement_id"] == did][0]
        self.assertEqual((item["status_label"], item["can_reschedule"], item["can_dismiss"]), ("Dismissed", False, False))
        self.assertEqual(self.client("viewer").get("/api/displaced-classes?status=Dismissed").status_code, 403)
        daily = {i["class_id"]: i for i in self.daily("crb")["items"]}[holder]
        self.assertEqual((daily["status"], daily["displaced_state"]), ("displaced", "Dismissed"))

    def test_dismissed_cannot_be_rescheduled_or_dismissed_again(self):
        holder, rid, did = self.displace()
        self.assertEqual(self.dismiss("crb", did).status_code, 200)
        self.assertEqual(self.resched("crb", did, self.room2).status_code, 409)
        self.assertEqual(self.resched("admin", did, self.room2).status_code, 409)
        self.assertEqual(self.client("crb").get(f"/api/displaced-classes/{did}/available-rooms").status_code, 409)
        self.assertEqual(self.dismiss("crb", did).status_code, 409)
        self.assertEqual(len(self.scheduled_in(self.room2)), 0); self.assertEqual(self.status(did), "Dismissed")

    def test_rescheduled_cannot_be_dismissed_and_rescheduling_still_works(self):
        holder, rid, did = self.displace()
        r = self.resched("crb", did, self.room2); self.assertEqual(r.status_code, 200, r.text)      # existing behaviour intact
        self.assertEqual(self.status(did), "Rescheduled")
        self.assertEqual(self.dismiss("crb", did).status_code, 409)
        self.assertEqual(self.status(did), "Rescheduled")

    def test_rescheduled_booking_can_be_cancelled_and_history_is_preserved(self):
        before = self.weekly()
        holder, rid, did = self.displace()
        self.assertEqual(self.resched("crb", did, self.room2).status_code, 200)
        new_id = self.q("SELECT rescheduled_class_id FROM CLASS_DISPLACEMENT WHERE displacement_id=%s", (did,))[0]["rescheduled_class_id"]
        row = {i["class_id"]: i for i in self.daily("crb")["items"]}[new_id]
        self.assertEqual((row["status"], row["can_cancel"]), ("rescheduled", True))                  # the server says it is cancellable
        self.assertEqual(self.client("crc").post(f"/api/classes/{new_id}/cancel", json={"reason": "not mine"}).status_code, 403)   # same scope rules
        r = self.client("crb").post(f"/api/classes/{new_id}/cancel", json={"reason": "no longer needed"}); self.assertEqual(r.status_code, 200, r.text)
        self.assertEqual(self.q("SELECT status FROM CLASS_SCHEDULE WHERE class_id=%s", (new_id,))[0]["status"], "Cancelled")
        self.assertEqual(self.client("crb").post(f"/api/classes/{new_id}/cancel", json={"reason": "again"}).status_code, 409)
        d = self.q("SELECT status, rescheduled_class_id FROM CLASS_DISPLACEMENT WHERE displacement_id=%s", (did,))[0]
        self.assertEqual((d["status"], d["rescheduled_class_id"]), ("Rescheduled", new_id))          # link kept, nothing reset
        self.assertEqual(self.q("SELECT status FROM CLASS_SCHEDULE WHERE class_id=%s", (holder,))[0]["status"], "Cancelled")   # original untouched
        self.assertEqual(self.q("SELECT COUNT(*) n FROM CLASS_CANCELLATION WHERE class_id IN (%s,%s)", (holder, new_id))[0]["n"], 2)   # both cancellations kept
        actions = {x["action"] for x in self.q("SELECT action FROM AUDIT_LOG WHERE entity_type='CLASS_DISPLACEMENT' AND entity_id=%s", (str(did),))}
        self.assertTrue({"CLASS_DISPLACED", "CLASS_RESCHEDULED", "RESCHEDULED_CLASS_CANCELLED"} <= actions)
        self.assertEqual(self.dismiss("crb", did).status_code, 409)                                   # still not dismissible / reschedulable again
        self.assertEqual(self.resched("crb", did, self.room2).status_code, 409)
        self.assertEqual(self.weekly(), before)

    def test_database_refuses_inconsistent_dismissed_rows(self):
        holder, rid, did = self.displace()
        with self.assertRaises(Exception):                                       # CHECK ck_disp_state_v2: Dismissed needs dismissed_at
            with self.db.transaction() as cur:
                cur.execute("UPDATE CLASS_DISPLACEMENT SET status='Dismissed' WHERE displacement_id=%s", (did,))


if __name__ == "__main__":
    unittest.main()
