"""Regression for MySQL error 3065 (SELECT DISTINCT ... ORDER BY a column not in the select list) and the routing
decisions built on cr_ids_for_section(). Runs WITHOUT a database (scripted cursor). The same scenarios against a real
MySQL 8 are in test_api_integration.py::Routing (RW_INTEGRATION=1)."""
import re, sys, pathlib, unittest
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
from tests._isolation import offline_imports
with offline_imports():            # fakes exist only inside this block; sys.modules (incl. app.*) is restored on exit
    from app import common, workflow as wf
APP = pathlib.Path(__file__).resolve().parent.parent / "app"

class Script:
    """Cursor double: records every SQL string, returns queued results in order."""
    def __init__(self, *results): self.q, self.sql, self.cur = list(results), [], None
    def execute(self, sql, args=()): self.sql.append(" ".join(sql.split())); self.cur = self.q.pop(0) if self.q else []
    def fetchall(self): return self.cur if isinstance(self.cur, list) else [self.cur]
    def fetchone(self):
        if isinstance(self.cur, list): return self.cur[0] if self.cur else None
        return self.cur

class Mysql8Safe(unittest.TestCase):
    def test_cr_query_has_no_distinct_order_by_conflict(self):
        c = Script([{"user_id": 3}]); common.cr_ids_for_section(c, 10, exclude_user=7)
        sql = c.sql[0]
        self.assertNotIn("DISTINCT", sql.upper())
        self.assertRegex(sql, r"GROUP BY a\.user_id ORDER BY MIN\(a\.assignment_id\)")
    def test_no_select_distinct_with_order_by_anywhere(self):
        """Static guard over every SQL string in the app: DISTINCT + ORDER BY on a non-selected column is MySQL-8 invalid."""
        for py in list(APP.rglob("*.py")):
            for m in re.finditer(r'"""(.*?)"""|"((?:[^"\\\n]|\\.)*)"', py.read_text(encoding="utf-8"), re.S):
                sql = " ".join((m.group(1) or m.group(2) or "").split())
                if re.search(r"SELECT DISTINCT", sql, re.I) and re.search(r"ORDER BY", sql, re.I):
                    sel = re.search(r"SELECT DISTINCT (.*?) FROM", sql, re.I).group(1)
                    order = re.search(r"ORDER BY (.*?)(?: LIMIT|$)", sql, re.I).group(1)
                    for col in [c.strip().split()[0] for c in order.split(",")]:
                        self.assertIn(col, sel, f"{py.name}: ORDER BY {col} not in DISTINCT select list: {sql[:90]}")
    def test_every_section_cr_query_excludes_inactive(self):
        c = Script([]); common.cr_ids_for_section(c, 1)
        self.assertIn("a.is_active=1", c.sql[0]); self.assertIn("u.is_active=1", c.sql[0]); self.assertIn("u.role='CR'", c.sql[0])

class RoutingDecisions(unittest.TestCase):
    """route(): [active-in-room rows] -> [released class] -> [CR ids]. Scripted in that order."""
    def route(self, active, released, crs):
        results = [active, released] + ([crs] if (active or released) else [])
        c = Script(*results)
        return wf.route(c, room_id=1, class_date="2027-01-04", start=600, end=660, requester_user_id=7), c
    OWNER = {"class_id": 5, "section_id": 10, "section_label": "x", "subject_code": "S", "room_number": "1", "start_time": 0, "end_time": 0}
    def test_one_cr_assigned(self):
        r, _ = self.route([], {"class_id": 5, "section_id": 10}, [{"user_id": 3}])
        self.assertEqual((r["recipient_role"], r["recipient_user_id"], r["target_section_id"]), ("CR", 3, 10))
    def test_multiple_crs_primary_is_oldest_and_unique(self):
        r, _ = self.route([], {"class_id": 5, "section_id": 10}, [{"user_id": 3}, {"user_id": 4}])
        self.assertEqual((r["recipient_role"], r["recipient_user_id"]), ("CR", 3))
    def test_no_cr_routes_to_admin(self):
        r, _ = self.route([], {"class_id": 5, "section_id": 10}, [])
        self.assertEqual((r["recipient_role"], r["recipient_user_id"], r["target_section_id"]), ("ADMIN", None, 10))
    def test_free_room_never_released_routes_to_admin(self):
        r, c = self.route([], None, [])
        self.assertEqual((r["recipient_role"], r["target_section_id"]), ("ADMIN", None))
        self.assertFalse(any("SECTION_CR_ASSIGNMENT" in s for s in c.sql))      # no CR lookup without a target section
    def test_occupied_slot_targets_holder_section(self):
        r, _ = self.route([self.OWNER], None, [{"user_id": 3}])
        self.assertEqual((r["target_class_id"], r["target_section_id"], r["recipient_user_id"]), (5, 10, 3))
    def test_requester_is_excluded_from_recipient_lookup(self):
        _, c = self.route([], {"class_id": 5, "section_id": 10}, [])
        self.assertTrue(any("a.user_id<>" in s for s in c.sql))

class NotificationRecipients(unittest.TestCase):
    def test_notify_dedups_and_skips_requester(self):
        c = Script(); common.notify(c, [3, 4, 3, None, 7], "REQUEST_RECEIVED", "m", exclude=7)
        self.assertEqual(len([s for s in c.sql if s.startswith("INSERT INTO NOTIFICATION")]), 2)

if __name__ == "__main__":
    unittest.main()
