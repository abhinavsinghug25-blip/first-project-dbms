"""Offline tests (no MySQL / FastAPI) for dismissing displaced classes, the 007 migration, and the "reuse, don't duplicate" rules.
Run:  python -m unittest tests.test_dismiss_unit -v
Same behaviour against a real MySQL 8: tests/test_displacement_dismiss_integration.py (RW_INTEGRATION=1)."""
import re, sys, pathlib, unittest, datetime as dt
from unittest import mock
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
from tests._isolation import offline_imports
with offline_imports():
    from app import displacement as dsp, workflow as wf   # one import session => one ApiError class
    from app.errors import ApiError

BACKEND = pathlib.Path(__file__).resolve().parent.parent
ROOT = BACKEND.parent


class Script:
    def __init__(self, *results): self.q, self.sql, self.cur, self.rowcount, self.lastrowid = list(results), [], None, 1, 1
    def execute(self, sql, args=()): self.sql.append(" ".join(sql.split())); self.cur = self.q.pop(0) if self.q else []
    def fetchall(self): return self.cur if isinstance(self.cur, list) else [self.cur]
    def fetchone(self):
        if isinstance(self.cur, list): return self.cur[0] if self.cur else None
        return self.cur

ROW = {"displacement_id": 1, "displacement_status": "Awaiting", "section_id": 10, "original_class_id": 5, "request_id": 9,
       "class_date": dt.date(2099, 1, 5), "start_time": "10:00", "end_time": "11:00", "subject_code": "DBMS", "section_label": "Section A",
       "original_room": "301", "subject_id": 1, "teacher_id": 2, "requesting_section": "Section B"}
CR_A, CR_OTHER, ADMIN, VIEWER = ({"user_id": 2, "role": "CR", "full_name": "Cara"}, {"user_id": 3, "role": "CR"},
                                 {"user_id": 1, "role": "ADMIN", "full_name": "Ada"}, {"user_id": 4, "role": "VIEWER"})


def run_dismiss(user, row=None, scope=({"section_id": 10},), rowcount=1):
    """Calls dismiss() with audit/notify/recipient lookups captured. Returns (result_or_exception, cursor, captured)."""
    cap = {"audit": [], "notify": []}
    c = Script(dict(row or ROW), list(scope)); c.rowcount = rowcount
    with mock.patch.object(dsp.common, "audit", lambda *a, **k: cap["audit"].append(a)), \
         mock.patch.object(dsp.common, "notify", lambda *a, **k: cap["notify"].append((a, k))), \
         mock.patch.object(dsp.common, "cr_ids_for_section", lambda cur, sid, **k: [2, 6]), \
         mock.patch.object(dsp.common, "admin_ids", lambda cur: [1]):
        try:
            out = dsp.dismiss(c, user, 1)
        except ApiError as e:
            out = e
    return out, c, cap


class DismissRules(unittest.TestCase):
    def test_assigned_cr_can_dismiss_and_it_is_recorded_and_notified(self):
        out, c, cap = run_dismiss(CR_A)
        self.assertEqual(out["status"], "Dismissed")
        upd = [s for s in c.sql if s.startswith("UPDATE CLASS_DISPLACEMENT")]
        self.assertEqual(len(upd), 1)
        self.assertIn("status='Dismissed'", upd[0]); self.assertIn("dismissed_by_user_id=%s", upd[0]); self.assertIn("dismissed_at=UTC_TIMESTAMP()", upd[0])
        self.assertIn("AND status='Awaiting'", upd[0])                       # compare-and-set: a concurrent reschedule wins cleanly
        self.assertEqual(cap["audit"][0][2], "CLASS_DISPLACEMENT_DISMISSED")  # audit(cur, user_id, action, ...)
        (args, kw), = cap["notify"]
        self.assertEqual(sorted(set(args[1])), [1, 2, 6])                     # section CRs + admins
        self.assertEqual(kw.get("exclude"), 2)                                # the actor is not told about their own action
        self.assertEqual(args[2], "CLASS_DISPLACEMENT_DISMISSED")
        self.assertIn("DBMS", args[3]); self.assertIn("2099-01-05", args[3])

    def test_admin_can_dismiss_any_section(self):
        out, _, _ = run_dismiss(ADMIN, scope=())
        self.assertEqual(out["status"], "Dismissed")

    def test_unrelated_cr_and_viewer_get_403_and_nothing_is_written(self):
        for user, scope in ((CR_OTHER, [{"section_id": 11}]), (VIEWER, [])):
            out, c, cap = run_dismiss(user, scope=scope)
            self.assertIsInstance(out, ApiError); self.assertEqual(out.status, 403, user)
            self.assertFalse(any(s.startswith("UPDATE") for s in c.sql)); self.assertEqual(cap["audit"] + cap["notify"], [])

    def test_only_awaiting_can_be_dismissed(self):
        for status in ("Dismissed", "Rescheduled"):
            out, c, cap = run_dismiss(CR_A, row={**ROW, "displacement_status": status})
            self.assertEqual(out.status, 409, status)
            self.assertFalse(any(s.startswith("UPDATE") for s in c.sql)); self.assertEqual(cap["notify"], [])

    def test_lost_race_rolls_back_without_audit_or_notification(self):
        out, c, cap = run_dismiss(CR_A, rowcount=0)
        self.assertEqual(out.status, 409); self.assertEqual(cap["audit"] + cap["notify"], [])

    def test_dismiss_takes_the_same_row_lock_as_reschedule(self):
        _, c, _ = run_dismiss(CR_A)
        self.assertIn("FOR UPDATE OF d", c.sql[0])

    def test_nothing_is_ever_deleted(self):
        _, c, _ = run_dismiss(CR_A)
        self.assertFalse(any(re.match(r"(DELETE|TRUNCATE|DROP)", s) for s in c.sql))
        self.assertFalse(any("CLASS_SCHEDULE" in s and s.startswith(("UPDATE", "DELETE")) for s in c.sql))     # original class untouched
        self.assertFalse(any("CLASS_CANCELLATION" in s and s.startswith(("UPDATE", "DELETE")) for s in c.sql))


class CancelEligibility(unittest.TestCase):
    """can_cancel() (what the UI uses) must agree with workflow.cancel_class."""
    FUT, PAST = dt.date(2099, 1, 5), dt.date(2000, 1, 5)
    def test_matrix(self):
        mine = {10}
        cases = [(CR_A, "Scheduled", self.FUT, 10, True), (CR_A, "Scheduled", dt.date.today(), 10, True), (CR_A, "Scheduled", self.FUT, 11, False),
                 (CR_A, "Scheduled", self.PAST, 10, False), (CR_A, "Completed", self.FUT, 10, False), (CR_A, "Cancelled", self.FUT, 10, False),
                 (ADMIN, "Scheduled", self.FUT, 11, True), (ADMIN, "Scheduled", self.PAST, 11, False), (ADMIN, "Cancelled", self.FUT, 11, False),
                 (VIEWER, "Scheduled", self.FUT, 10, False)]
        for user, st, date, sec, expect in cases:
            self.assertEqual(dsp.can_cancel(user, st, date, sec, mine), expect, (user["role"], st, date, sec))
    def test_rescheduled_booking_is_a_scheduled_row_and_cancellable(self):
        self.assertEqual(dsp.display_status("Scheduled", None, True)[0], "rescheduled")          # shown as Rescheduled ...
        self.assertTrue(dsp.can_cancel(CR_A, "Scheduled", self.FUT, 10, {10}))                    # ... but it is a 'Scheduled' row
    def test_cancelled_rescheduled_slot_is_shown_as_cancelled_not_displaced(self):
        self.assertEqual(dsp.display_status("Cancelled", None, True)[0], "cancelled")
    def test_workflow_rules_are_the_ones_mirrored(self):
        src = (BACKEND / "app" / "workflow.py").read_text(encoding="utf-8")
        body = src[src.index("def cancel_class"):src.index("# ------------------------------------------------------------------ routing")]
        self.assertIn('cls["status"] != "Scheduled"', body); self.assertIn('cls["class_date"] < dt.date.today()', body); self.assertIn("common.require_section", body)
    def test_frontend_uses_the_server_flag(self):
        js = (ROOT / "frontend" / "assets" / "js" / "daily.js").read_text(encoding="utf-8")
        line = [l for l in js.splitlines() if l.strip().startswith("const canCancel")][0]
        self.assertIn("r.can_cancel === true", line)

class CancelRescheduledBooking(unittest.TestCase):
    """workflow.cancel_class on a rescheduled booking: allowed, same validation, history linked and preserved."""
    def run_cancel(self, resched_row, status="Scheduled", date=dt.date(2099, 1, 5), user=CR_A, scope=({"section_id": 10},)):
        cap = {"audit": [], "notify": []}
        cls = {"section_id": 10, "class_date": date, "end_time": "11:00", "status": status}
        c = Script(dict(cls), list(scope), resched_row)
        row = {"subject_code": "DBMS", "section_label": "Section A", "class_date": date, "start_time": "10:00", "end_time": "11:00", "room_number": "302", "section_id": 10}
        with mock.patch.object(wf.sch, "cancel_class_row", lambda *a, **k: row), \
             mock.patch.object(wf.common, "audit", lambda *a, **k: cap["audit"].append(a)), \
             mock.patch.object(wf.common, "notify", lambda *a, **k: cap["notify"].append(a)), \
             mock.patch.object(wf.common, "admin_ids", lambda cur: [1]), mock.patch.object(wf.common, "cr_ids_for_section", lambda *a, **k: [2]), \
             mock.patch.object(wf.common, "all_cr_ids", lambda cur: [2]):
            try: out = wf.cancel_class(c, user, 77, "teacher unwell")
            except ApiError as e: out = e
        return out, c, cap
    def test_cancelling_a_rescheduled_booking_works_and_is_linked_in_the_audit_trail(self):
        out, c, cap = self.run_cancel({"displacement_id": 5, "original_class_id": 3})
        self.assertEqual(out["status"], "Cancelled")
        (a,) = cap["audit"]; self.assertEqual((a[2], a[3], a[4]), ("RESCHEDULED_CLASS_CANCELLED", "CLASS_DISPLACEMENT", 5))
        self.assertIn("rescheduled slot of a displaced class", cap["notify"][0][3])
    def test_history_is_preserved_displacement_and_original_are_never_modified(self):
        _, c, _ = self.run_cancel({"displacement_id": 5, "original_class_id": 3})
        self.assertFalse(any(s.startswith(("UPDATE CLASS_DISPLACEMENT", "DELETE", "UPDATE CLASS_CANCELLATION")) for s in c.sql))
    def test_an_ordinary_class_is_unaffected(self):
        out, c, cap = self.run_cancel(None)
        self.assertEqual(out["status"], "Cancelled"); self.assertEqual(cap["audit"], [])
    def test_same_validation_applies(self):
        for kw, code in (({"status": "Cancelled"}, 409), ({"status": "Completed"}, 409), ({"date": dt.date(2000, 1, 1)}, 409),
                         ({"user": CR_OTHER, "scope": [{"section_id": 11}]}, 403), ({"user": VIEWER, "scope": []}, 403)):
            out, c, cap = self.run_cancel({"displacement_id": 5, "original_class_id": 3}, **kw)
            self.assertIsInstance(out, ApiError, kw); self.assertEqual(out.status, code, kw); self.assertEqual(cap["audit"], [], kw)

class DismissedCannotBeRescheduled(unittest.TestCase):
    def test_reschedule_refused_with_409_and_no_booking(self):
        c = Script({**ROW, "displacement_status": "Dismissed"}, [{"section_id": 10}])
        with self.assertRaises(ApiError) as cm: dsp.reschedule(c, CR_A, 1, 5)
        self.assertEqual(cm.exception.status, 409); self.assertIn("dismissed", str(cm.exception).lower() + str(getattr(cm.exception, "message", "")).lower())
        self.assertFalse(any(s.startswith("INSERT INTO CLASS_SCHEDULE") for s in c.sql))

    def test_available_rooms_refused_for_dismissed(self):
        c = Script({**ROW, "displacement_status": "Dismissed"}, [{"section_id": 10}])
        with self.assertRaises(ApiError) as cm: dsp.available_rooms(c, CR_A, 1)
        self.assertEqual(cm.exception.status, 409)

    def test_reschedule_of_awaiting_still_reaches_booking_stage(self):          # existing behaviour preserved
        c = Script({**ROW, "displacement_status": "Awaiting"}, [{"section_id": 10}])
        with mock.patch.object(dsp.sch, "book_class", side_effect=RuntimeError("reached booking")):
            with self.assertRaises(RuntimeError): dsp.reschedule(c, CR_A, 1, 5)


class PendingResults(unittest.TestCase):
    def test_status_filter_is_applied_in_sql_so_dismissed_never_shows_as_awaiting(self):
        c = Script([])
        with mock.patch.object(dsp.common, "assigned_sections", lambda cur, u: None):
            dsp.list_displaced(c, ADMIN, "Awaiting")
        self.assertIn("d.status=%s", c.sql[-1])
    def test_shape_flags(self):
        past = {**ROW, "class_date": dt.date(2000, 1, 1)}
        shaped = lambda status, row=ROW: dsp._shape({**row, "displacement_status": status}, True)
        self.assertTrue(shaped("Awaiting")["can_dismiss"]); self.assertTrue(shaped("Awaiting")["can_reschedule"])
        p = shaped("Awaiting", past); self.assertTrue(p["can_dismiss"]); self.assertFalse(p["can_reschedule"])   # stale item can be cleared
        for st in ("Dismissed", "Rescheduled"):
            self.assertFalse(shaped(st)["can_dismiss"]); self.assertFalse(shaped(st)["can_reschedule"])
        self.assertEqual(shaped("Dismissed")["status_label"], "Dismissed")
        self.assertFalse(dsp._shape({**ROW}, False)["can_dismiss"])
    def test_daily_status_for_dismissed_is_still_displaced_never_scheduled(self):
        self.assertEqual(dsp.display_status("Cancelled", "Dismissed", False), ("displaced", "Displaced - dismissed"))
    def test_cancelled_class_is_not_counted_as_occupying_the_room(self):
        c = Script([], [])
        with mock.patch.object(dsp, "_load_authorised", lambda *a, **k: {**ROW, "displacement_status": "Awaiting", "start_time": "10:00", "end_time": "11:00"}):
            try: dsp.available_rooms(c, CR_A, 1)
            except Exception: pass
        occ = [s for s in c.sql if "SELECT DISTINCT room_id FROM CLASS_SCHEDULE" in s][0]
        self.assertIn("status IN ('Scheduled','Completed')", occ); self.assertNotIn("Cancelled", occ)


class MigrationAndWiring(unittest.TestCase):
    SQL = (ROOT / "db" / "007_displacement_dismissed.sql").read_text(encoding="utf-8")
    CODE = "\n".join(l for l in SQL.splitlines() if not l.strip().startswith("--"))
    def test_adds_status_check_and_metadata(self):
        self.assertIn("ENUM(''Awaiting'',''Rescheduled'',''Dismissed'')", self.CODE)
        self.assertIn("ck_disp_state_v2", self.CODE); self.assertIn("dismissed_by_user_id", self.CODE); self.assertIn("dismissed_at", self.CODE)
        check = re.search(r"CHECK \((.*)\)'", self.CODE, re.S).group(1)
        self.assertNotIn("dismissed_by_user_id", check)                        # MySQL 3823: CHECK + FK SET NULL on one column
        for st in ("Awaiting", "Rescheduled", "Dismissed"): self.assertIn(f"status = ''{st}''", check)
    def test_preserves_data_and_other_tables(self):
        for bad in (r"DROP\s+TABLE", r"TRUNCATE", r"DELETE\s+FROM", r"\bINSERT\b", r"\bUPDATE\b", r"CREATE\s+DATABASE", r"DROP\s+DATABASE"):
            self.assertIsNone(re.search(bad, self.CODE, re.I), bad)
        self.assertEqual(set(re.findall(r"ALTER TABLE (\w+)", self.CODE)), {"CLASS_DISPLACEMENT"})
    def test_idempotent_every_step_checks_information_schema(self):
        self.assertEqual(self.CODE.count("information_schema"), 4)
    def test_numbered_after_006(self):
        names = sorted(p.name for p in (ROOT / "db").glob("*.sql"))
        self.assertIn("007_displacement_dismissed.sql", names)
        self.assertEqual(names[names.index("007_displacement_dismissed.sql") - 1][:3], "006")
    def test_dismiss_route_is_staff_only_and_cancel_endpoint_is_not_duplicated(self):
        src = (BACKEND / "app" / "routers" / "daily.py").read_text(encoding="utf-8")
        m = re.search(r'@router\.post\("/displaced-classes/\{displacement_id\}/dismiss"\)\ndef dismiss\([^)]*Depends\(staff\)', src)
        self.assertTrue(m, "dismiss route must depend on staff (VIEWER -> 403)")
        self.assertNotIn("cancel", src.lower().replace("cancelled", ""))      # no second cancellation endpoint
    def test_frontend_reuses_existing_cancel_endpoint_and_has_three_tabs(self):
        js = (ROOT / "frontend" / "assets" / "js" / "daily.js").read_text(encoding="utf-8")
        self.assertIn("/api/classes/${r.class_id}/cancel", js)
        for tab in ('data-pend="Awaiting"', 'data-pend="Rescheduled"', 'data-pend="Dismissed"'): self.assertIn(tab, js)
        self.assertIn("/api/displaced-classes/${id}/dismiss", js); self.assertIn("tabindex=\"0\"", js)


if __name__ == "__main__":
    unittest.main()
