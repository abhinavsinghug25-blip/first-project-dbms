"""Displaced classes: record, list, find rooms, reschedule; plus the date-specific Daily Schedule view.

Model (migration db/006_displaced_classes.sql):
  * A class is DISPLACED  <=>  its CLASS_SCHEDULE row is 'Cancelled' AND a CLASS_DISPLACEMENT row points at it.
    The original row and its CLASS_CANCELLATION record are never changed or deleted.
  * Rescheduling INSERTS a new dated CLASS_SCHEDULE row (origin 'Extra') and links it through
    CLASS_DISPLACEMENT.rescheduled_class_id. UNIQUE keys make a second rescheduling impossible even under a race.
  * Nothing here reads or writes TIMETABLE / TIMETABLE_SLOT: everything is date-specific.

All functions run inside the caller's db.transaction(); an exception rolls back every step.
"""
import datetime as dt
from . import common, scheduling as sch
from .errors import bad, conflict, forbidden, not_found
from .timeutil import to_min, fmt, sql_time, parse_date, serialize

# ------------------------------------------------------------------ status vocabulary (pure, unit-tested)
SCHEDULED, CANCELLED, DISPLACED, RESCHEDULED, COMPLETED = "scheduled", "cancelled", "displaced", "rescheduled", "completed"
LABELS = {SCHEDULED: "Scheduled", CANCELLED: "Cancelled", DISPLACED: "Displaced",
          RESCHEDULED: "Rescheduled", COMPLETED: "Completed"}

def display_status(class_status, displaced_state, is_rescheduled_booking):
    """One derivation used by the Daily Schedule so the UI never has to guess.
    class_status: CLASS_SCHEDULE.status; displaced_state: CLASS_DISPLACEMENT.status of the row that points at THIS class
    as the original ('Awaiting'/'Rescheduled') or None; is_rescheduled_booking: this class is some displacement's replacement."""
    if class_status == "Cancelled":
        if displaced_state is not None:
            return DISPLACED, {"Awaiting": "Displaced - awaiting rescheduling", "Rescheduled": "Displaced - rescheduled",
                               "Dismissed": "Displaced - dismissed"}[displaced_state]
        return CANCELLED, LABELS[CANCELLED]
    if class_status == "Completed":          # never relabel a held class as Scheduled/Rescheduled (the note still says it was rescheduled)
        return COMPLETED, LABELS[COMPLETED]
    if is_rescheduled_booking:
        return RESCHEDULED, LABELS[RESCHEDULED]
    return SCHEDULED, LABELS[SCHEDULED]

def can_cancel(user, class_status, class_date, section_id, my_sections):
    """Mirror of workflow.cancel_class, so the UI offers "Cancel class" exactly when the server will accept it: ADMIN/CR only, a CR only in an
    assigned section, CLASS_SCHEDULE.status 'Scheduled', not a past date. A rescheduled booking is a 'Scheduled' row, hence cancellable;
    Completed and Cancelled rows are not."""
    if user["role"] not in ("ADMIN", "CR") or class_status != "Scheduled" or class_date < dt.date.today():
        return False
    return user["role"] == "ADMIN" or section_id in (my_sections or ())

def displacement_reason(room_number, requesting_section, request_id):
    return f"Room {room_number} was allocated to {requesting_section} (approved request #{request_id})."

def _not_awaiting(status):
    """409 for any action on a displacement that is no longer Awaiting (the message says why)."""
    return conflict("This displaced class was dismissed and can no longer be rescheduled." if status == "Dismissed"
                    else "This class has already been rescheduled." if status == "Rescheduled" else "This displaced class is not awaiting rescheduling.")

def _sch_conflict(e):
    return conflict("; ".join(v.message for v in e.violations), e.details())

# ------------------------------------------------------------------ recording (called from workflow._approve_extra)
def record(cur, user, *, original, request_id, requester_section_id, request_subject_id, displacing_class_id):
    """`original` is the row returned by sch.cancel_class_row (the class BEFORE it was cancelled, with room_number,
    subject_code and section_label). Inserts the CLASS_DISPLACEMENT row and sends ONE notification to every active CR of
    the displaced section (the approving CR included - they are the section's CR and must see what happened)."""
    cur.execute("INSERT INTO CLASS_DISPLACEMENT(original_class_id,request_id,displacing_class_id) VALUES(%s,%s,%s)",
                (original["class_id"], request_id, displacing_class_id))
    did = cur.lastrowid
    cur.execute("SELECT label FROM SECTION WHERE section_id=%s", (requester_section_id,))
    req_sec = cur.fetchone()["label"]
    cur.execute("SELECT code FROM SUBJECT WHERE subject_id=%s", (request_subject_id,))
    req_subj = cur.fetchone()["code"]
    msg = (f"Your class {original['subject_code']} ({original['section_label']}) on {original['class_date']} "
           f"{fmt(to_min(original['start_time']))}-{fmt(to_min(original['end_time']))} in room {original['room_number']} was displaced: "
           f"the room was allocated to {req_sec} ({req_subj}) after request #{request_id} was approved. "
           f"Open Pending rescheduling to choose another room for the same date and time.")
    common.notify(cur, common.cr_ids_for_section(cur, original["section_id"]), "CLASS_DISPLACED", msg, "CLASS_DISPLACEMENT", did)
    common.audit(cur, user["user_id"], "CLASS_DISPLACED", "CLASS_DISPLACEMENT", did,
                 {"original_class_id": original["class_id"], "request_id": request_id, "displacing_class_id": displacing_class_id})
    return did

# ------------------------------------------------------------------ listing
_SELECT = """SELECT d.displacement_id, d.status AS displacement_status, d.created_at AS displaced_at, d.rescheduled_at,
       d.request_id, c.class_id AS original_class_id, c.class_date, c.start_time, c.end_time, c.section_id, c.subject_id, c.teacher_id,
       c.room_id AS original_room_id, r.room_number AS original_room, sec.label AS section_label, sub.code AS subject_code,
       sub.name AS subject_name, t.name AS teacher_name, x.reason AS cancellation_reason, x.cancelled_at,
       rs.label AS requesting_section, ru.full_name AS requested_by,
       d.rescheduled_class_id, nr.room_id AS new_room_id, nr.room_number AS new_room, nc.status AS new_class_status,
       d.dismissed_at, d.dismissed_by_user_id, du.full_name AS dismissed_by
       FROM CLASS_DISPLACEMENT d
       JOIN CLASS_SCHEDULE c ON c.class_id=d.original_class_id
       JOIN ROOM r ON r.room_id=c.room_id
       JOIN SECTION sec ON sec.section_id=c.section_id
       JOIN SUBJECT sub ON sub.subject_id=c.subject_id
       LEFT JOIN TEACHER t ON t.teacher_id=c.teacher_id
       LEFT JOIN CLASS_CANCELLATION x ON x.class_id=c.class_id
       JOIN EXTRA_CLASS_REQUEST q ON q.request_id=d.request_id
       JOIN SECTION rs ON rs.section_id=q.requester_section_id
       JOIN USER_ACCOUNT ru ON ru.user_id=q.requester_user_id
       LEFT JOIN CLASS_SCHEDULE nc ON nc.class_id=d.rescheduled_class_id
       LEFT JOIN ROOM nr ON nr.room_id=nc.room_id
       LEFT JOIN USER_ACCOUNT du ON du.user_id=d.dismissed_by_user_id"""

def _shape(row, user_can_act):
    row["reason"] = displacement_reason(row["original_room"], row["requesting_section"], row["request_id"])
    row["status_label"] = {"Rescheduled": "Rescheduled", "Dismissed": "Dismissed"}.get(row["displacement_status"], "Awaiting rescheduling")
    row["can_reschedule"] = bool(user_can_act and row["displacement_status"] == "Awaiting" and row["class_date"] >= dt.date.today())
    row["can_dismiss"] = bool(user_can_act and row["displacement_status"] == "Awaiting")      # also for a past date: lets stale items be cleared
    return serialize(row)

def list_displaced(cur, user, status=None, limit=100, offset=0):
    scope = common.assigned_sections(cur, user)          # None => ADMIN (all); set => the CR's ACTIVE sections
    sql, args = _SELECT + " WHERE 1=1", []
    if status:
        sql += " AND d.status=%s"; args.append(status)
    if scope is not None:
        ids = sorted(scope) or [0]
        sql += f" AND c.section_id IN ({','.join(['%s'] * len(ids))})"; args += ids
    cur.execute(sql + " ORDER BY (d.status='Awaiting') DESC, c.class_date, c.start_time, d.displacement_id LIMIT %s OFFSET %s", (*args, limit, offset))
    return [_shape(r, True) for r in cur.fetchall()]

def _load_authorised(cur, user, displacement_id, lock=False):
    """The displacement + original class. 404 if absent; 403 unless ADMIN or an ACTIVELY assigned CR of that section."""
    if user["role"] not in ("ADMIN", "CR"):
        raise forbidden("Only the section's CR or an administrator can do that.")
    cur.execute(_SELECT + " WHERE d.displacement_id=%s" + (" FOR UPDATE OF d" if lock else ""), (displacement_id,))
    row = cur.fetchone()
    if not row:
        raise not_found("Displaced class not found.")
    common.require_section(cur, user, row["section_id"])
    return row

# ------------------------------------------------------------------ available rooms for the exact same date/time
BLOCKING = {"teacher_conflict", "section_conflict", "teacher_unavailable", "past_date", "outside_hours", "bad_time_range"}

def available_rooms(cur, user, displacement_id):
    d = _load_authorised(cur, user, displacement_id)
    if d["displacement_status"] != "Awaiting":
        raise _not_awaiting(d["displacement_status"])
    start, end, day = to_min(d["start_time"]), to_min(d["end_time"]), d["class_date"]
    cur.execute("""SELECT DISTINCT room_id FROM CLASS_SCHEDULE WHERE class_date=%s AND status IN ('Scheduled','Completed')
                   AND start_time < %s AND %s < end_time""", (day, sql_time(end), sql_time(start)))
    occupied = {r["room_id"] for r in cur.fetchall()}
    cur.execute("SELECT room_id,room_number,block,room_type,capacity FROM ROOM WHERE status='Active' ORDER BY capacity,block,room_number")
    rooms, free, blockers = cur.fetchall(), [], {}
    for room in rooms:
        if room["room_id"] in occupied:
            continue
        v = sch.find_conflicts(cur, room_id=room["room_id"], teacher_id=d["teacher_id"], section_id=d["section_id"], subject_id=d["subject_id"],
                               class_date=day, start=start, end=end)
        if not v:
            free.append(serialize(room))
        for item in v:
            if item.code in BLOCKING:
                blockers[item.code] = item.message
    return {"displacement_id": displacement_id, "date": day.isoformat(), "start": fmt(start), "end": fmt(end),
            "rooms": free, "blockers": [] if free else list(blockers.values())}

# ------------------------------------------------------------------ reschedule
def reschedule(cur, user, displacement_id, room_id):
    d = _load_authorised(cur, user, displacement_id, lock=True)           # row lock: two concurrent attempts serialise here
    if d["displacement_status"] != "Awaiting":                            # re-read after the lock => the loser sees the winner's commit
        raise _not_awaiting(d["displacement_status"])
    if d["class_date"] < dt.date.today():
        raise conflict("A class on a past date cannot be rescheduled.")
    start, end = to_min(d["start_time"]), to_min(d["end_time"])
    try:                                                                  # locks room/teacher/section, re-validates, inserts
        new_id = sch.book_class(cur, section_id=d["section_id"], subject_id=d["subject_id"], teacher_id=d["teacher_id"], room_id=room_id,
                                class_date=d["class_date"], start=start, end=end, user_id=user["user_id"], origin="Extra")
    except sch.SchedulingError as e:
        raise _sch_conflict(e)                                            # nothing was written; the displacement stays Awaiting
    cur.execute("""UPDATE CLASS_DISPLACEMENT SET status='Rescheduled', rescheduled_class_id=%s, rescheduled_by_user_id=%s,
                   rescheduled_at=UTC_TIMESTAMP() WHERE displacement_id=%s AND status='Awaiting'""", (new_id, user["user_id"], displacement_id))
    if cur.rowcount != 1:
        raise conflict("This class has already been rescheduled.")       # transaction rolls back, including the new booking
    cur.execute("SELECT room_number FROM ROOM WHERE room_id=%s", (room_id,))
    new_room = cur.fetchone()["room_number"]
    common.audit(cur, user["user_id"], "CLASS_RESCHEDULED", "CLASS_DISPLACEMENT", displacement_id,
                 {"original_class_id": d["original_class_id"], "new_class_id": new_id, "from_room": d["original_room"], "to_room": new_room,
                  "date": str(d["class_date"]), "admin_override": user["role"] == "ADMIN"})
    msg = (f"{d['subject_code']} ({d['section_label']}) on {d['class_date']} {fmt(start)}-{fmt(end)} was rescheduled "
           f"from room {d['original_room']} to room {new_room}.")
    common.notify(cur, common.cr_ids_for_section(cur, d["section_id"]), "CLASS_RESCHEDULED", msg, "CLASS_DISPLACEMENT", displacement_id)
    return {"displacement_id": displacement_id, "status": "Rescheduled", "new_class_id": new_id, "room": new_room}

# ------------------------------------------------------------------ dismiss
def dismiss(cur, user, displacement_id):
    """Awaiting -> Dismissed. ADMIN or the actively assigned CR of the affected section only (_load_authorised -> 403 otherwise).
    Nothing is deleted: the original class, its cancellation record, this row and the audit history all stay. Records who/when."""
    d = _load_authorised(cur, user, displacement_id, lock=True)           # row lock: dismiss and reschedule serialise here
    if d["displacement_status"] != "Awaiting":
        raise conflict("This class has already been rescheduled." if d["displacement_status"] == "Rescheduled"
                       else "This displaced class has already been dismissed.")
    cur.execute("""UPDATE CLASS_DISPLACEMENT SET status='Dismissed', dismissed_by_user_id=%s, dismissed_at=UTC_TIMESTAMP()
                   WHERE displacement_id=%s AND status='Awaiting'""", (user["user_id"], displacement_id))
    if cur.rowcount != 1:
        raise conflict("This displaced class is no longer awaiting rescheduling.")
    common.audit(cur, user["user_id"], "CLASS_DISPLACEMENT_DISMISSED", "CLASS_DISPLACEMENT", displacement_id,
                 {"original_class_id": d["original_class_id"], "request_id": d["request_id"], "date": str(d["class_date"]),
                  "admin_override": user["role"] == "ADMIN"})
    msg = (f"The displaced class {d['subject_code']} ({d['section_label']}) on {d['class_date']} "
           f"{fmt(to_min(d['start_time']))}-{fmt(to_min(d['end_time']))} (originally room {d['original_room']}) was dismissed by "
           f"{user.get('full_name') or 'a user'}; it will not be rescheduled.")
    recipients = common.cr_ids_for_section(cur, d["section_id"]) + common.admin_ids(cur)
    common.notify(cur, recipients, "CLASS_DISPLACEMENT_DISMISSED", msg, "CLASS_DISPLACEMENT", displacement_id, exclude=user["user_id"])
    return {"displacement_id": displacement_id, "status": "Dismissed"}

# ------------------------------------------------------------------ Daily Schedule (date-specific, read-only)
_DAILY = """SELECT c.class_id,c.class_date,c.start_time,c.end_time,c.status AS class_status,c.origin,c.section_id,c.room_id,
       r.room_number,sec.label AS section_label,sub.code AS subject_code,sub.name AS subject_name,t.name AS teacher_name,
       x.reason AS cancellation_reason,
       od.displacement_id AS displaced_id, od.status AS displaced_state, od.request_id AS displaced_by_request,
       oqs.label AS displaced_for_section, rr.room_number AS rescheduled_to_room,
       nd.displacement_id AS rescheduled_from_id, orm.room_number AS rescheduled_from_room,
       dc.class_id AS displaces_class_id, dcs.label AS displaces_section, dcr.room_number AS displaces_room,
       (SELECT r2.room_number FROM ROOM_CHANGE_REQUEST rc JOIN ROOM r2 ON r2.room_id=rc.current_room_id
         WHERE rc.class_id=c.class_id AND rc.status='Approved' ORDER BY rc.change_id LIMIT 1) AS moved_from_room
       FROM CLASS_SCHEDULE c
       JOIN ROOM r ON r.room_id=c.room_id
       JOIN SECTION sec ON sec.section_id=c.section_id
       JOIN SUBJECT sub ON sub.subject_id=c.subject_id
       LEFT JOIN TEACHER t ON t.teacher_id=c.teacher_id
       LEFT JOIN CLASS_CANCELLATION x ON x.class_id=c.class_id
       LEFT JOIN CLASS_DISPLACEMENT od ON od.original_class_id=c.class_id
       LEFT JOIN EXTRA_CLASS_REQUEST oq ON oq.request_id=od.request_id
       LEFT JOIN SECTION oqs ON oqs.section_id=oq.requester_section_id
       LEFT JOIN CLASS_SCHEDULE rcs ON rcs.class_id=od.rescheduled_class_id
       LEFT JOIN ROOM rr ON rr.room_id=rcs.room_id
       LEFT JOIN CLASS_DISPLACEMENT nd ON nd.rescheduled_class_id=c.class_id
       LEFT JOIN CLASS_SCHEDULE oc ON oc.class_id=nd.original_class_id
       LEFT JOIN ROOM orm ON orm.room_id=oc.room_id
       LEFT JOIN CLASS_DISPLACEMENT dd ON dd.displacing_class_id=c.class_id
       LEFT JOIN CLASS_SCHEDULE dc ON dc.class_id=dd.original_class_id
       LEFT JOIN SECTION dcs ON dcs.section_id=dc.section_id
       LEFT JOIN ROOM dcr ON dcr.room_id=dc.room_id"""

def daily_schedule(cur, user, date, section_id=None):
    """Every dated class on `date` with a derived status. ADMIN and VIEWER see all sections; a CR sees the classes of the
    sections they are actively assigned to, plus the class that displaced one of theirs (also when filtering by their own section). Read-only (the only write is the
    idempotent INSERT IGNORE materialisation the existing /api/events already performs)."""
    d = parse_date(date)
    sch.ensure_materialized(cur, d, d)
    sql, args = _DAILY + " WHERE c.class_date=%s", [d]
    mine = None                                           # sections this user may cancel in (None = every section, ADMIN)
    if user["role"] == "CR":
        mine = set(common.assigned_sections(cur, user))
        ids = sorted(mine) or [0]
        marks = ",".join(["%s"] * len(ids))
        sql += f" AND (c.section_id IN ({marks}) OR dc.section_id IN ({marks}))"; args += ids + ids
    if section_id is not None:   # a section view also shows the class that took that section's room (else "my section" would hide the cause)
        sql += " AND (c.section_id=%s OR dc.section_id=%s)"; args += [section_id, section_id]
    cur.execute(sql + " ORDER BY c.start_time, r.room_number, c.class_id", args)
    items, counts = [], {SCHEDULED: 0, CANCELLED: 0, DISPLACED: 0, RESCHEDULED: 0, COMPLETED: 0}
    for r in cur.fetchall():
        code, label = display_status(r["class_status"], r["displaced_state"], r["rescheduled_from_id"] is not None)
        counts[code] += 1
        notes = []
        if code == DISPLACED:
            notes.append(f"Room {r['room_number']} went to {r['displaced_for_section']} (request #{r['displaced_by_request']})")
            if r["rescheduled_to_room"]:
                notes.append(f"moved to room {r['rescheduled_to_room']}")
        elif code == CANCELLED and r["cancellation_reason"]:
            notes.append(f"Reason: {r['cancellation_reason']}")
        if r["rescheduled_from_id"] is not None:
            notes.append(f"Rescheduled from room {r['rescheduled_from_room']}" if code != CANCELLED
                         else f"Cancelled after being rescheduled from room {r['rescheduled_from_room']}")
        if r["displaces_class_id"]:
            notes.append(f"Replaced {r['displaces_section']}'s class in this room")
        if r["moved_from_room"] and r["class_status"] != "Cancelled":
            notes.append(f"Room changed (was {r['moved_from_room']})")
        if r["origin"] == "Extra" and code in (SCHEDULED, COMPLETED) and not r["displaces_class_id"]:
            notes.append("Extra class")
        items.append(serialize({**r, "status": code, "status_label": label, "note": " · ".join(notes) or None,
                                "can_cancel": can_cancel(user, r["class_status"], r["class_date"], r["section_id"], mine)}))
    return {"date": d.isoformat(), "weekday": d.strftime("%A"), "items": items, "counts": counts}
