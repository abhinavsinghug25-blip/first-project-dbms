"""Authentication dependency. Identity ALWAYS comes from the server-side session; user_id, role,
section_id, requester/approver identity sent by the browser are never trusted."""
import hmac
from fastapi import Request, Depends
from . import config, db, security
from .errors import unauthorized, forbidden

SAFE = {"GET", "HEAD", "OPTIONS"}

def current_user(request: Request) -> dict:
    token = request.cookies.get(config.COOKIE_NAME)
    if not token:
        raise unauthorized()
    with db.transaction() as cur:
        row = db.one(cur, """SELECT u.user_id,u.username,u.email,u.full_name,u.role,s.csrf_token
                             FROM USER_SESSION s JOIN USER_ACCOUNT u ON u.user_id=s.user_id
                             WHERE s.token_hash=%s AND s.expires_at>UTC_TIMESTAMP() AND u.is_active=1""",
                     (security.token_hash(token),))
    if not row:
        raise unauthorized("Session expired. Please sign in again.")
    if request.method not in SAFE:
        sent = request.headers.get("x-csrf-token", "")
        if not hmac.compare_digest(sent, row["csrf_token"]):
            raise forbidden("Missing or invalid CSRF token.")
    return row

def require(*roles):
    def dep(user: dict = Depends(current_user)) -> dict:
        if user["role"] not in roles:
            raise forbidden(f"Requires role: {' or '.join(roles)}.")
        return user
    return dep

any_user = current_user
admin_only = require("ADMIN")
staff = require("ADMIN", "CR")
