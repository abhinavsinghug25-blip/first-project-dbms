"""Cancellation/release, CR-to-CR room/slot requests and room-change requests (Stage 5).

Request kinds share one routing + authorisation model:
  * route(): decides WHO may decide. target = the ACTIVE class currently holding the slot
    (released on approval); else the CANCELLED class that freed it; its section's CR decides.
    No eligible CR (other than the requester) -> ADMIN.
  * can_decide(): re-evaluated against the database at decision time.
  * A requester can never decide their own request (not even an ADMIN requester).
"""
import datetime as dt
from . import common, displacement, scheduling as sch
from .errors import ApiError, bad, conflict, forbidden, not_found
from .timeutil import to_min, fmt, sql_time, parse_date

KINDS = {"extra": ("EXTRA_CLASS_REQUEST", "request_id"), "room-change": ("ROOM_CHANGE_REQUEST", "change_id")}

def _sch_conflict(e: sch.SchedulingError):
    return conflict("; ".join(v.message for v in e.violations), e.details())

# ------------------------------------------------------------------ cancellation / release
def cancel_class(cur, user, class_id, reason):
    reason = (reason or "").strip()
    if not reason:
        raise bad("A cancellation reason is required.")
    cur.execute("SELECT section_id,class_date,end_time,status FROM CLASS_SCHEDULE WHERE class_id=%s", (class_id,))
    cls = cur.fetchone()
    if not cls:
        raise not_found("Class not found.")
    common.require_section(cur, user, cls["section_id"])            # CR only for assigned sections
    if user["role"] not in ("ADMIN", "CR"):
        raise forbidden()
    if cls["status"] != "Scheduled":
        raise conflict(f"Class is already {cls['status']}.")
    if cls["class_date"] < dt.date.today():
        raise conflict("Past classes cannot be cancelled.")
    row = sch.cancel_class_row(cur, class_id, user["user_id"], reason)
    if not row:                                                      # lost a race with another cancel
        raise conflict("Class is no longer scheduled.")
    # A displaced class that was rescheduled is an ordinary CLASS_SCHEDULE row with status 'Scheduled' (there is no 'Rescheduled' class status),
    # so the checks above already apply to it unchanged. Here we only LINK the history: the displacement stays 'Rescheduled' and keeps pointing at
    # this (now cancelled) class, the original class and its first cancellation are untouched, and a separate audit row says what happened.
    cur.execute("SELECT displacement_id, original_class_id FROM CLASS_DISPLACEMENT WHERE rescheduled_class_id=%s", (class_id,))
    resched = cur.fetchone()
    if resched:
        common.audit(cur, user["user_id"], "RESCHEDULED_CLASS_CANCELLED", "CLASS_DISPLACEMENT", resched["displacement_id"],
                     {"rescheduled_class_id": class_id, "original_class_id": resched["original_class_id"], "reason": reason,
                      "admin_override": user["role"] == "ADMIN"})
    msg = (f"{row['subject_code']} ({row['section_label']}) on {row['class_date']} {fmt(to_min(row['start_time']))}-"
           f"{fmt(to_min(row['end_time']))} was cancelled; room {row['room_number']} is now free. Reason: {reason}"
           + (" (this was the rescheduled slot of a displaced class)" if resched else ""))
    recipients = common.admin_ids(cur) + common.cr_ids_for_section(cur, row["section_id"]) + common.all_cr_ids(cur)
    common.notify(cur, recipients, "CLASS_CANCELLED", msg, "CLASS_SCHEDULE", class_id, exclude=user["user_id"])
    return {"class_id": class_id, "status": "Cancelled", "room_released": row["room_number"]}

# ------------------------------------------------------------------ routing
def route(cur, *, room_id, class_date, start, end, requester_user_id, ignore_class_id=None):
    active = sch.active_in_room(cur, room_id, class_date, start, end, [ignore_class_id])
    if len(active) > 1:
        raise conflict("More than one class occupies that room during the requested time. Request each slot separately.",
                       [{"class_id": c["class_id"], "section": c["section_label"]} for c in active])
    cur.execute("""SELECT c.class_id,c.section_id FROM CLASS_SCHEDULE c JOIN CLASS_CANCELLATION x ON x.class_id=c.class_id
                   WHERE c.room_id=%s AND c.class_date=%s AND c.status='Cancelled' AND c.start_time < %s AND %s < c.end_time
                   ORDER BY x.cancelled_at DESC LIMIT 1""", (room_id, class_date, sql_time(end), sql_time(start)))
    released = cur.fetchone()
    target = active[0] if active else None
    basis_section = (target or released or {}).get("section_id")
    recipient_role, recipient_user = "ADMIN", None
    if basis_section:
        crs = common.cr_ids_for_section(cur, basis_section, exclude_user=requester_user_id)
        if crs:
            recipient_role, recipient_user = "CR", crs[0]
    return {"target_class_id": target["class_id"] if target else None,
            "released_class_id": released["class_id"] if released else None,
            "target_section_id": basis_section, "recipient_role": recipient_role, "recipient_user_id": recipient_user}

def can_decide(cur, user, req):
    """Server-side, recomputed on every decision."""
    if req["requester_user_id"] == user["user_id"]:
        return False
    if user["role"] == "ADMIN":
        return True
    if user["role"] == "CR" and req["recipient_role"] == "CR" and req["target_section_id"] is not None:
        return req["target_section_id"] in common.assigned_sections(cur, user)
    return False

def _notify_new_request(cur, req_id, kind, route_, text, requester_id):
    if route_["recipient_role"] == "CR":
        who = common.cr_ids_for_section(cur, route_["target_section_id"], exclude_user=requester_id) + common.admin_ids(cur)
    else:
        who = common.admin_ids(cur)
    common.notify(cur, who, "REQUEST_RECEIVED", text, kind, req_id, exclude=requester_id)

# ------------------------------------------------------------------ extra-class (room/slot) request
def create_extra_request(cur, user, p):
    if user["role"] not in ("ADMIN", "CR"):
        raise forbidden("Viewers cannot submit requests.")
    common.require_section(cur, user, p["section_id"])               # CR: own assigned section only
    start, end, d = to_min(p["start"]), to_min(p["end"]), parse_date(p["date"])
    sch.ensure_materialized(cur, d, d)
    r = route(cur, room_id=p["room_id"], class_date=d, start=start, end=end, requester_user_id=user["user_id"])
    v = sch.find_conflicts(cur, room_id=p["room_id"], teacher_id=p.get("teacher_id"), section_id=p["section_id"], subject_id=p["subject_id"],
                           class_date=d, start=start, end=end, ignore_class_ids=[r["target_class_id"]])
    if v:
        raise _sch_conflict(sch.SchedulingError(v))
    cur.execute("""SELECT request_id FROM EXTRA_CLASS_REQUEST WHERE requester_user_id=%s AND requested_room_id=%s AND request_date=%s
                   AND start_time=%s AND end_time=%s AND status='Pending'""", (user["user_id"], p["room_id"], d, sql_time(start), sql_time(end)))
    if cur.fetchone():
        raise conflict("You already have a pending request for this room and time.")
    cur.execute("""INSERT INTO EXTRA_CLASS_REQUEST(requester_user_id,requester_section_id,subject_id,teacher_id,requested_room_id,request_date,
                   start_time,end_time,purpose,target_class_id,released_class_id,target_section_id,recipient_role,recipient_user_id)
                   VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
                (user["user_id"], p["section_id"], p["subject_id"], p.get("teacher_id"), p["room_id"], d, sql_time(start), sql_time(end),
                 (p.get("purpose") or "")[:500] or None, r["target_class_id"], r["released_class_id"], r["target_section_id"],
                 r["recipient_role"], r["recipient_user_id"]))
    rid = cur.lastrowid
    cur.execute("SELECT room_number FROM ROOM WHERE room_id=%s", (p["room_id"],))
    room = cur.fetchone()["room_number"]
    common.audit(cur, user["user_id"], "REQUEST_CREATED", "EXTRA_CLASS_REQUEST", rid, {**{k: str(v) for k, v in r.items()}, "room": room, "date": str(d)})
    _notify_new_request(cur, rid, "EXTRA_CLASS_REQUEST", r, f"{user['full_name']} requests room {room} on {d} {fmt(start)}-{fmt(end)}.", user["user_id"])
    return {"request_id": rid, "status": "Pending", "routed_to": r["recipient_role"], "target_section_id": r["target_section_id"]}

# ------------------------------------------------------------------ room-change request
def create_room_change(cur, user, p):
    if user["role"] not in ("ADMIN", "CR"):
        raise forbidden("Viewers cannot submit requests.")
    reason = (p.get("reason") or "").strip()
    if not reason:
        raise bad("A reason is required.")
    cur.execute("SELECT * FROM CLASS_SCHEDULE WHERE class_id=%s", (p["class_id"],))
    cls = cur.fetchone()
    if not cls:
        raise not_found("Class not found.")
    common.require_section(cur, user, cls["section_id"])
    if cls["status"] != "Scheduled":
        raise conflict(f"Class is {cls['status']}.")
    if cls["room_id"] == p["requested_room_id"]:
        raise bad("The class is already in that room.")
    start, end = to_min(cls["start_time"]), to_min(cls["end_time"])
    r = route(cur, room_id=p["requested_room_id"], class_date=cls["class_date"], start=start, end=end,
              requester_user_id=user["user_id"], ignore_class_id=cls["class_id"])
    v = sch.find_conflicts(cur, room_id=p["requested_room_id"], teacher_id=cls["teacher_id"], section_id=cls["section_id"], subject_id=cls["subject_id"],
                           class_date=cls["class_date"], start=start, end=end, ignore_class_ids=[cls["class_id"], r["target_class_id"]])
    if v:
        raise _sch_conflict(sch.SchedulingError(v))
    cur.execute("""INSERT INTO ROOM_CHANGE_REQUEST(class_id,requester_user_id,current_room_id,requested_room_id,reason,target_class_id,
                   released_class_id,target_section_id,recipient_role,recipient_user_id) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
                (cls["class_id"], user["user_id"], cls["room_id"], p["requested_room_id"], reason[:500], r["target_class_id"],
                 r["released_class_id"], r["target_section_id"], r["recipient_role"], r["recipient_user_id"]))
    cid = cur.lastrowid
    common.audit(cur, user["user_id"], "ROOM_CHANGE_REQUESTED", "ROOM_CHANGE_REQUEST", cid, {"class_id": cls["class_id"], **{k: str(v) for k, v in r.items()}})
    _notify_new_request(cur, cid, "ROOM_CHANGE_REQUEST", r, f"{user['full_name']} asks to move a class on {cls['class_date']} to another room.", user["user_id"])
    return {"change_id": cid, "status": "Pending", "routed_to": r["recipient_role"]}

# ------------------------------------------------------------------ decisions
def _load_for_decision(cur, user, kind, req_id):
    table, pk = KINDS[kind]
    cur.execute(f"SELECT * FROM {table} WHERE {pk}=%s FOR UPDATE", (req_id,))
    req = cur.fetchone()
    if not req:
        raise not_found("Request not found.")
    if req["status"] != "Pending":                                   # stale status
        raise conflict(f"Request is already {req['status']}.")
    if req["requester_user_id"] == user["user_id"]:
        raise forbidden("You cannot decide your own request.")
    if not can_decide(cur, user, req):
        raise forbidden("This request is outside your authority.")
    return req, table, pk

def _finish(cur, table, pk, req_id, user, status, reason, extra_sql="", extra_args=()):
    cur.execute(f"UPDATE {table} SET status=%s,decided_by_user_id=%s,decided_at=UTC_TIMESTAMP(),decision_reason=%s{extra_sql} WHERE {pk}=%s",
                (status, user["user_id"], reason, *extra_args, req_id))

def decide(cur, user, kind, req_id, decision, reason):
    if kind not in KINDS:
        raise not_found("Unknown request kind.")
    if user["role"] not in ("ADMIN", "CR"):
        raise forbidden()
    reason = (reason or "").strip()
    if decision == "reject" and not reason:
        raise bad("A reason is required when rejecting.")
    req, table, pk = _load_for_decision(cur, user, kind, req_id)
    entity = "EXTRA_CLASS_REQUEST" if kind == "extra" else "ROOM_CHANGE_REQUEST"
    if decision == "reject":
        _finish(cur, table, pk, req_id, user, "Rejected", reason)
        common.audit(cur, user["user_id"], "REQUEST_REJECTED", entity, req_id, {"reason": reason, "admin_override": user["role"] == "ADMIN" and req["recipient_role"] == "CR"})
        common.notify(cur, [req["requester_user_id"]], "REQUEST_REJECTED", f"Your request #{req_id} was rejected by {user['full_name']}. Reason: {reason}", entity, req_id)
        return {"status": "Rejected"}
    (_approve_extra if kind == "extra" else _approve_room_change)(cur, user, req, req_id, reason)
    return {"status": "Approved"}

def _release_target(cur, user, req, req_id, why, *, notify=True):
    """Cancel the class that currently holds the slot (history kept). Returns the class row as it was BEFORE the
    cancellation, or None when nothing was released. notify=False lets the caller send its own (richer) notification."""
    tid = req["target_class_id"]
    if not tid:
        return None
    cur.execute("SELECT status,section_id FROM CLASS_SCHEDULE WHERE class_id=%s FOR UPDATE", (tid,))
    t = cur.fetchone()
    if not t or t["status"] != "Scheduled":
        return None                                                  # already cancelled - nothing to release
    if user["role"] == "CR" and t["section_id"] not in common.assigned_sections(cur, user):
        raise forbidden("The class holding that slot is not in your section.")
    row = sch.cancel_class_row(cur, tid, user["user_id"], why, action="CLASS_RELEASED_FOR_REQUEST")
    if notify:
        common.notify(cur, common.cr_ids_for_section(cur, row["section_id"]) + common.admin_ids(cur), "CLASS_CANCELLED",
                      f"{row['subject_code']} ({row['section_label']}) on {row['class_date']} was released for request #{req_id}.", "CLASS_SCHEDULE", tid, exclude=user["user_id"])
    return row

def _approve_extra(cur, user, req, req_id, reason):
    start, end, d = to_min(req["start_time"]), to_min(req["end_time"]), req["request_date"]
    sch.ensure_materialized(cur, d, d)
    sch.lock_resources(cur, [req["requested_room_id"]], req["teacher_id"], req["requester_section_id"])
    allowed = [req["target_class_id"]]
    # recheck at decision time: anything in the room other than the one class we may release is a clash
    try:
        v = sch.find_conflicts(cur, room_id=req["requested_room_id"], teacher_id=req["teacher_id"], section_id=req["requester_section_id"],
                               subject_id=req["subject_id"], class_date=d, start=start, end=end, ignore_class_ids=allowed)
        if v:
            raise sch.SchedulingError(v)
        # displaced class: cancelled (never deleted) and recorded in CLASS_DISPLACEMENT below, in this same transaction
        displaced = _release_target(cur, user, req, req_id, f"Released for request #{req_id}" + (f": {reason}" if reason else ""), notify=False)
        cid = sch.book_class(cur, section_id=req["requester_section_id"], subject_id=req["subject_id"], teacher_id=req["teacher_id"],
                             room_id=req["requested_room_id"], class_date=d, start=start, end=end, user_id=user["user_id"],
                             origin="Extra", source_request_id=req_id, ignore_class_ids=allowed)
    except sch.SchedulingError as e:
        raise _sch_conflict(e)                                       # transaction rolls back; request stays Pending
    _finish(cur, "EXTRA_CLASS_REQUEST", "request_id", req_id, user, "Approved", reason or None, ",resulting_class_id=%s", (cid,))
    common.audit(cur, user["user_id"], "REQUEST_APPROVED", "EXTRA_CLASS_REQUEST", req_id,
                 {"new_class_id": cid, "released_class_id": req["target_class_id"], "admin_override": user["role"] == "ADMIN" and req["recipient_role"] == "CR"})
    if displaced:
        displacement.record(cur, user, original=displaced, request_id=req_id, requester_section_id=req["requester_section_id"],
                            request_subject_id=req["subject_id"], displacing_class_id=cid)     # + notifies the displaced section's CR(s)
        common.notify(cur, common.admin_ids(cur), "CLASS_CANCELLED",                          # unchanged behaviour for ADMINs
                      f"{displaced['subject_code']} ({displaced['section_label']}) on {displaced['class_date']} was released for request #{req_id}.",
                      "CLASS_SCHEDULE", displaced["class_id"], exclude=user["user_id"])
    cur.execute("SELECT room_number FROM ROOM WHERE room_id=%s", (req["requested_room_id"],))
    room = cur.fetchone()["room_number"]
    common.notify(cur, [req["requester_user_id"]], "REQUEST_APPROVED",
                  f"Your request #{req_id} for room {room} on {d} {fmt(start)}-{fmt(end)} was approved by {user['full_name']}.", "EXTRA_CLASS_REQUEST", req_id)

def _approve_room_change(cur, user, req, req_id, reason):
    cur.execute("SELECT * FROM CLASS_SCHEDULE WHERE class_id=%s", (req["class_id"],))
    cls = cur.fetchone()
    sch.lock_resources(cur, [req["current_room_id"], req["requested_room_id"]], cls["teacher_id"], cls["section_id"])
    cur.execute("SELECT * FROM CLASS_SCHEDULE WHERE class_id=%s FOR UPDATE", (req["class_id"],))
    cls = cur.fetchone()
    if cls["status"] != "Scheduled" or cls["room_id"] != req["current_room_id"]:
        raise conflict("The class changed since the request was made (cancelled or already moved).")
    start, end, d = to_min(cls["start_time"]), to_min(cls["end_time"]), cls["class_date"]
    try:
        v = sch.find_conflicts(cur, room_id=req["requested_room_id"], teacher_id=cls["teacher_id"], section_id=cls["section_id"],
                               subject_id=cls["subject_id"], class_date=d, start=start, end=end, allow_past=False,
                               ignore_class_ids=[cls["class_id"], req["target_class_id"]])
        if v:
            raise sch.SchedulingError(v)
    except sch.SchedulingError as e:
        raise _sch_conflict(e)                                       # original schedule untouched
    _release_target(cur, user, req, req_id, f"Released for room change #{req_id}" + (f": {reason}" if reason else ""))
    cur.execute("UPDATE CLASS_SCHEDULE SET room_id=%s WHERE class_id=%s", (req["requested_room_id"], cls["class_id"]))
    _finish(cur, "ROOM_CHANGE_REQUEST", "change_id", req_id, user, "Approved", reason or None)
    common.audit(cur, user["user_id"], "ROOM_CHANGED", "CLASS_SCHEDULE", cls["class_id"],
                 {"from_room_id": req["current_room_id"], "to_room_id": req["requested_room_id"], "request_id": req_id,
                  "admin_override": user["role"] == "ADMIN" and req["recipient_role"] == "CR"})
    common.notify(cur, [req["requester_user_id"]], "REQUEST_APPROVED", f"Your room change #{req_id} was approved by {user['full_name']}.", "ROOM_CHANGE_REQUEST", req_id)

def withdraw(cur, user, kind, req_id):
    table, pk = KINDS[kind]
    cur.execute(f"SELECT * FROM {table} WHERE {pk}=%s FOR UPDATE", (req_id,))
    req = cur.fetchone()
    if not req:
        raise not_found("Request not found.")
    if req["requester_user_id"] != user["user_id"] and user["role"] != "ADMIN":
        raise forbidden("Only the requester (or ADMIN) can withdraw a request.")
    if req["status"] != "Pending":
        raise conflict(f"Request is already {req['status']}.")
    _finish(cur, table, pk, req_id, user, "Cancelled", "Withdrawn")
    common.audit(cur, user["user_id"], "REQUEST_WITHDRAWN", table, req_id)
    return {"status": "Cancelled"}
