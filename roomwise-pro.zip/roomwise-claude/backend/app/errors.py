from fastapi import Request
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
import logging
import pymysql

class ApiError(Exception):
    def __init__(self, status: int, code: str, message: str, details=None):
        self.status, self.code, self.message, self.details = status, code, message, details

def bad(msg, details=None):        return ApiError(400, "bad_request", msg, details)
def unauthorized(msg="Authentication required"): return ApiError(401, "unauthorized", msg)
def forbidden(msg="You are not allowed to do that"): return ApiError(403, "forbidden", msg)
def not_found(msg="Not found"):    return ApiError(404, "not_found", msg)
def conflict(msg, details=None):   return ApiError(409, "conflict", msg, details)

def body(status, code, message, details=None):
    return JSONResponse(status_code=status, content={"error": {"code": code, "message": message, "details": details}})

def install(app):
    @app.exception_handler(ApiError)
    async def _api(_: Request, e: ApiError):
        return body(e.status, e.code, e.message, e.details)

    @app.exception_handler(RequestValidationError)
    async def _val(_: Request, e: RequestValidationError):
        errs = [{"field": ".".join(str(x) for x in err["loc"] if x != "body"), "message": err["msg"]} for err in e.errors()]
        return body(422, "validation_error", "Request validation failed", errs)

    @app.exception_handler(pymysql.err.IntegrityError)
    async def _integrity(_: Request, e):
        return body(409, "integrity_error", "The change violates a database constraint (duplicate or referenced record).")

    @app.exception_handler(pymysql.err.OperationalError)
    async def _op(_: Request, e):
        code = e.args[0] if e.args else 0
        if code in (1205, 1213):   # lock wait timeout / deadlock: nothing was committed
            return body(409, "busy", "The room is being modified by someone else. Please retry.")
        if code in (2002, 2003, 2006, 2013, 1040, 1045, 1049):   # cannot connect / auth / unknown DB / server gone
            return body(503, "database_unavailable", "The database is unavailable.")
        logging.getLogger("roomwise").exception("Unhandled SQL error %s", code)   # a real bug, not an outage
        return body(500, "server_error", "Internal error while processing the request. See the server log.")
