import datetime as dt
import re

_HHMM = re.compile(r"^([01]\d|2[0-3]):([0-5]\d)(?::[0-5]\d)?$")

def to_min(v) -> int:
    """Minutes since midnight from 'HH:MM[:SS]', datetime.time or the timedelta PyMySQL returns for TIME."""
    if isinstance(v, dt.timedelta):
        return int(v.total_seconds() // 60)
    if isinstance(v, dt.time):
        return v.hour * 60 + v.minute
    m = _HHMM.match(str(v))
    if not m:
        raise ValueError(f"Invalid time '{v}', expected HH:MM")
    return int(m.group(1)) * 60 + int(m.group(2))

def fmt(minutes: int) -> str:
    return f"{minutes // 60:02d}:{minutes % 60:02d}"

def sql_time(minutes: int) -> str:
    return f"{minutes // 60:02d}:{minutes % 60:02d}:00"

def parse_date(v) -> dt.date:
    if isinstance(v, dt.date):
        return v
    return dt.date.fromisoformat(str(v))

def monday_of(d: dt.date) -> dt.date:
    return d - dt.timedelta(days=d.weekday())

def serialize(row):
    """Make a DB row JSON-safe."""
    if row is None:
        return None
    out = {}
    for k, v in row.items():
        if isinstance(v, dt.timedelta):
            out[k] = fmt(int(v.total_seconds() // 60))
        elif isinstance(v, (dt.datetime, dt.date)):
            out[k] = v.isoformat()
        elif isinstance(v, bytes):
            out[k] = v.decode()
        else:
            out[k] = v
    return out

def serialize_all(rows):
    return [serialize(r) for r in rows]
