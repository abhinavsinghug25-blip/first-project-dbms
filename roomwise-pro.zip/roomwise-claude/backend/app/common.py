"""Shared helpers: audit trail, notifications, CR-scope lookups."""
import json
from .errors import forbidden

def audit(cur, actor_id, action, entity_type, entity_id=None, details=None):
    cur.execute("INSERT INTO AUDIT_LOG(actor_user_id,action,entity_type,entity_id,details) VALUES(%s,%s,%s,%s,%s)",
                (actor_id, action, entity_type, None if entity_id is None else str(entity_id),
                 json.dumps(details, default=str) if details is not None else None))

def notify(cur, user_ids, type_, message, entity_type=None, entity_id=None, exclude=None):
    seen = set()
    for uid in user_ids:
        if uid is None or uid == exclude or uid in seen:
            continue
        seen.add(uid)
        cur.execute("INSERT INTO NOTIFICATION(user_id,type,message,entity_type,entity_id) VALUES(%s,%s,%s,%s,%s)",
                    (uid, type_, message[:500], entity_type, None if entity_id is None else str(entity_id)))

def admin_ids(cur):
    cur.execute("SELECT user_id FROM USER_ACCOUNT WHERE role='ADMIN' AND is_active=1")
    return [r["user_id"] for r in cur.fetchall()]

def cr_ids_for_section(cur, section_id, exclude_user=None):
    """Active CR user ids for a section, oldest assignment first, requester excluded.
    One row per user (GROUP BY) so a duplicate assignment can never yield a duplicate recipient.
    ORDER BY uses an aggregate: ordering a DISTINCT result by a column that is not selected is
    rejected by MySQL 8 (error 3065)."""
    cur.execute("""SELECT a.user_id FROM SECTION_CR_ASSIGNMENT a JOIN USER_ACCOUNT u ON u.user_id=a.user_id
                   WHERE a.section_id=%s AND a.is_active=1 AND u.is_active=1 AND u.role='CR' AND a.user_id<>%s
                   GROUP BY a.user_id ORDER BY MIN(a.assignment_id)""", (section_id, exclude_user or 0))
    return [r["user_id"] for r in cur.fetchall()]

def all_cr_ids(cur):
    cur.execute("SELECT user_id FROM USER_ACCOUNT WHERE role='CR' AND is_active=1")
    return [r["user_id"] for r in cur.fetchall()]

def assigned_sections(cur, user):
    """None => unrestricted (ADMIN). Otherwise the set of section ids from ACTIVE assignments.
    Always read from the database; the browser's claim is never used."""
    if user["role"] == "ADMIN":
        return None
    if user["role"] != "CR":
        return set()
    cur.execute("SELECT section_id FROM SECTION_CR_ASSIGNMENT WHERE user_id=%s AND is_active=1", (user["user_id"],))
    return {r["section_id"] for r in cur.fetchall()}

def require_section(cur, user, section_id):
    scope = assigned_sections(cur, user)
    if scope is not None and section_id not in scope:
        raise forbidden("You are not assigned to that section.")
