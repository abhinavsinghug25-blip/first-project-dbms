"""Operator commands (run on the server, never exposed over HTTP).

  python -m app.cli create-admin --username admin --email you@example.edu --name "Admin"
        (password from RW_ADMIN_PASSWORD or an interactive prompt; nothing is hard-coded)
  python -m app.cli materialize [--from YYYY-MM-DD] [--weeks N]
  python -m app.cli seed-demo        (fictional CR/VIEWER accounts + sample cancellation/requests, lab demo only)
"""
import argparse, datetime as dt, getpass, os, secrets, sys
from . import db, security, common, scheduling as sch, workflow as wf, config
from .errors import ApiError
from .timeutil import monday_of

def _user(cur, username):
    return db.one(cur, "SELECT user_id,username,full_name,role FROM USER_ACCOUNT WHERE username=%s", (username,))

def create_admin(a):
    pw = os.environ.get("RW_ADMIN_PASSWORD") or getpass.getpass("Admin password: ")
    problem = security.password_problem(pw)
    if problem: sys.exit(problem)
    with db.transaction() as cur:
        cur.execute("INSERT INTO USER_ACCOUNT(username,email,full_name,password_hash,role) VALUES(%s,%s,%s,%s,'ADMIN')",
                    (a.username, a.email.lower(), a.name, security.hash_password(pw)))
        common.audit(cur, cur.lastrowid, "ADMIN_PROVISIONED", "USER_ACCOUNT", cur.lastrowid, {"via": "cli"})
    print(f"Admin '{a.username}' created.")

def materialize(a):
    start = dt.date.fromisoformat(a.from_) if a.from_ else monday_of(dt.date.today())
    end = start + dt.timedelta(weeks=a.weeks) - dt.timedelta(days=1)
    with db.transaction() as cur:
        sch.ensure_materialized(cur, start, end)
        n = db.one(cur, "SELECT COUNT(*) AS n FROM CLASS_SCHEDULE WHERE class_date BETWEEN %s AND %s", (start, end))["n"]
    print(f"Materialised {start}..{end}: {n} dated classes.")

def seed_demo(_):
    pw = os.environ.get("RW_DEMO_PASSWORD") or (secrets.token_urlsafe(9) + "a1")
    accounts = [("demo_admin", "ADMIN", "Demo Admin"), ("cr_cs5", "VIEWER", "CR Computer Science Sem 5"),
                ("cr_cs3", "VIEWER", "CR Computer Science Sem 3"), ("viewer1", "VIEWER", "Demo Viewer")]
    with db.transaction() as cur:
        for uname, role, name in accounts:
            if not _user(cur, uname):
                cur.execute("INSERT INTO USER_ACCOUNT(username,email,full_name,password_hash,role) VALUES(%s,%s,%s,%s,%s)",
                            (uname, f"{uname}@example.invalid", name, security.hash_password(pw), role))
        admin = _user(cur, "demo_admin")
        for uname, label in (("cr_cs5", "CS · Semester 5 · Section 1"), ("cr_cs3", "CS · Semester 3 · Section 1")):
            u, sec = _user(cur, uname), db.one(cur, "SELECT section_id FROM SECTION WHERE label=%s", (label,))
            if sec and not db.one(cur, "SELECT 1 FROM SECTION_CR_ASSIGNMENT WHERE user_id=%s AND section_id=%s AND is_active=1", (u["user_id"], sec["section_id"])):
                cur.execute("INSERT INTO SECTION_CR_ASSIGNMENT(user_id,section_id,assigned_by_user_id) VALUES(%s,%s,%s)", (u["user_id"], sec["section_id"], admin["user_id"]))
                cur.execute("UPDATE USER_ACCOUNT SET role='CR' WHERE user_id=%s", (u["user_id"],))
    print(f"Demo accounts (password: {pw}): demo_admin, cr_cs5, cr_cs3, viewer1   <- shown once, store it now.")
    _demo_workflow()

def _demo_workflow():
    """Drives the REAL workflow functions so demo rows are as valid as production rows."""
    today = dt.date.today()
    start = today if today.weekday() < 5 else today + dt.timedelta(days=7 - today.weekday())
    with db.transaction() as cur:
        sch.ensure_materialized(cur, start, start + dt.timedelta(days=13))
        cr5, cr3, admin = _user(cur, "cr_cs5"), _user(cur, "cr_cs3"), _user(cur, "demo_admin")
        cands = db.all_(cur, """SELECT c.class_id,c.room_id,c.class_date,c.start_time,c.end_time FROM CLASS_SCHEDULE c JOIN SECTION s ON s.section_id=c.section_id
                                WHERE s.label='CS · Semester 5 · Section 1' AND c.status='Scheduled' AND c.class_date>=%s ORDER BY c.class_date,c.start_time LIMIT 6""", (start,))
        sec3 = db.one(cur, "SELECT section_id FROM SECTION WHERE label='CS · Semester 3 · Section 1'")["section_id"]
        subj3 = db.all_(cur, "SELECT DISTINCT subject_id,teacher_id FROM TIMETABLE_SLOT WHERE section_id=%s AND teacher_id IS NOT NULL", (sec3,))
    made = {"cancelled": 0, "pending": 0, "approved": 0, "rejected": 0}
    for i, c in enumerate(cands):
        try:
            with db.transaction() as cur: wf.cancel_class(cur, cr5, c["class_id"], "Faculty on duty leave (demo data)"); made["cancelled"] += 1
        except ApiError: continue
        for s3 in subj3:
            try:
                with db.transaction() as cur:
                    r = wf.create_extra_request(cur, cr3, {"section_id": sec3, "subject_id": s3["subject_id"], "teacher_id": s3["teacher_id"], "room_id": c["room_id"],
                                                           "date": c["class_date"], "start": c["start_time"], "end": c["end_time"], "purpose": "Make-up class (demo data)"})
                break
            except ApiError: r = None
        if not r: continue
        outcome = ("approve", "approved") if made["approved"] == 0 else (("reject", "rejected") if made["rejected"] == 0 else (None, "pending"))
        if outcome[0]:
            try:
                with db.transaction() as cur: wf.decide(cur, cr5, "extra", r["request_id"], outcome[0], "Demo decision" if outcome[0] == "reject" else "")
            except ApiError: pass
        made[outcome[1]] += 1
        if made["approved"] and made["rejected"] and made["pending"]: break
    print("Demo workflow rows:", made)

def main():
    p = argparse.ArgumentParser(prog="app.cli"); sp = p.add_subparsers(dest="cmd", required=True)
    a = sp.add_parser("create-admin"); a.add_argument("--username", required=True); a.add_argument("--email", required=True); a.add_argument("--name", required=True)
    m = sp.add_parser("materialize"); m.add_argument("--from", dest="from_"); m.add_argument("--weeks", type=int, default=config.MATERIALIZE_WEEKS_AHEAD)
    sp.add_parser("seed-demo")
    args = p.parse_args()
    {"create-admin": create_admin, "materialize": materialize, "seed-demo": seed_demo}[args.cmd](args)

if __name__ == "__main__":
    main()
