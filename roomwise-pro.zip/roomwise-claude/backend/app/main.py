import os, pathlib
from urllib.parse import urlparse
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from . import config, errors
from .routers import auth, catalog, workflow_api, admin, daily

app = FastAPI(title="Roomwise API", version="1.0", docs_url="/api/docs", openapi_url="/api/openapi.json")
errors.install(app)
if config.CORS_ORIGINS:
    app.add_middleware(CORSMiddleware, allow_origins=config.CORS_ORIGINS, allow_credentials=True,
                       allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE"], allow_headers=["Content-Type", "X-CSRF-Token"])

@app.middleware("http")
async def guard(request: Request, call_next):
    # Defence in depth for cookie sessions: reject cross-site state-changing requests by Origin header
    # (the per-session X-CSRF-Token check in deps.current_user is the primary control).
    if request.method not in ("GET", "HEAD", "OPTIONS"):
        origin = request.headers.get("origin")
        if origin and urlparse(origin).netloc != request.headers.get("host") and origin not in config.CORS_ORIGINS:
            return JSONResponse(status_code=403, content={"error": {"code": "forbidden", "message": "Cross-site request blocked.", "details": None}})
    resp = await call_next(request)
    resp.headers.setdefault("X-Content-Type-Options", "nosniff")
    resp.headers.setdefault("X-Frame-Options", "DENY")
    resp.headers.setdefault("Referrer-Policy", "same-origin")
    if request.url.path.startswith("/api/"):
        resp.headers.setdefault("Cache-Control", "no-store")
    return resp

@app.get("/api/health")
def health():
    return {"ok": True}

for r in (auth.router, catalog.router, workflow_api.router, admin.router, daily.router):
    app.include_router(r)

# The backend serves the (unchanged-design) frontend so cookies are same-origin: no CORS, no CSRF surprises.
if os.path.isdir(config.FRONTEND_DIR):
    app.mount("/", StaticFiles(directory=config.FRONTEND_DIR, html=True), name="frontend")
