import os, pathlib

def _load_dotenv():
    p = pathlib.Path(__file__).resolve().parent.parent / ".env"
    if p.exists():
        for line in p.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())
_load_dotenv()

def env(name, default=""):
    return os.environ.get(name, default)

DB = dict(host=env("RW_DB_HOST", "127.0.0.1"), port=int(env("RW_DB_PORT", "3306")),
          user=env("RW_DB_USER", "roomwise_app"), password=env("RW_DB_PASSWORD", ""),
          database=env("RW_DB_NAME", "roomwise"))
COOKIE_NAME = "rw_session"
COOKIE_SECURE = env("RW_COOKIE_SECURE", "0") == "1"
SESSION_HOURS = int(env("RW_SESSION_HOURS", "12"))
MATERIALIZE_WEEKS_AHEAD = int(env("RW_MATERIALIZE_WEEKS_AHEAD", "8"))
CORS_ORIGINS = [o.strip() for o in env("RW_CORS_ORIGINS").split(",") if o.strip()]
FRONTEND_DIR = env("RW_FRONTEND_DIR") or str(pathlib.Path(__file__).resolve().parent.parent.parent / "frontend")
