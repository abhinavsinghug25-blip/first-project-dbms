import hashlib, re, secrets, time, datetime as dt
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError, InvalidHashError
from . import config

_ph = PasswordHasher()   # Argon2id with library defaults
_USERNAME = re.compile(r"^[A-Za-z0-9_.-]{3,50}$")
_EMAIL = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

def hash_password(pw: str) -> str:
    return _ph.hash(pw)

def verify_password(h: str, pw: str) -> bool:
    try:
        return _ph.verify(h, pw)
    except (VerifyMismatchError, InvalidHashError):
        return False

def password_problem(pw: str):
    if len(pw) < 10: return "Password must be at least 10 characters."
    if len(pw) > 128: return "Password is too long."
    if not re.search(r"[A-Za-z]", pw) or not re.search(r"\d", pw): return "Password must contain letters and digits."
    return None

def valid_username(u): return bool(_USERNAME.match(u))
def valid_email(e): return bool(_EMAIL.match(e)) and len(e) <= 255

def new_session(cur, user_id: int):
    token = secrets.token_urlsafe(32)
    csrf = secrets.token_urlsafe(32)
    th = hashlib.sha256(token.encode()).hexdigest()
    exp = dt.datetime.utcnow() + dt.timedelta(hours=config.SESSION_HOURS)
    cur.execute("DELETE FROM USER_SESSION WHERE expires_at < UTC_TIMESTAMP()")
    cur.execute("INSERT INTO USER_SESSION(token_hash,user_id,csrf_token,expires_at) VALUES(%s,%s,%s,%s)", (th, user_id, csrf, exp))
    return token, csrf

def token_hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()

# ---- naive in-process brute-force throttle (per username+ip). Per-process only: documented limitation.
_fails: dict = {}
MAX_FAILS, WINDOW = 5, 900
def throttled(key) -> bool:
    n, first = _fails.get(key, (0, 0))
    if n and time.time() - first > WINDOW:
        _fails.pop(key, None); return False
    return n >= MAX_FAILS
def record_fail(key):
    n, first = _fails.get(key, (0, time.time()))
    _fails[key] = (n + 1, first)
def clear_fails(key): _fails.pop(key, None)
