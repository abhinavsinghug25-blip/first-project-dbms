"""Centralised scheduling & room-allocation service (Stage 6).

EVERY booking, approval, room change, class edit and timetable publication goes through this module,
so the rules live in exactly one place:

  1. no two overlapping ACTIVE classes in a room           (half-open intervals [start,end))
  2. ... for a teacher
  3. ... for a section
  4. room is Active and capacity >= section strength
  5. required subject feature exists in ROOM_FEATURE_MAPPING
  6. teacher has no overlapping 'Unavailable' record for that weekday
  7. start < end, inside operating hours
  8. only PUBLISHED timetables generate CLASS_SCHEDULE rows (publication policy)
  9. Cancelled classes never block (ACTIVE = Scheduled, Completed)
 10. extra classes (no recurring slot) are first-class citizens (origin='Extra')
 11. failed room changes leave the original row untouched (single transaction => rollback)
 12. requests are re-validated at approval time (callers pass the same arguments again)

Overlap predicate everywhere:  start1 < end2 AND start2 < end1.

Concurrency: callers run inside db.transaction() (READ COMMITTED). lock_resources() takes
SELECT ... FOR UPDATE row locks on ROOM, TEACHER and SECTION in one global order
(rooms ascending id -> teacher -> section). Two transactions that could allocate the same room,
teacher or section therefore serialise on a shared row; the loser re-reads committed data after
the winner commits and fails cleanly with a conflict. A lock-wait timeout/deadlock surfaces as
HTTP 409 'busy' with nothing committed. Limitation: row locks are per-database-node and
the lock-wait timeout defaults to 50 s (innodb_lock_wait_timeout).
"""
import datetime as dt
from dataclasses import dataclass, field, asdict
from .timeutil import to_min, sql_time, fmt, parse_date
from . import common

ACTIVE = ("Scheduled", "Completed")
DAY_START, DAY_END = 8 * 60, 18 * 60     # operating-hours policy (matches the UI: 08:00-18:00)

# --------------------------------------------------------------------------- pure helpers
def overlaps(s1: int, e1: int, s2: int, e2: int) -> bool:
    """Half-open interval overlap. Adjacent intervals (e1 == s2) do NOT overlap."""
    return s1 < e2 and s2 < e1

@dataclass
class Violation:
    code: str
    message: str
    ref: dict = field(default_factory=dict)

class SchedulingError(Exception):
    def __init__(self, violations):
        self.violations = violations
        super().__init__("; ".join(v.message for v in violations))
    def details(self):
        return [asdict(v) for v in self.violations]

def check_times(start: int, end: int):
    out = []
    if start >= end:
        out.append(Violation("bad_time_range", "Start time must be before end time."))
    if start < DAY_START or end > DAY_END:
        out.append(Violation("outside_hours", f"Classes must fall within {fmt(DAY_START)}-{fmt(DAY_END)}."))
    return out

def unexpected_overlaps(active_ids, allowed_ids):
    """Room overlaps that are NOT the one class the request is allowed to replace."""
    allowed = set(i for i in allowed_ids if i is not None)
    return [i for i in active_ids if i not in allowed]

# --------------------------------------------------------------------------- locking
def lock_resources(cur, room_ids, teacher_id, section_id):
    for rid in sorted(set(r for r in room_ids if r is not None)):
        cur.execute("SELECT room_id FROM ROOM WHERE room_id=%s FOR UPDATE", (rid,))
    if teacher_id is not None:
        cur.execute("SELECT teacher_id FROM TEACHER WHERE teacher_id=%s FOR UPDATE", (teacher_id,))
    if section_id is not None:
        cur.execute("SELECT section_id FROM SECTION WHERE section_id=%s FOR UPDATE", (section_id,))

# --------------------------------------------------------------------------- materialisation
def ensure_materialized(cur, d1, d2):
    """Create dated CLASS_SCHEDULE rows from PUBLISHED timetable slots for weekdays in [d1,d2].
    Idempotent (UNIQUE(timetable_slot_id,class_date) + INSERT IGNORE). Existing rows - including
    cancelled or moved ones - are never overwritten."""
    d1, d2 = parse_date(d1), parse_date(d2)
    d = d1
    while d <= d2:
        if d.weekday() < 5:
            cur.execute("""INSERT IGNORE INTO CLASS_SCHEDULE
                (timetable_slot_id,section_id,subject_id,teacher_id,room_id,class_date,start_time,end_time,status,origin)
                SELECT s.slot_id,s.section_id,s.subject_id,s.teacher_id,s.room_id,%s,s.start_time,s.end_time,'Scheduled','Timetable'
                FROM TIMETABLE_SLOT s JOIN TIMETABLE t ON t.timetable_id=s.timetable_id
                WHERE t.status='Published' AND %s BETWEEN t.effective_from AND t.effective_to
                  AND s.day_of_week=WEEKDAY(%s)""", (d, d, d))
        d += dt.timedelta(days=1)

# --------------------------------------------------------------------------- conflict detection
def _overlapping(cur, column, value, class_date, start, end, ignore):
    ignore = [i for i in ignore if i is not None]
    sql = f"""SELECT c.class_id, c.start_time, c.end_time, c.section_id, c.room_id, c.teacher_id,
                     sec.label AS section_label, sub.code AS subject_code, r.room_number
              FROM CLASS_SCHEDULE c JOIN SECTION sec ON sec.section_id=c.section_id
              JOIN SUBJECT sub ON sub.subject_id=c.subject_id JOIN ROOM r ON r.room_id=c.room_id
              WHERE c.{column}=%s AND c.class_date=%s AND c.status IN ('Scheduled','Completed')
                AND c.start_time < %s AND %s < c.end_time"""
    args = [value, class_date, sql_time(end), sql_time(start)]
    if ignore:
        sql += " AND c.class_id NOT IN (" + ",".join(["%s"] * len(ignore)) + ")"
        args += ignore
    cur.execute(sql + " ORDER BY c.start_time", args)
    return cur.fetchall()

def active_in_room(cur, room_id, class_date, start, end, ignore=()):
    return _overlapping(cur, "room_id", room_id, class_date, start, end, ignore)

def find_conflicts(cur, *, room_id, teacher_id, section_id, subject_id, class_date, start, end,
                   ignore_class_ids=(), allow_past=False):
    """Run rules 1-7 and 9. Does not lock - callers lock first when they are about to write."""
    class_date = parse_date(class_date)
    v = check_times(start, end)
    if not allow_past and class_date < dt.date.today():
        v.append(Violation("past_date", "Cannot schedule a class on a past date."))
    if v:
        return v
    cur.execute("SELECT room_number,status,capacity FROM ROOM WHERE room_id=%s", (room_id,))
    room = cur.fetchone()
    if not room:
        return [Violation("room_missing", "Room does not exist.")]
    if room["status"] != "Active":
        v.append(Violation("room_inactive", f"Room {room['room_number']} is {room['status']}."))
    cur.execute("SELECT strength,label FROM SECTION WHERE section_id=%s", (section_id,))
    sec = cur.fetchone()
    if not sec:
        return v + [Violation("section_missing", "Section does not exist.")]
    if sec["strength"] and room["capacity"] < sec["strength"]:
        v.append(Violation("capacity", f"Room {room['room_number']} seats {room['capacity']} but {sec['label']} has {sec['strength']} students."))
    cur.execute("SELECT required_feature_id FROM SUBJECT WHERE subject_id=%s", (subject_id,))
    subj = cur.fetchone()
    if not subj:
        return v + [Violation("subject_missing", "Subject does not exist.")]
    if subj["required_feature_id"]:
        cur.execute("SELECT 1 FROM ROOM_FEATURE_MAPPING WHERE room_id=%s AND feature_id=%s", (room_id, subj["required_feature_id"]))
        if not cur.fetchone():
            cur.execute("SELECT name FROM ROOM_FEATURE WHERE feature_id=%s", (subj["required_feature_id"],))
            v.append(Violation("missing_feature", f"Room {room['room_number']} lacks required feature '{cur.fetchone()['name']}'."))
    if teacher_id is not None:
        cur.execute("""SELECT note FROM TEACHER_AVAILABILITY WHERE teacher_id=%s AND day_of_week=%s AND status='Unavailable'
                       AND start_time < %s AND %s < end_time""", (teacher_id, class_date.weekday(), sql_time(end), sql_time(start)))
        if cur.fetchone():
            v.append(Violation("teacher_unavailable", "The teacher is marked unavailable at that time."))
    for column, value, code, who in (("room_id", room_id, "room_conflict", "Room"),
                                     ("teacher_id", teacher_id, "teacher_conflict", "Teacher"),
                                     ("section_id", section_id, "section_conflict", "Section")):
        if value is None:
            continue
        for c in _overlapping(cur, column, value, class_date, start, end, ignore_class_ids):
            v.append(Violation(code, f"{who} already has {c['subject_code']} ({c['section_label']}, room {c['room_number']}) "
                                     f"{fmt(to_min(c['start_time']))}-{fmt(to_min(c['end_time']))}.", {"class_id": c["class_id"]}))
    return v

# --------------------------------------------------------------------------- writes
def book_class(cur, *, section_id, subject_id, teacher_id, room_id, class_date, start, end, user_id,
               origin="Extra", source_request_id=None, ignore_class_ids=(), allow_past=False):
    """Lock -> validate -> insert. Raises SchedulingError; the caller's transaction rolls back."""
    class_date = parse_date(class_date)
    ensure_materialized(cur, class_date, class_date)
    lock_resources(cur, [room_id], teacher_id, section_id)
    violations = find_conflicts(cur, room_id=room_id, teacher_id=teacher_id, section_id=section_id, subject_id=subject_id,
                                class_date=class_date, start=start, end=end, ignore_class_ids=ignore_class_ids, allow_past=allow_past)
    if violations:
        raise SchedulingError(violations)
    cur.execute("""INSERT INTO CLASS_SCHEDULE(section_id,subject_id,teacher_id,room_id,class_date,start_time,end_time,status,origin,
                   source_request_id,created_by_user_id) VALUES(%s,%s,%s,%s,%s,%s,%s,'Scheduled',%s,%s,%s)""",
                (section_id, subject_id, teacher_id, room_id, class_date, sql_time(start), sql_time(end), origin, source_request_id, user_id))
    return cur.lastrowid

def update_class(cur, class_id, *, user_id, **changes):
    """ADMIN correction of a dated class. Locks old+new rooms, re-validates, audits."""
    cur.execute("SELECT * FROM CLASS_SCHEDULE WHERE class_id=%s", (class_id,))
    cls = cur.fetchone()
    if not cls:
        return None
    new = {"section_id": cls["section_id"], "subject_id": cls["subject_id"], "teacher_id": cls["teacher_id"], "room_id": cls["room_id"],
           "class_date": cls["class_date"], "start": to_min(cls["start_time"]), "end": to_min(cls["end_time"])}
    new.update({k: v for k, v in changes.items() if k in new})
    ensure_materialized(cur, new["class_date"], new["class_date"])
    lock_resources(cur, [cls["room_id"], new["room_id"]], new["teacher_id"], new["section_id"])
    cur.execute("SELECT * FROM CLASS_SCHEDULE WHERE class_id=%s FOR UPDATE", (class_id,))
    cls = cur.fetchone()
    if cls["status"] != "Scheduled":
        raise SchedulingError([Violation("not_scheduled", f"Class is {cls['status']} and cannot be edited.")])
    violations = find_conflicts(cur, room_id=new["room_id"], teacher_id=new["teacher_id"], section_id=new["section_id"],
                                subject_id=new["subject_id"], class_date=new["class_date"], start=new["start"], end=new["end"],
                                ignore_class_ids=[class_id], allow_past=True)
    if violations:
        raise SchedulingError(violations)
    cur.execute("""UPDATE CLASS_SCHEDULE SET section_id=%s,subject_id=%s,teacher_id=%s,room_id=%s,class_date=%s,start_time=%s,end_time=%s
                   WHERE class_id=%s""", (new["section_id"], new["subject_id"], new["teacher_id"], new["room_id"], new["class_date"],
                                          sql_time(new["start"]), sql_time(new["end"]), class_id))
    common.audit(cur, user_id, "CLASS_UPDATED", "CLASS_SCHEDULE", class_id,
                 {"before": {k: str(cls[k]) for k in ("section_id", "subject_id", "teacher_id", "room_id", "class_date", "start_time", "end_time")},
                  "after": {k: str(v) for k, v in new.items()}})
    return class_id

def cancel_class_row(cur, class_id, user_id, reason, *, action="CLASS_CANCELLED"):
    """Mark a dated class Cancelled (never delete) + CLASS_CANCELLATION history + audit, atomically
    with the caller's transaction. Returns the class row (before cancellation) or None if not cancellable."""
    cur.execute("""SELECT c.*, r.room_number, sub.code AS subject_code, sec.label AS section_label
                   FROM CLASS_SCHEDULE c JOIN ROOM r ON r.room_id=c.room_id JOIN SUBJECT sub ON sub.subject_id=c.subject_id
                   JOIN SECTION sec ON sec.section_id=c.section_id WHERE c.class_id=%s FOR UPDATE""", (class_id,))
    cls = cur.fetchone()
    if not cls or cls["status"] != "Scheduled":
        return None
    cur.execute("UPDATE CLASS_SCHEDULE SET status='Cancelled' WHERE class_id=%s", (class_id,))
    cur.execute("INSERT INTO CLASS_CANCELLATION(class_id,cancelled_by_user_id,reason) VALUES(%s,%s,%s)", (class_id, user_id, reason))
    common.audit(cur, user_id, action, "CLASS_SCHEDULE", class_id,
                 {"reason": reason, "room": cls["room_number"], "date": str(cls["class_date"]), "section": cls["section_label"]})
    return cls

# --------------------------------------------------------------------------- timetable slots (weekly template)
def find_slot_conflicts(cur, timetable_id, only_slot_id=None):
    """Self-join of TIMETABLE_SLOT: same room / teacher / section, same weekday, overlapping times."""
    out = []
    for column, code in (("room_id", "room_conflict"), ("teacher_id", "teacher_conflict"), ("section_id", "section_conflict")):
        extra = " AND (a.slot_id=%s OR b.slot_id=%s)" if only_slot_id else ""
        args = [timetable_id, timetable_id] + ([only_slot_id, only_slot_id] if only_slot_id else [])
        cur.execute(f"""SELECT a.slot_id AS a_id, b.slot_id AS b_id, a.day_of_week, a.start_time, a.end_time
                        FROM TIMETABLE_SLOT a JOIN TIMETABLE_SLOT b ON a.slot_id < b.slot_id AND a.{column}=b.{column}
                          AND a.day_of_week=b.day_of_week AND a.start_time < b.end_time AND b.start_time < a.end_time
                        WHERE a.timetable_id=%s AND b.timetable_id=%s{extra}""", args)
        for r in cur.fetchall():
            out.append(Violation(code, f"Slots {r['a_id']} and {r['b_id']} overlap on weekday {r['day_of_week']} for the same {column.split('_')[0]}.",
                                 {"slot_ids": [r["a_id"], r["b_id"]]}))
    return out

def check_slot(cur, *, timetable_id, room_id, teacher_id, section_id, subject_id, day, start, end, ignore_slot_id=None):
    v = check_times(start, end)
    if not 0 <= day <= 4:
        v.append(Violation("bad_day", "Day must be 0 (Monday) to 4 (Friday)."))
    if v:
        return v
    cur.execute("SELECT room_number,status,capacity FROM ROOM WHERE room_id=%s", (room_id,))
    room = cur.fetchone()
    if not room:
        return [Violation("room_missing", "Room does not exist.")]
    if room["status"] != "Active":
        v.append(Violation("room_inactive", f"Room {room['room_number']} is {room['status']}."))
    cur.execute("SELECT strength,label FROM SECTION WHERE section_id=%s", (section_id,))
    sec = cur.fetchone()
    if sec and sec["strength"] and room["capacity"] < sec["strength"]:
        v.append(Violation("capacity", f"Room {room['room_number']} is too small for {sec['label']}."))
    for column, value, code in (("room_id", room_id, "room_conflict"), ("teacher_id", teacher_id, "teacher_conflict"), ("section_id", section_id, "section_conflict")):
        if value is None:
            continue
        sql = f"""SELECT slot_id FROM TIMETABLE_SLOT WHERE timetable_id=%s AND {column}=%s AND day_of_week=%s
                  AND start_time < %s AND %s < end_time"""
        args = [timetable_id, value, day, sql_time(end), sql_time(start)]
        if ignore_slot_id:
            sql += " AND slot_id<>%s"; args.append(ignore_slot_id)
        cur.execute(sql, args)
        for r in cur.fetchall():
            v.append(Violation(code, f"Overlaps slot {r['slot_id']} ({column.split('_')[0]}).", {"slot_id": r["slot_id"]}))
    return v
