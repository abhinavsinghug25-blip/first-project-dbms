import datetime as dt
from typing import Annotated, Literal, Optional
from pydantic import BaseModel, ConfigDict, Field, StringConstraints

class Strict(BaseModel):
    # extra='forbid' => a browser cannot smuggle role/user_id/approver fields (mass assignment).
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

HHMM = Annotated[str, StringConstraints(pattern=r"^([01]\d|2[0-3]):[0-5]\d$")]
Reason = Annotated[str, StringConstraints(min_length=1, max_length=500, strip_whitespace=True)]

class SignupIn(Strict):
    username: str = Field(min_length=3, max_length=50)
    email: str = Field(max_length=255)
    full_name: str = Field(min_length=1, max_length=120)
    password: str = Field(max_length=128)

class LoginIn(Strict):
    username: str = Field(max_length=255)   # username or email
    password: str = Field(max_length=128)

class ClassCreate(Strict):
    section_id: int; subject_id: int; teacher_id: Optional[int] = None; room_id: int
    date: dt.date; start: HHMM; end: HHMM

class ClassUpdate(Strict):
    section_id: Optional[int] = None; subject_id: Optional[int] = None; teacher_id: Optional[int] = None
    room_id: Optional[int] = None; date: Optional[dt.date] = None; start: Optional[HHMM] = None; end: Optional[HHMM] = None

class CancelIn(Strict):
    reason: Reason

class ExtraRequestIn(Strict):
    section_id: int; subject_id: int; teacher_id: Optional[int] = None; room_id: int
    date: dt.date; start: HHMM; end: HHMM; purpose: Optional[str] = Field(default=None, max_length=500)

class RoomChangeIn(Strict):
    class_id: int; requested_room_id: int; reason: Reason

class DecisionIn(Strict):
    decision: Literal["approve", "reject"]
    reason: Optional[str] = Field(default=None, max_length=500)

# ---- admin
class RoomIn(Strict):
    block: str = Field(min_length=1, max_length=40); room_number: str = Field(min_length=1, max_length=20)
    floor_no: Optional[int] = Field(default=None, ge=-5, le=50)
    room_type: Literal["Classroom", "Laboratory", "Seminar Hall"] = "Classroom"
    capacity: int = Field(gt=0, le=2000); status: Literal["Active", "Maintenance", "Inactive"] = "Active"

class RoomPatch(Strict):
    block: Optional[str] = Field(default=None, max_length=40); room_number: Optional[str] = Field(default=None, max_length=20)
    floor_no: Optional[int] = None; room_type: Optional[Literal["Classroom", "Laboratory", "Seminar Hall"]] = None
    capacity: Optional[int] = Field(default=None, gt=0, le=2000); status: Optional[Literal["Active", "Maintenance", "Inactive"]] = None

class RoomFeaturesIn(Strict):
    feature_ids: list[int]

class FeatureIn(Strict):
    name: str = Field(min_length=1, max_length=60)

class BranchIn(Strict):
    code: str = Field(min_length=1, max_length=10); name: str = Field(min_length=1, max_length=120)

class SectionIn(Strict):
    branch_id: int; semester: int = Field(ge=1, le=10); section_no: int = Field(ge=0, le=255, default=1)
    label: Optional[str] = Field(default=None, max_length=80)
    strength: Optional[int] = Field(default=None, gt=0, le=1000); status: Literal["Active", "Inactive"] = "Active"

class SectionPatch(Strict):
    strength: Optional[int] = Field(default=None, gt=0, le=1000); status: Optional[Literal["Active", "Inactive"]] = None
    label: Optional[str] = Field(default=None, max_length=80)

class SubjectIn(Strict):
    code: str = Field(min_length=1, max_length=30); name: str = Field(min_length=1, max_length=160)
    branch_id: Optional[int] = None; required_feature_id: Optional[int] = None

class TeacherIn(Strict):
    name: str = Field(min_length=1, max_length=120); email: Optional[str] = Field(default=None, max_length=255)
    branch_id: Optional[int] = None

class AvailabilityIn(Strict):
    teacher_id: int; day_of_week: int = Field(ge=0, le=6); start: HHMM; end: HHMM
    status: Literal["Available", "Unavailable"] = "Unavailable"; note: Optional[str] = Field(default=None, max_length=200)

class TimetableIn(Strict):
    name: str = Field(min_length=1, max_length=120); effective_from: dt.date; effective_to: dt.date

class SlotIn(Strict):
    section_id: int; subject_id: int; teacher_id: Optional[int] = None; room_id: int
    day_of_week: int = Field(ge=0, le=4); start: HHMM; end: HHMM

class AssignIn(Strict):
    user_id: int; section_id: int

class UserPatch(Strict):
    is_active: Optional[bool] = None
    role: Optional[Literal["ADMIN", "VIEWER"]] = None   # CR is granted ONLY through a section assignment

class MaterializeIn(Strict):
    date_from: dt.date; date_to: dt.date

class RescheduleIn(Strict):
    room_id: int
