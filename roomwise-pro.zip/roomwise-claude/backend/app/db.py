"""MySQL access. One short-lived connection per request/transaction (simple and safe for a lab
deployment; swap for a pool such as DBUtils if load requires it).

Isolation: every transaction runs at READ COMMITTED so that, after a scheduling transaction has
acquired its row locks, ordinary SELECTs see the latest committed bookings (REPEATABLE READ would
keep serving the snapshot taken before the lock was granted).
"""
import contextlib
import pymysql
from pymysql.cursors import DictCursor
from . import config

def connect():
    conn = pymysql.connect(**config.DB, cursorclass=DictCursor, autocommit=False,
                           charset="utf8mb4",
                           init_command="SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED")
    try:
        with conn.cursor() as cur:
            cur.execute("SET SESSION time_zone = '+00:00'")
        return conn
    except BaseException:
        conn.close()
        raise

@contextlib.contextmanager
def transaction():
    """Yield a cursor; COMMIT on success, ROLLBACK on any exception."""
    conn = connect()
    try:
        with conn.cursor() as cur:
            yield cur
        conn.commit()
    except BaseException:
        conn.rollback()
        raise
    finally:
        conn.close()

def one(cur, sql, args=()):
    cur.execute(sql, args)
    return cur.fetchone()

def all_(cur, sql, args=()):
    cur.execute(sql, args)
    return cur.fetchall()
