"""Write APIs: classes, cancellations, CR-to-CR requests, room changes, decisions, notifications."""
from typing import Optional
from fastapi import APIRouter, Depends, Query
from .. import db, common, scheduling as sch, workflow as wf
from ..deps import any_user, admin_only, staff
from ..errors import bad, forbidden, not_found
from ..schemas import ClassCreate, ClassUpdate, CancelIn, ExtraRequestIn, RoomChangeIn, DecisionIn
from ..timeutil import to_min, serialize, serialize_all

router = APIRouter(prefix="/api", tags=["workflow"])

def _hhmm(v, name):
    try: return to_min(v)
    except ValueError: raise bad(f"{name} must be HH:MM")

# ------------------------------------------------------------------ classes
@router.post("/classes", status_code=201)
def create_class(body: ClassCreate, user=Depends(admin_only)):
    """ADMIN direct booking of an extra (non-recurring) class. CRs use POST /api/requests instead."""
    with db.transaction() as cur:
        try:
            cid = sch.book_class(cur, section_id=body.section_id, subject_id=body.subject_id, teacher_id=body.teacher_id, room_id=body.room_id,
                                 class_date=body.date, start=_hhmm(body.start, "start"), end=_hhmm(body.end, "end"), user_id=user["user_id"], origin="Extra")
        except sch.SchedulingError as e:
            raise wf._sch_conflict(e)
        common.audit(cur, user["user_id"], "CLASS_CREATED", "CLASS_SCHEDULE", cid, body.model_dump(mode="json"))
    return {"class_id": cid}

@router.put("/classes/{class_id}")
def edit_class(class_id: int, body: ClassUpdate, user=Depends(admin_only)):
    ch = body.model_dump(exclude_unset=True)
    if "start" in ch: ch["start"] = _hhmm(ch["start"], "start")
    if "end" in ch: ch["end"] = _hhmm(ch["end"], "end")
    if "date" in ch: ch["class_date"] = ch.pop("date")
    with db.transaction() as cur:
        try:
            if sch.update_class(cur, class_id, user_id=user["user_id"], **ch) is None:
                raise not_found("Class not found.")
        except sch.SchedulingError as e:
            raise wf._sch_conflict(e)
    return {"class_id": class_id}

@router.post("/classes/{class_id}/cancel")
def cancel(class_id: int, body: CancelIn, user=Depends(staff)):
    with db.transaction() as cur:
        return wf.cancel_class(cur, user, class_id, body.reason)

# ------------------------------------------------------------------ requests
@router.post("/requests", status_code=201)
def create_request(body: ExtraRequestIn, user=Depends(staff)):
    p = body.model_dump()
    p["start"], p["end"] = _hhmm(p["start"], "start"), _hhmm(p["end"], "end")
    from ..timeutil import fmt
    p["start"], p["end"] = fmt(p["start"]), fmt(p["end"])
    with db.transaction() as cur:
        return wf.create_extra_request(cur, user, p)

@router.post("/requests/room-change", status_code=201)
def create_room_change(body: RoomChangeIn, user=Depends(staff)):
    with db.transaction() as cur:
        return wf.create_room_change(cur, user, body.model_dump())

_LIST_SQL = """
SELECT 'extra' AS kind, q.request_id AS id, q.status, q.request_date AS date, q.start_time, q.end_time, q.purpose AS note, q.created_at,
       q.decision_reason, q.decided_at, q.requester_user_id, q.target_section_id, q.recipient_role, r.room_number AS room, sub.code AS title,
       u.full_name AS requested_by, rs.label AS requester_section, ts.label AS target_section, du.full_name AS decided_by
FROM EXTRA_CLASS_REQUEST q JOIN ROOM r ON r.room_id=q.requested_room_id JOIN SUBJECT sub ON sub.subject_id=q.subject_id
JOIN USER_ACCOUNT u ON u.user_id=q.requester_user_id JOIN SECTION rs ON rs.section_id=q.requester_section_id
LEFT JOIN SECTION ts ON ts.section_id=q.target_section_id LEFT JOIN USER_ACCOUNT du ON du.user_id=q.decided_by_user_id
UNION ALL
SELECT 'room-change', q.change_id, q.status, c.class_date, c.start_time, c.end_time, q.reason, q.created_at,
       q.decision_reason, q.decided_at, q.requester_user_id, q.target_section_id, q.recipient_role, r.room_number, sub.code,
       u.full_name, cs.label, ts.label, du.full_name
FROM ROOM_CHANGE_REQUEST q JOIN CLASS_SCHEDULE c ON c.class_id=q.class_id JOIN ROOM r ON r.room_id=q.requested_room_id
JOIN SUBJECT sub ON sub.subject_id=c.subject_id JOIN USER_ACCOUNT u ON u.user_id=q.requester_user_id JOIN SECTION cs ON cs.section_id=c.section_id
LEFT JOIN SECTION ts ON ts.section_id=q.target_section_id LEFT JOIN USER_ACCOUNT du ON du.user_id=q.decided_by_user_id"""

@router.get("/requests")
def list_requests(status: Optional[str] = Query(None, pattern="^(Pending|Approved|Rejected|Cancelled)$"),
                  limit: int = Query(100, ge=1, le=200), offset: int = Query(0, ge=0), user=Depends(staff)):
    """ADMIN sees all. CR sees requests they made + requests routed to their ACTIVELY assigned sections."""
    with db.transaction() as cur:
        scope = common.assigned_sections(cur, user)
        sql, args = f"SELECT * FROM ({_LIST_SQL}) x WHERE 1=1", []
        if status: sql += " AND x.status=%s"; args.append(status)
        if scope is not None:
            ids = sorted(scope) or [0]
            sql += f" AND (x.requester_user_id=%s OR (x.recipient_role='CR' AND x.target_section_id IN ({','.join(['%s'] * len(ids))})))"
            args += [user["user_id"], *ids]
        rows = db.all_(cur, sql + " ORDER BY x.created_at DESC LIMIT %s OFFSET %s", (*args, limit, offset))
        items = []
        for r in rows:
            r["can_decide"] = r["status"] == "Pending" and wf.can_decide(cur, user, r)
            r["can_withdraw"] = r["status"] == "Pending" and (r["requester_user_id"] == user["user_id"] or user["role"] == "ADMIN")
            r["type"] = "Extra class" if r["kind"] == "extra" else "Room change"
            items.append(serialize(r))
    return {"items": items, "limit": limit, "offset": offset}

@router.post("/requests/{kind}/{request_id}/decision")
def decision(kind: str, request_id: int, body: DecisionIn, user=Depends(staff)):
    with db.transaction() as cur:
        return wf.decide(cur, user, kind, request_id, body.decision, body.reason)

@router.post("/requests/{kind}/{request_id}/withdraw")
def withdraw(kind: str, request_id: int, user=Depends(staff)):
    if kind not in wf.KINDS: raise not_found("Unknown request kind.")
    with db.transaction() as cur:
        return wf.withdraw(cur, user, kind, request_id)

# ------------------------------------------------------------------ notifications
@router.get("/notifications")
def notifications(unread_only: bool = False, limit: int = Query(50, ge=1, le=200), offset: int = Query(0, ge=0), user=Depends(any_user)):
    with db.transaction() as cur:
        rows = db.all_(cur, "SELECT notification_id,type,message,entity_type,entity_id,is_read,created_at FROM NOTIFICATION WHERE user_id=%s"
                       + (" AND is_read=0" if unread_only else "") + " ORDER BY created_at DESC,notification_id DESC LIMIT %s OFFSET %s",
                       (user["user_id"], limit, offset))
        unread = db.one(cur, "SELECT COUNT(*) AS n FROM NOTIFICATION WHERE user_id=%s AND is_read=0", (user["user_id"],))["n"]
    return {"items": serialize_all(rows), "unread": unread}

@router.post("/notifications/{notification_id}/read")
def read_one(notification_id: int, user=Depends(any_user)):
    with db.transaction() as cur:
        cur.execute("UPDATE NOTIFICATION SET is_read=1 WHERE notification_id=%s AND user_id=%s", (notification_id, user["user_id"]))
    return {"ok": True}

@router.post("/notifications/read-all")
def read_all(user=Depends(any_user)):
    with db.transaction() as cur:
        cur.execute("UPDATE NOTIFICATION SET is_read=1 WHERE user_id=%s AND is_read=0", (user["user_id"],))
    return {"ok": True}
