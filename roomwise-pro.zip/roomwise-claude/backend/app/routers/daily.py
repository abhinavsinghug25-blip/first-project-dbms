"""Daily Schedule (date-specific view) and the displaced-class workflow (Pending rescheduling).

Authorisation is enforced HERE and in displacement.py, never by the UI:
  * GET  /api/daily-schedule                       any signed-in user (ADMIN/VIEWER: all sections; CR: assigned sections + what displaced them)
  * GET  /api/displaced-classes                    ADMIN (all) / CR (own sections); VIEWER -> 403
  * GET  /api/displaced-classes/{id}/available-rooms   same section authority
  * POST /api/displaced-classes/{id}/reschedule        same section authority; VIEWER -> 403; unrelated CR -> 403
  * POST /api/displaced-classes/{id}/dismiss           same section authority (ADMIN or the section's active CR); VIEWER/unrelated CR -> 403
None of these endpoints touches TIMETABLE / TIMETABLE_SLOT.
"""
from typing import Optional
from fastapi import APIRouter, Depends, Query
from .. import db, common, displacement as dsp
from ..deps import any_user, staff
from ..errors import bad, forbidden
from ..schemas import RescheduleIn
from ..timeutil import parse_date

router = APIRouter(prefix="/api", tags=["daily"])

@router.get("/daily-schedule")
def daily_schedule(date: str, section_id: Optional[int] = None, user=Depends(any_user)):
    try:
        parse_date(date)
    except ValueError:
        raise bad("date must be YYYY-MM-DD")
    with db.transaction() as cur:
        if section_id is not None and user["role"] == "CR":
            common.require_section(cur, user, section_id)            # a CR may only filter by their own sections
        return dsp.daily_schedule(cur, user, date, section_id)

@router.get("/displaced-classes")
def displaced_classes(status: Optional[str] = Query(None, pattern="^(Awaiting|Rescheduled|Dismissed)$"),
                      limit: int = Query(100, ge=1, le=200), offset: int = Query(0, ge=0), user=Depends(staff)):
    with db.transaction() as cur:
        return {"items": dsp.list_displaced(cur, user, status, limit, offset), "limit": limit, "offset": offset}

@router.get("/displaced-classes/{displacement_id}/available-rooms")
def available_rooms(displacement_id: int, user=Depends(staff)):
    with db.transaction() as cur:
        return dsp.available_rooms(cur, user, displacement_id)

@router.post("/displaced-classes/{displacement_id}/reschedule")
def reschedule(displacement_id: int, body: RescheduleIn, user=Depends(staff)):
    with db.transaction() as cur:
        return dsp.reschedule(cur, user, displacement_id, body.room_id)

@router.post("/displaced-classes/{displacement_id}/dismiss")
def dismiss(displacement_id: int, user=Depends(staff)):
    with db.transaction() as cur:
        return dsp.dismiss(cur, user, displacement_id)
