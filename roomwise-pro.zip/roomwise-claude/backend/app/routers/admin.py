"""ADMIN-only management of OPERATIONAL DATA (DML) through validated endpoints.
There is intentionally no raw-SQL endpoint and no DDL: schema changes are reviewed, versioned
migration scripts run by the deployment operator (see db/005_migration_example.sql)."""
from typing import Optional
from fastapi import APIRouter, Depends, Query
from .. import db, common, scheduling as sch, workflow as wf
from ..deps import admin_only
from ..errors import bad, conflict, forbidden, not_found
from ..schemas import *
from ..timeutil import to_min, sql_time, serialize, serialize_all

router = APIRouter(prefix="/api/admin", tags=["admin"], dependencies=[Depends(admin_only)])

def _patch(cur, user, table, pk, pk_val, changes: dict, entity):
    if not changes: raise bad("Nothing to update.")
    cols = ", ".join(f"{k}=%s" for k in changes)
    cur.execute(f"UPDATE {table} SET {cols} WHERE {pk}=%s", (*changes.values(), pk_val))
    if cur.rowcount == 0 and not db.one(cur, f"SELECT 1 FROM {table} WHERE {pk}=%s", (pk_val,)):
        raise not_found(f"{entity} not found.")
    common.audit(cur, user["user_id"], f"{entity.upper()}_UPDATED", table, pk_val, changes)

# ------------------------------------------------------------------ rooms & features
@router.post("/rooms", status_code=201)
def create_room(b: RoomIn, user=Depends(admin_only)):
    with db.transaction() as cur:
        cur.execute("INSERT INTO ROOM(block,room_number,floor_no,room_type,capacity,status) VALUES(%s,%s,%s,%s,%s,%s)",
                    (b.block, b.room_number, b.floor_no, b.room_type, b.capacity, b.status))
        new_id = cur.lastrowid                      # capture BEFORE audit(): its INSERT overwrites cursor.lastrowid
        common.audit(cur, user["user_id"], "ROOM_CREATED", "ROOM", new_id, b.model_dump())
        return {"room_id": new_id}

@router.patch("/rooms/{room_id}")
def patch_room(room_id: int, b: RoomPatch, user=Depends(admin_only)):
    with db.transaction() as cur:
        _patch(cur, user, "ROOM", "room_id", room_id, b.model_dump(exclude_unset=True, exclude_none=True), "Room")
    return {"room_id": room_id}

@router.put("/rooms/{room_id}/features")
def set_room_features(room_id: int, b: RoomFeaturesIn, user=Depends(admin_only)):
    with db.transaction() as cur:
        if not db.one(cur, "SELECT 1 FROM ROOM WHERE room_id=%s", (room_id,)): raise not_found("Room not found.")
        cur.execute("DELETE FROM ROOM_FEATURE_MAPPING WHERE room_id=%s", (room_id,))
        for fid in sorted(set(b.feature_ids)):
            cur.execute("INSERT INTO ROOM_FEATURE_MAPPING(room_id,feature_id) VALUES(%s,%s)", (room_id, fid))
        common.audit(cur, user["user_id"], "ROOM_FEATURES_SET", "ROOM", room_id, {"feature_ids": b.feature_ids})
    return {"room_id": room_id, "feature_ids": b.feature_ids}

@router.post("/features", status_code=201)
def create_feature(b: FeatureIn, user=Depends(admin_only)):
    with db.transaction() as cur:
        cur.execute("INSERT INTO ROOM_FEATURE(name) VALUES(%s)", (b.name,))
        new_id = cur.lastrowid                      # capture BEFORE audit(): its INSERT overwrites cursor.lastrowid
        common.audit(cur, user["user_id"], "FEATURE_CREATED", "ROOM_FEATURE", new_id, b.model_dump())
        return {"feature_id": new_id}

# ------------------------------------------------------------------ branches / sections / subjects / teachers
@router.post("/branches", status_code=201)
def create_branch(b: BranchIn, user=Depends(admin_only)):
    with db.transaction() as cur:
        cur.execute("INSERT INTO BRANCH(code,name) VALUES(%s,%s)", (b.code.upper(), b.name))
        new_id = cur.lastrowid                      # capture BEFORE audit(): its INSERT overwrites cursor.lastrowid
        common.audit(cur, user["user_id"], "BRANCH_CREATED", "BRANCH", new_id, b.model_dump())
        return {"branch_id": new_id}

@router.post("/sections", status_code=201)
def create_section(b: SectionIn, user=Depends(admin_only)):
    with db.transaction() as cur:
        br = db.one(cur, "SELECT code FROM BRANCH WHERE branch_id=%s", (b.branch_id,))
        if not br: raise not_found("Branch not found.")
        label = b.label or (f"{br['code']} · Semester {b.semester}" + (f" · Section {b.section_no}" if b.section_no else ""))
        cur.execute("INSERT INTO SECTION(branch_id,semester,section_no,label,strength,status) VALUES(%s,%s,%s,%s,%s,%s)",
                    (b.branch_id, b.semester, b.section_no, label, b.strength, b.status))
        new_id = cur.lastrowid                      # capture BEFORE audit(): its INSERT overwrites cursor.lastrowid
        common.audit(cur, user["user_id"], "SECTION_CREATED", "SECTION", new_id, {**b.model_dump(), "label": label})
        return {"section_id": new_id, "label": label}

@router.patch("/sections/{section_id}")
def patch_section(section_id: int, b: SectionPatch, user=Depends(admin_only)):
    with db.transaction() as cur:
        _patch(cur, user, "SECTION", "section_id", section_id, b.model_dump(exclude_unset=True, exclude_none=True), "Section")
    return {"section_id": section_id}

@router.post("/subjects", status_code=201)
def create_subject(b: SubjectIn, user=Depends(admin_only)):
    with db.transaction() as cur:
        cur.execute("INSERT INTO SUBJECT(code,name,branch_id,required_feature_id) VALUES(%s,%s,%s,%s)", (b.code.upper(), b.name, b.branch_id, b.required_feature_id))
        new_id = cur.lastrowid                      # capture BEFORE audit(): its INSERT overwrites cursor.lastrowid
        common.audit(cur, user["user_id"], "SUBJECT_CREATED", "SUBJECT", new_id, b.model_dump())
        return {"subject_id": new_id}

@router.post("/teachers", status_code=201)
def create_teacher(b: TeacherIn, user=Depends(admin_only)):
    with db.transaction() as cur:
        cur.execute("INSERT INTO TEACHER(name,email,branch_id) VALUES(%s,%s,%s)", (b.name, b.email, b.branch_id))
        new_id = cur.lastrowid                      # capture BEFORE audit(): its INSERT overwrites cursor.lastrowid
        common.audit(cur, user["user_id"], "TEACHER_CREATED", "TEACHER", new_id, b.model_dump())
        return {"teacher_id": new_id}

@router.post("/teacher-availability", status_code=201)
def add_availability(b: AvailabilityIn, user=Depends(admin_only)):
    s, e = to_min(b.start), to_min(b.end)
    if s >= e: raise bad("Start must be before end.")
    with db.transaction() as cur:
        cur.execute("INSERT INTO TEACHER_AVAILABILITY(teacher_id,day_of_week,start_time,end_time,status,note) VALUES(%s,%s,%s,%s,%s,%s)",
                    (b.teacher_id, b.day_of_week, sql_time(s), sql_time(e), b.status, b.note))
        new_id = cur.lastrowid                      # capture BEFORE audit(): its INSERT overwrites cursor.lastrowid
        common.audit(cur, user["user_id"], "TEACHER_AVAILABILITY_ADDED", "TEACHER_AVAILABILITY", new_id, b.model_dump())
        return {"availability_id": new_id}

@router.delete("/teacher-availability/{availability_id}")
def delete_availability(availability_id: int, user=Depends(admin_only)):
    with db.transaction() as cur:
        cur.execute("DELETE FROM TEACHER_AVAILABILITY WHERE availability_id=%s", (availability_id,))
        if cur.rowcount == 0: raise not_found("Not found.")
        common.audit(cur, user["user_id"], "TEACHER_AVAILABILITY_DELETED", "TEACHER_AVAILABILITY", availability_id)
    return {"ok": True}

# ------------------------------------------------------------------ timetables (weekly template) & slots
@router.get("/timetables")
def list_timetables():
    with db.transaction() as cur:
        return {"items": serialize_all(db.all_(cur, "SELECT t.*,(SELECT COUNT(*) FROM TIMETABLE_SLOT s WHERE s.timetable_id=t.timetable_id) AS slots FROM TIMETABLE t ORDER BY t.effective_from DESC"))}

@router.post("/timetables", status_code=201)
def create_timetable(b: TimetableIn, user=Depends(admin_only)):
    if b.effective_from > b.effective_to: raise bad("effective_from must not be after effective_to.")
    with db.transaction() as cur:
        cur.execute("INSERT INTO TIMETABLE(name,status,effective_from,effective_to,created_by_user_id) VALUES(%s,'Draft',%s,%s,%s)",
                    (b.name, b.effective_from, b.effective_to, user["user_id"]))
        new_id = cur.lastrowid                      # capture BEFORE audit(): its INSERT overwrites cursor.lastrowid
        common.audit(cur, user["user_id"], "TIMETABLE_CREATED", "TIMETABLE", new_id, b.model_dump(mode="json"))
        return {"timetable_id": new_id, "status": "Draft"}

@router.get("/timetables/{timetable_id}/slots")
def list_slots(timetable_id: int, limit: int = Query(500, ge=1, le=1000), offset: int = Query(0, ge=0)):
    with db.transaction() as cur:
        rows = db.all_(cur, "SELECT * FROM TIMETABLE_SLOT WHERE timetable_id=%s ORDER BY day_of_week,start_time,room_id LIMIT %s OFFSET %s", (timetable_id, limit, offset))
    return {"items": serialize_all(rows)}

def _draft_only(cur, timetable_id):
    t = db.one(cur, "SELECT status FROM TIMETABLE WHERE timetable_id=%s FOR UPDATE", (timetable_id,))
    if not t: raise not_found("Timetable not found.")
    if t["status"] != "Draft":
        raise conflict("Only DRAFT timetables can be edited. Correct dated classes via PUT /api/classes/{id} instead.")

@router.post("/timetables/{timetable_id}/slots", status_code=201)
def add_slot(timetable_id: int, b: SlotIn, user=Depends(admin_only)):
    s, e = to_min(b.start), to_min(b.end)
    with db.transaction() as cur:
        _draft_only(cur, timetable_id)
        sch.lock_resources(cur, [b.room_id], b.teacher_id, b.section_id)
        v = sch.check_slot(cur, timetable_id=timetable_id, room_id=b.room_id, teacher_id=b.teacher_id, section_id=b.section_id,
                           subject_id=b.subject_id, day=b.day_of_week, start=s, end=e)
        if v: raise wf._sch_conflict(sch.SchedulingError(v))
        cur.execute("""INSERT INTO TIMETABLE_SLOT(timetable_id,section_id,subject_id,teacher_id,room_id,day_of_week,start_time,end_time)
                       VALUES(%s,%s,%s,%s,%s,%s,%s,%s)""", (timetable_id, b.section_id, b.subject_id, b.teacher_id, b.room_id, b.day_of_week, sql_time(s), sql_time(e)))
        new_id = cur.lastrowid                      # capture BEFORE audit(): its INSERT overwrites cursor.lastrowid
        common.audit(cur, user["user_id"], "SLOT_CREATED", "TIMETABLE_SLOT", new_id, b.model_dump())
        return {"slot_id": new_id}

@router.delete("/timetables/{timetable_id}/slots/{slot_id}")
def delete_slot(timetable_id: int, slot_id: int, user=Depends(admin_only)):
    with db.transaction() as cur:
        _draft_only(cur, timetable_id)
        cur.execute("DELETE FROM TIMETABLE_SLOT WHERE slot_id=%s AND timetable_id=%s", (slot_id, timetable_id))
        if cur.rowcount == 0: raise not_found("Slot not found.")
        common.audit(cur, user["user_id"], "SLOT_DELETED", "TIMETABLE_SLOT", slot_id)
    return {"ok": True}

@router.post("/timetables/{timetable_id}/publish")
def publish(timetable_id: int, user=Depends(admin_only)):
    """Validates the WHOLE weekly template with the scheduling service, then publishes it. Dated classes are generated lazily
    (and idempotently) the first time a date is read or booked, or via POST /api/admin/materialize."""
    with db.transaction() as cur:
        t = db.one(cur, "SELECT * FROM TIMETABLE WHERE timetable_id=%s FOR UPDATE", (timetable_id,))
        if not t: raise not_found("Timetable not found.")
        if t["status"] == "Published": raise conflict("Already published.")
        v = sch.find_slot_conflicts(cur, timetable_id)
        if v: raise wf._sch_conflict(sch.SchedulingError(v))
        overlap = db.one(cur, "SELECT 1 FROM TIMETABLE WHERE status='Published' AND effective_from<=%s AND %s<=effective_to LIMIT 1", (t["effective_to"], t["effective_from"]))
        if overlap: raise conflict("Another published timetable covers part of this period. Archive it first.")
        cur.execute("UPDATE TIMETABLE SET status='Published',published_at=UTC_TIMESTAMP() WHERE timetable_id=%s", (timetable_id,))
        common.audit(cur, user["user_id"], "TIMETABLE_PUBLISHED", "TIMETABLE", timetable_id)
    return {"timetable_id": timetable_id, "status": "Published"}

@router.post("/timetables/{timetable_id}/archive")
def archive(timetable_id: int, user=Depends(admin_only)):
    with db.transaction() as cur:
        cur.execute("UPDATE TIMETABLE SET status='Archived' WHERE timetable_id=%s AND status<>'Archived'", (timetable_id,))
        if cur.rowcount == 0: raise not_found("Timetable not found or already archived.")
        common.audit(cur, user["user_id"], "TIMETABLE_ARCHIVED", "TIMETABLE", timetable_id)
    return {"status": "Archived"}

@router.post("/materialize")
def materialize(b: MaterializeIn, user=Depends(admin_only)):
    if b.date_to < b.date_from or (b.date_to - b.date_from).days > 366: raise bad("Range must be 0-366 days.")
    with db.transaction() as cur:
        sch.ensure_materialized(cur, b.date_from, b.date_to)
        common.audit(cur, user["user_id"], "MATERIALIZED", "CLASS_SCHEDULE", None, b.model_dump(mode="json"))
    return {"ok": True}

# ------------------------------------------------------------------ CR assignments & users
@router.get("/cr-assignments")
def list_assignments(active_only: bool = True):
    with db.transaction() as cur:
        rows = db.all_(cur, f"""SELECT a.assignment_id,a.user_id,u.username,u.full_name,a.section_id,s.label AS section,a.is_active,a.assigned_at,a.revoked_at,ab.full_name AS assigned_by
            FROM SECTION_CR_ASSIGNMENT a JOIN USER_ACCOUNT u ON u.user_id=a.user_id JOIN SECTION s ON s.section_id=a.section_id
            JOIN USER_ACCOUNT ab ON ab.user_id=a.assigned_by_user_id {'WHERE a.is_active=1' if active_only else ''} ORDER BY s.label,u.username""")
    return {"items": serialize_all(rows)}

@router.post("/cr-assignments", status_code=201)
def assign(b: AssignIn, user=Depends(admin_only)):
    """Only ADMIN grants CR. First assignment promotes VIEWER -> CR; ADMIN accounts are never downgraded."""
    with db.transaction() as cur:
        u = db.one(cur, "SELECT user_id,role,is_active FROM USER_ACCOUNT WHERE user_id=%s FOR UPDATE", (b.user_id,))
        if not u or not u["is_active"]: raise not_found("Active user not found.")
        if u["role"] == "ADMIN": raise bad("ADMIN accounts do not need CR assignments.")
        if not db.one(cur, "SELECT 1 FROM SECTION WHERE section_id=%s", (b.section_id,)): raise not_found("Section not found.")
        if db.one(cur, "SELECT 1 FROM SECTION_CR_ASSIGNMENT WHERE user_id=%s AND section_id=%s AND is_active=1", (b.user_id, b.section_id)):
            raise conflict("User is already assigned to that section.")
        cur.execute("INSERT INTO SECTION_CR_ASSIGNMENT(user_id,section_id,assigned_by_user_id) VALUES(%s,%s,%s)", (b.user_id, b.section_id, user["user_id"]))
        aid = cur.lastrowid
        if u["role"] != "CR": cur.execute("UPDATE USER_ACCOUNT SET role='CR' WHERE user_id=%s", (b.user_id,))
        common.audit(cur, user["user_id"], "CR_ASSIGNED", "SECTION_CR_ASSIGNMENT", aid, b.model_dump())
        common.notify(cur, [b.user_id], "CR_ASSIGNED", "You were assigned as CR for a section.", "SECTION", b.section_id)
    return {"assignment_id": aid}

@router.delete("/cr-assignments/{assignment_id}")
def revoke(assignment_id: int, user=Depends(admin_only)):
    with db.transaction() as cur:
        a = db.one(cur, "SELECT * FROM SECTION_CR_ASSIGNMENT WHERE assignment_id=%s FOR UPDATE", (assignment_id,))
        if not a or not a["is_active"]: raise not_found("Active assignment not found.")
        cur.execute("UPDATE SECTION_CR_ASSIGNMENT SET is_active=0,revoked_at=UTC_TIMESTAMP() WHERE assignment_id=%s", (assignment_id,))
        left = db.one(cur, "SELECT COUNT(*) AS n FROM SECTION_CR_ASSIGNMENT WHERE user_id=%s AND is_active=1", (a["user_id"],))["n"]
        if left == 0: cur.execute("UPDATE USER_ACCOUNT SET role='VIEWER' WHERE user_id=%s AND role='CR'", (a["user_id"],))
        common.audit(cur, user["user_id"], "CR_REVOKED", "SECTION_CR_ASSIGNMENT", assignment_id, {"user_id": a["user_id"], "section_id": a["section_id"]})
    return {"ok": True}

@router.get("/users")
def users(limit: int = Query(100, ge=1, le=200), offset: int = Query(0, ge=0)):
    with db.transaction() as cur:
        rows = db.all_(cur, "SELECT user_id,username,email,full_name,role,is_active,created_at,last_login_at FROM USER_ACCOUNT ORDER BY user_id LIMIT %s OFFSET %s", (limit, offset))
    return {"items": serialize_all(rows)}

@router.patch("/users/{user_id}")
def patch_user(user_id: int, b: UserPatch, user=Depends(admin_only)):
    ch = b.model_dump(exclude_unset=True, exclude_none=True)
    if not ch: raise bad("Nothing to update.")
    with db.transaction() as cur:
        target = db.one(cur, "SELECT * FROM USER_ACCOUNT WHERE user_id=%s FOR UPDATE", (user_id,))
        if not target: raise not_found("User not found.")
        losing_admin = target["role"] == "ADMIN" and (ch.get("role") == "VIEWER" or ch.get("is_active") is False)
        if losing_admin and db.one(cur, "SELECT COUNT(*) AS n FROM USER_ACCOUNT WHERE role='ADMIN' AND is_active=1 AND user_id<>%s", (user_id,))["n"] == 0:
            raise conflict("Cannot remove the last active administrator.")
        if ch.get("role") == "VIEWER":
            cur.execute("UPDATE SECTION_CR_ASSIGNMENT SET is_active=0,revoked_at=UTC_TIMESTAMP() WHERE user_id=%s AND is_active=1", (user_id,))
        if "is_active" in ch: ch["is_active"] = int(ch["is_active"])
        _patch(cur, user, "USER_ACCOUNT", "user_id", user_id, ch, "User")
        if ch.get("is_active") == 0: cur.execute("DELETE FROM USER_SESSION WHERE user_id=%s", (user_id,))
    return {"user_id": user_id}

@router.get("/audit")
def audit_log(entity_type: Optional[str] = Query(None, max_length=40), entity_id: Optional[str] = Query(None, max_length=40),
              limit: int = Query(100, ge=1, le=500), offset: int = Query(0, ge=0)):
    where, args = ["1=1"], []
    if entity_type: where.append("a.entity_type=%s"); args.append(entity_type)
    if entity_id: where.append("a.entity_id=%s"); args.append(entity_id)
    with db.transaction() as cur:
        rows = db.all_(cur, f"""SELECT a.audit_id,a.created_at,u.username AS actor,a.action,a.entity_type,a.entity_id,a.details FROM AUDIT_LOG a
            LEFT JOIN USER_ACCOUNT u ON u.user_id=a.actor_user_id WHERE {' AND '.join(where)} ORDER BY a.audit_id DESC LIMIT %s OFFSET %s""", (*args, limit, offset))
    return {"items": serialize_all(rows), "limit": limit, "offset": offset}
