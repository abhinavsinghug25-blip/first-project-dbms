"""Read APIs: rooms, availability, published timetable, dated schedules, week events, dashboard.
All require a logged-in user (VIEWER/CR/ADMIN). CR-scoped views are enforced server-side."""
import datetime as dt, math
from typing import Optional
from fastapi import APIRouter, Depends, Query
from .. import db, common, scheduling as sch, config
from ..deps import any_user, staff
from ..errors import bad, not_found, forbidden
from ..timeutil import to_min, fmt, sql_time, parse_date, monday_of, serialize, serialize_all

router = APIRouter(prefix="/api", tags=["read"])
NO_TEACHER_TEXT = "Entry is not legible in the source image"
KIND = {3: "violet-event", 5: "blue-event", 7: "blue-event"}

def _t(v, name):
    try: return to_min(v)
    except ValueError: raise bad(f"{name} must be HH:MM")

def _date(v, name):
    try: return parse_date(v)
    except ValueError: raise bad(f"{name} must be YYYY-MM-DD")

CLASS_SELECT = """SELECT c.class_id,c.class_date,c.start_time,c.end_time,c.status,c.origin,c.section_id,c.subject_id,c.teacher_id,c.room_id,
    r.room_number,r.block,sec.label AS section_label,sec.semester,sec.section_no,b.code AS branch,sub.code AS subject_code,t.name AS teacher_name
    FROM CLASS_SCHEDULE c JOIN ROOM r ON r.room_id=c.room_id JOIN SECTION sec ON sec.section_id=c.section_id
    JOIN BRANCH b ON b.branch_id=sec.branch_id JOIN SUBJECT sub ON sub.subject_id=c.subject_id LEFT JOIN TEACHER t ON t.teacher_id=c.teacher_id"""

def event_shape(r):
    s, e = to_min(r["start_time"]), to_min(r["end_time"])
    sem = r["semester"]
    tail = f"Sem {sem}" + (f" · Sec {r['section_no']}" if 0 < r["section_no"] < 90 else "")
    return {"id": r["class_id"], "classId": r["class_id"], "date": r["class_date"].isoformat(), "day": r["class_date"].weekday(),
            "start": s // 60, "duration": max(1, math.ceil((e - s) / 60)), "startTime": fmt(s), "endTime": fmt(e),
            "title": f"{r['branch']} · {r['subject_code']}", "meta": f"{r['teacher_name'] or NO_TEACHER_TEXT} · {tail}",
            "kind": KIND.get(sem, "blue-event"), "section": r["section_label"], "sectionId": r["section_id"], "room": r["room_number"],
            "roomId": r["room_id"], "branch": r["branch"], "courseCode": r["subject_code"], "subjectId": r["subject_id"],
            "teacher": r["teacher_name"] or "", "teacherId": r["teacher_id"], "semester": str(sem), "origin": r["origin"],
            "status": r["status"], "source": "server"}

@router.get("/events")
def week_events(week_start: Optional[str] = None, user=Depends(any_user)):
    """Active (non-cancelled) dated classes Mon-Fri of one week + that week's cancelled ones, in the shape the UI renders."""
    today = dt.date.today()
    base = _date(week_start, "week_start") if week_start else (today if today.weekday() < 5 else today + dt.timedelta(days=7 - today.weekday()))
    mon = monday_of(base); fri = mon + dt.timedelta(days=4)
    with db.transaction() as cur:
        sch.ensure_materialized(cur, mon, fri)
        rows = db.all_(cur, CLASS_SELECT + " WHERE c.class_date BETWEEN %s AND %s ORDER BY c.class_date,c.start_time,r.room_number", (mon, fri))
    return {"week_start": mon.isoformat(), "week_end": fri.isoformat(),
            "events": [event_shape(r) for r in rows if r["status"] != "Cancelled"],
            "cancelled": [event_shape(r) for r in rows if r["status"] == "Cancelled"]}

@router.get("/classes")
def list_classes(date_from: str, date_to: str, section_id: Optional[int] = None, room_id: Optional[int] = None,
                 teacher_id: Optional[int] = None, status: Optional[str] = Query(None, pattern="^(Scheduled|Cancelled|Completed)$"),
                 limit: int = Query(100, ge=1, le=500), offset: int = Query(0, ge=0), user=Depends(any_user)):
    d1, d2 = _date(date_from, "date_from"), _date(date_to, "date_to")
    if d2 < d1 or (d2 - d1).days > 120: raise bad("Date range must be 0-120 days.")
    where, args = ["c.class_date BETWEEN %s AND %s"], [d1, d2]
    for col, val in (("c.section_id", section_id), ("c.room_id", room_id), ("c.teacher_id", teacher_id), ("c.status", status)):
        if val is not None: where.append(f"{col}=%s"); args.append(val)
    with db.transaction() as cur:
        sch.ensure_materialized(cur, d1, d2)
        rows = db.all_(cur, CLASS_SELECT + " WHERE " + " AND ".join(where) + " ORDER BY c.class_date,c.start_time LIMIT %s OFFSET %s", (*args, limit, offset))
    return {"items": [event_shape(r) for r in rows], "limit": limit, "offset": offset}

@router.get("/my/timetable")
def my_timetable(date_from: str, date_to: str, user=Depends(staff)):
    """CR: only classes of ACTIVELY assigned sections (from the DB). ADMIN: everything."""
    d1, d2 = _date(date_from, "date_from"), _date(date_to, "date_to")
    if d2 < d1 or (d2 - d1).days > 120: raise bad("Date range must be 0-120 days.")
    with db.transaction() as cur:
        scope = common.assigned_sections(cur, user)
        sch.ensure_materialized(cur, d1, d2)
        sql, args = CLASS_SELECT + " WHERE c.class_date BETWEEN %s AND %s", [d1, d2]
        if scope is not None:
            if not scope: return {"items": []}
            sql += " AND c.section_id IN (" + ",".join(["%s"] * len(scope)) + ")"; args += sorted(scope)
        rows = db.all_(cur, sql + " ORDER BY c.class_date,c.start_time", args)
    return {"items": [event_shape(r) for r in rows]}

@router.get("/timetable/published")
def published_timetable(section_id: Optional[int] = None, room_id: Optional[int] = None, teacher_id: Optional[int] = None,
                        limit: int = Query(300, ge=1, le=1000), offset: int = Query(0, ge=0), user=Depends(any_user)):
    where, args = ["t.status='Published'"], []
    for col, val in (("s.section_id", section_id), ("s.room_id", room_id), ("s.teacher_id", teacher_id)):
        if val is not None: where.append(f"{col}=%s"); args.append(val)
    with db.transaction() as cur:
        rows = db.all_(cur, f"""SELECT s.slot_id,t.name AS timetable,s.day_of_week,s.start_time,s.end_time,r.room_number,sec.label AS section,
            sub.code AS subject_code,te.name AS teacher FROM TIMETABLE_SLOT s JOIN TIMETABLE t ON t.timetable_id=s.timetable_id
            JOIN ROOM r ON r.room_id=s.room_id JOIN SECTION sec ON sec.section_id=s.section_id JOIN SUBJECT sub ON sub.subject_id=s.subject_id
            LEFT JOIN TEACHER te ON te.teacher_id=s.teacher_id WHERE {' AND '.join(where)}
            ORDER BY s.day_of_week,s.start_time,r.room_number LIMIT %s OFFSET %s""", (*args, limit, offset))
    return {"items": serialize_all(rows), "limit": limit, "offset": offset}

# ------------------------------------------------------------------ rooms
@router.get("/rooms")
def list_rooms(q: Optional[str] = Query(None, max_length=40), status: Optional[str] = Query(None, pattern="^(Active|Maintenance|Inactive)$"),
               min_capacity: Optional[int] = Query(None, ge=1), feature_id: Optional[int] = None, room_type: Optional[str] = None,
               limit: int = Query(100, ge=1, le=200), offset: int = Query(0, ge=0), user=Depends(any_user)):
    where, args = ["1=1"], []
    if q: where.append("(r.room_number LIKE %s OR r.block LIKE %s)"); args += [f"%{q}%"] * 2
    if status: where.append("r.status=%s"); args.append(status)
    if min_capacity: where.append("r.capacity>=%s"); args.append(min_capacity)
    if room_type: where.append("r.room_type=%s"); args.append(room_type)
    if feature_id: where.append("EXISTS(SELECT 1 FROM ROOM_FEATURE_MAPPING m WHERE m.room_id=r.room_id AND m.feature_id=%s)"); args.append(feature_id)
    with db.transaction() as cur:
        rows = db.all_(cur, f"""SELECT r.*,(SELECT GROUP_CONCAT(f.name ORDER BY f.name SEPARATOR ', ') FROM ROOM_FEATURE_MAPPING m
                JOIN ROOM_FEATURE f ON f.feature_id=m.feature_id WHERE m.room_id=r.room_id) AS features
                FROM ROOM r WHERE {' AND '.join(where)} ORDER BY r.block,r.room_number LIMIT %s OFFSET %s""", (*args, limit, offset))
    return {"items": serialize_all(rows), "limit": limit, "offset": offset}

@router.get("/rooms/{room_id}")
def room_detail(room_id: int, date: Optional[str] = None, user=Depends(any_user)):
    d = _date(date, "date") if date else dt.date.today()
    with db.transaction() as cur:
        room = db.one(cur, "SELECT * FROM ROOM WHERE room_id=%s", (room_id,))
        if not room: raise not_found("Room not found.")
        feats = db.all_(cur, "SELECT f.feature_id,f.name FROM ROOM_FEATURE_MAPPING m JOIN ROOM_FEATURE f ON f.feature_id=m.feature_id WHERE m.room_id=%s", (room_id,))
        sch.ensure_materialized(cur, d, d)
        classes = db.all_(cur, CLASS_SELECT + " WHERE c.room_id=%s AND c.class_date=%s ORDER BY c.start_time", (room_id, d))
    return {"room": serialize(room), "features": feats, "date": d.isoformat(), "classes": [event_shape(c) for c in classes]}

@router.get("/availability")
def availability(date: str, start: str, end: str, min_capacity: Optional[int] = Query(None, ge=1), feature_id: Optional[int] = None,
                 user=Depends(any_user)):
    """Availability is DERIVED from active CLASS_SCHEDULE rows - there is no 'free room' flag that can go stale.
    A room cancelled-out by a CR appears as available immediately and lists the class that released it."""
    d, s, e = _date(date, "date"), _t(start, "start"), _t(end, "end")
    bad_times = sch.check_times(s, e)
    if bad_times: raise bad(bad_times[0].message)
    with db.transaction() as cur:
        sch.ensure_materialized(cur, d, d)
        rooms = db.all_(cur, "SELECT room_id,room_number,block,capacity,status FROM ROOM ORDER BY block,room_number")
        out = []
        for r in rooms:
            if min_capacity and r["capacity"] < min_capacity: continue
            if feature_id and not db.one(cur, "SELECT 1 FROM ROOM_FEATURE_MAPPING WHERE room_id=%s AND feature_id=%s", (r["room_id"], feature_id)): continue
            active = sch.active_in_room(cur, r["room_id"], d, s, e)
            released = db.all_(cur, """SELECT c.class_id,sub.code AS subject_code,sec.label AS section_label,x.reason FROM CLASS_SCHEDULE c
                JOIN CLASS_CANCELLATION x ON x.class_id=c.class_id JOIN SUBJECT sub ON sub.subject_id=c.subject_id JOIN SECTION sec ON sec.section_id=c.section_id
                WHERE c.room_id=%s AND c.class_date=%s AND c.status='Cancelled' AND c.start_time<%s AND %s<c.end_time""", (r["room_id"], d, sql_time(e), sql_time(s)))
            state = "unavailable" if r["status"] != "Active" else ("busy" if active else "available")
            out.append({**serialize(r), "state": state, "released_classes": serialize_all(released),
                        "occupied_by": [{"class_id": c["class_id"], "subject": c["subject_code"], "section": c["section_label"]} for c in active]})
    return {"date": d.isoformat(), "start": fmt(s), "end": fmt(e), "rooms": out}

# ------------------------------------------------------------------ catalogue lists
@router.get("/sections")
def sections(user=Depends(any_user)):
    with db.transaction() as cur:
        rows = db.all_(cur, "SELECT s.section_id,s.label,s.semester,s.section_no,s.strength,s.status,b.code AS branch,b.branch_id FROM SECTION s JOIN BRANCH b ON b.branch_id=s.branch_id ORDER BY s.label")
        mine = common.assigned_sections(cur, user)
    return {"items": rows, "my_section_ids": None if mine is None else sorted(mine)}

@router.get("/subjects")
def subjects(user=Depends(any_user)):
    with db.transaction() as cur:
        return {"items": db.all_(cur, "SELECT subject_id,code,name,branch_id,required_feature_id FROM SUBJECT ORDER BY code")}

@router.get("/teachers")
def teachers(user=Depends(any_user)):
    with db.transaction() as cur:
        return {"items": db.all_(cur, "SELECT teacher_id,name,branch_id FROM TEACHER ORDER BY name")}

@router.get("/branches")
def branches(user=Depends(any_user)):
    with db.transaction() as cur:
        return {"items": db.all_(cur, "SELECT branch_id,code,name FROM BRANCH ORDER BY code")}

@router.get("/features")
def features(user=Depends(any_user)):
    with db.transaction() as cur:
        return {"items": db.all_(cur, "SELECT feature_id,name FROM ROOM_FEATURE ORDER BY name")}

# ------------------------------------------------------------------ dashboard (database-driven)
@router.get("/dashboard")
def dashboard(user=Depends(any_user)):
    today = dt.date.today()
    with db.transaction() as cur:
        sch.ensure_materialized(cur, today, today)
        stats = db.one(cur, """SELECT (SELECT COUNT(*) FROM ROOM WHERE status='Active') AS active_rooms,
              (SELECT COUNT(*) FROM CLASS_SCHEDULE WHERE class_date=%s AND status IN ('Scheduled','Completed')) AS classes_today,
              (SELECT COUNT(*) FROM CLASS_SCHEDULE WHERE class_date=%s AND status='Cancelled') AS cancelled_today,
              (SELECT COUNT(*) FROM EXTRA_CLASS_REQUEST WHERE status='Pending') + (SELECT COUNT(*) FROM ROOM_CHANGE_REQUEST WHERE status='Pending') AS pending_requests_total""", (today, today))
        busy = db.all_(cur, """SELECT r.room_number,ROUND(SUM(TIME_TO_SEC(TIMEDIFF(c.end_time,c.start_time)))/3600,1) AS hours
              FROM ROOM r LEFT JOIN CLASS_SCHEDULE c ON c.room_id=r.room_id AND c.class_date=%s AND c.status IN ('Scheduled','Completed')
              WHERE r.status='Active' GROUP BY r.room_id,r.room_number ORDER BY r.room_number""", (today,))
        mine = db.one(cur, "SELECT COUNT(*) AS n FROM NOTIFICATION WHERE user_id=%s AND is_read=0", (user["user_id"],))["n"]
        out = {**stats, "room_hours_today": busy, "unread_notifications": mine, "role": user["role"]}
        if user["role"] in ("ADMIN", "CR"):
            scope = common.assigned_sections(cur, user)
            if scope is None:
                out["inbox_pending"] = out["pending_requests_total"]
            else:
                ids = sorted(scope) or [0]
                ph = ",".join(["%s"] * len(ids))
                out["inbox_pending"] = db.one(cur, f"""SELECT (SELECT COUNT(*) FROM EXTRA_CLASS_REQUEST WHERE status='Pending' AND recipient_role='CR' AND target_section_id IN ({ph}))
                    + (SELECT COUNT(*) FROM ROOM_CHANGE_REQUEST WHERE status='Pending' AND recipient_role='CR' AND target_section_id IN ({ph})) AS n""", ids + ids)["n"]
    return serialize(out) | {"room_hours_today": [serialize(b) | {"hours": float(b["hours"] or 0)} for b in busy]}
