from fastapi import APIRouter, Request, Response, Depends
from .. import db, security, config, common
from ..deps import current_user
from ..errors import bad, ApiError, unauthorized
from ..schemas import SignupIn, LoginIn

router = APIRouter(prefix="/api/auth", tags=["auth"])

def _set_cookie(resp: Response, token: str):
    resp.set_cookie(config.COOKIE_NAME, token, httponly=True, samesite="lax", secure=config.COOKIE_SECURE,
                    max_age=config.SESSION_HOURS * 3600, path="/")

def _public(cur, u, csrf):
    secs = db.all_(cur, """SELECT s.section_id,s.label FROM SECTION_CR_ASSIGNMENT a JOIN SECTION s ON s.section_id=a.section_id
                           WHERE a.user_id=%s AND a.is_active=1 ORDER BY s.label""", (u["user_id"],))
    return {"user": {"user_id": u["user_id"], "username": u["username"], "full_name": u["full_name"], "email": u["email"], "role": u["role"]},
            "csrf_token": csrf, "assigned_sections": secs}

@router.post("/signup", status_code=201)
def signup(body: SignupIn, resp: Response):
    # Public signup ALWAYS yields VIEWER: the schema has no role field and rejects extras.
    if not security.valid_username(body.username): raise bad("Username may contain letters, digits, . _ - (3-50 chars).")
    if not security.valid_email(body.email): raise bad("Enter a valid email address.")
    problem = security.password_problem(body.password)
    if problem: raise bad(problem)
    with db.transaction() as cur:
        if db.one(cur, "SELECT 1 FROM USER_ACCOUNT WHERE username=%s OR email=%s", (body.username, body.email.lower())):
            raise ApiError(409, "conflict", "That username or email is already registered.")
        cur.execute("INSERT INTO USER_ACCOUNT(username,email,full_name,password_hash,role) VALUES(%s,%s,%s,%s,'VIEWER')",
                    (body.username, body.email.lower(), body.full_name, security.hash_password(body.password)))
        uid = cur.lastrowid
        common.audit(cur, uid, "SIGNUP", "USER_ACCOUNT", uid, {"role": "VIEWER"})
        token, csrf = security.new_session(cur, uid)
        u = db.one(cur, "SELECT * FROM USER_ACCOUNT WHERE user_id=%s", (uid,))
        out = _public(cur, u, csrf)
    _set_cookie(resp, token)
    return out

@router.post("/login")
def login(body: LoginIn, request: Request, resp: Response):
    key = (body.username.lower(), request.client.host if request.client else "")
    if security.throttled(key):
        raise ApiError(429, "too_many_attempts", "Too many failed sign-ins. Try again in 15 minutes.")
    with db.transaction() as cur:
        u = db.one(cur, "SELECT * FROM USER_ACCOUNT WHERE username=%s OR email=%s", (body.username, body.username.lower()))
        ok = bool(u) and u["is_active"] and security.verify_password(u["password_hash"], body.password)
        if not ok:
            security.record_fail(key)
            raise unauthorized("Invalid username or password.")   # same message for unknown user / wrong password / disabled
        security.clear_fails(key)
        cur.execute("UPDATE USER_ACCOUNT SET last_login_at=UTC_TIMESTAMP() WHERE user_id=%s", (u["user_id"],))
        token, csrf = security.new_session(cur, u["user_id"])
        out = _public(cur, u, csrf)
    _set_cookie(resp, token)
    return out

@router.post("/logout")
def logout(request: Request, resp: Response, user=Depends(current_user)):
    token = request.cookies.get(config.COOKIE_NAME)
    with db.transaction() as cur:
        cur.execute("DELETE FROM USER_SESSION WHERE token_hash=%s", (security.token_hash(token),))
    resp.delete_cookie(config.COOKIE_NAME, path="/")
    return {"ok": True}

@router.get("/me")
def me(user=Depends(current_user)):
    with db.transaction() as cur:
        return _public(cur, user, user["csrf_token"])
