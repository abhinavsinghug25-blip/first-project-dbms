"""DEV/TEST ONLY: a stdlib stand-in for the FastAPI backend (in-memory, no MySQL) used to smoke-test the
frontend in a browser. It mimics response shapes only - it does NOT implement the real scheduling rules."""
import json, http.server, pathlib, datetime as dt, re, sys, urllib.parse
ROOT = pathlib.Path(__file__).resolve().parent.parent
EV = json.loads((ROOT / "tools" / "source_timetable.json").read_text(encoding="utf-8"))
today = dt.date.today(); mon = today - dt.timedelta(days=today.weekday())
if today.weekday() > 4: mon += dt.timedelta(days=7)
labels = sorted({e["section"] for e in EV}); SEC = [{"section_id": i + 1, "label": l, "semester": 5, "section_no": 1, "strength": 60, "status": "Active", "branch": l.split(" · ")[0], "branch_id": 1} for i, l in enumerate(labels)]
sid = {s["label"]: s["section_id"] for s in SEC}
teachers = sorted({e["teacher"] for e in EV if "legible" not in e["teacher"]}); tid = {t: i + 1 for i, t in enumerate(teachers)}
codes = sorted({e["courseCode"] for e in EV}); subid = {c: i + 1 for i, c in enumerate(codes)}
rooms = sorted({e["room"] for e in EV}); rid = {r: i + 1 for i, r in enumerate(rooms)}
classes = {}
for n, e in enumerate(EV, 1):
    d = mon + dt.timedelta(days=e["day"]); sem = re.search(r"Semester (\d)", e["section"]).group(1)
    classes[n] = {"id": n, "classId": n, "date": d.isoformat(), "day": e["day"], "start": e["start"], "duration": e["duration"], "startTime": f"{e['start']:02d}:00", "endTime": f"{e['start']+e['duration']:02d}:00",
                  "title": e["title"], "meta": e["meta"], "kind": e["kind"], "section": e["section"], "sectionId": sid[e["section"]], "room": e["room"], "roomId": rid[e["room"]], "branch": e["branch"],
                  "courseCode": e["courseCode"], "subjectId": subid[e["courseCode"]], "teacher": e["teacher"] if "legible" not in e["teacher"] else "", "teacherId": tid.get(e["teacher"]), "semester": sem, "origin": "Timetable", "status": "Scheduled", "source": "server"}
USERS = {"admin": ("ADMIN", []), "cr": ("CR", [sid["CS · Semester 5 · Section 1"]]), "viewer": ("VIEWER", [])}
sessions, requests_, nid = {}, [], [1000]
class H(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
    def user(self):
        m = re.search(r"rw_session=(\w+)", self.headers.get("Cookie", "")); return sessions.get(m.group(1)) if m else None
    def send(self, code, obj, cookie=None):
        b = json.dumps(obj).encode(); self.send_response(code); self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(b)))
        if cookie: self.send_header("Set-Cookie", cookie)
        self.end_headers(); self.wfile.write(b)
    def err(self, code, msg): self.send(code, {"error": {"code": "x", "message": msg, "details": None}})
    def body(self):
        n = int(self.headers.get("Content-Length") or 0); return json.loads(self.rfile.read(n) or b"{}")
    def do_GET(self):
        p = urllib.parse.urlparse(self.path).path
        if not p.startswith("/api/"):
            self.path = p if p != "/" else "/index.html"; self.directory = str(ROOT / "frontend"); return super().do_GET()
        u = self.user()
        if p == "/api/auth/me": return self.send(200, self.sess(u)) if u else self.err(401, "no session")
        if not u: return self.err(401, "Authentication required")
        role, secs = USERS[u]
        if p == "/api/events": return self.send(200, {"week_start": mon.isoformat(), "week_end": (mon + dt.timedelta(days=4)).isoformat(), "events": [c for c in classes.values() if c["status"] != "Cancelled"], "cancelled": [c for c in classes.values() if c["status"] == "Cancelled"]})
        if p == "/api/sections": return self.send(200, {"items": SEC, "my_section_ids": None if role == "ADMIN" else secs})
        if p == "/api/subjects": return self.send(200, {"items": [{"subject_id": i, "code": c, "name": c} for c, i in subid.items()]})
        if p == "/api/teachers": return self.send(200, {"items": [{"teacher_id": i, "name": t} for t, i in tid.items()]})
        if p == "/api/rooms": return self.send(200, {"items": [{"room_id": i, "room_number": r, "block": "Block 5", "capacity": 60, "room_type": "Classroom", "status": "Active", "features": "Projector"} for r, i in rid.items()]})
        if p in ("/api/features", "/api/branches"): return self.send(200, {"items": [{"feature_id": 1, "name": "Projector", "branch_id": 1, "code": "CS"}]})
        if p == "/api/notifications": return self.send(200, {"items": [], "unread": 0})
        if p == "/api/requests": return self.send(200, {"items": requests_}) if role != "VIEWER" else self.err(403, "Requires role")
        if p == "/api/my/timetable": return self.send(200, {"items": [c for c in classes.values() if role == "ADMIN" or c["sectionId"] in secs]})
        self.err(404, "mock: not implemented " + p)
    def sess(self, u): return {"user": {"user_id": 1, "username": u, "full_name": u.title(), "email": "", "role": USERS[u][0]}, "csrf_token": "t", "assigned_sections": [{"section_id": s, "label": "x"} for s in USERS[u][1]]}
    def do_POST(self):
        p = urllib.parse.urlparse(self.path).path; b = self.body()
        if p == "/api/auth/login":
            if b.get("username") in USERS and b.get("password") == "pw": tok = "tok" + b["username"]; sessions[tok] = b["username"]; return self.send(200, self.sess(b["username"]), f"rw_session={tok}; Path=/; HttpOnly")
            return self.err(401, "Invalid username or password.")
        u = self.user()
        if not u: return self.err(401, "Authentication required")
        if self.headers.get("X-CSRF-Token") != "t": return self.err(403, "csrf")
        m = re.match(r"/api/classes/(\d+)/cancel", p)
        if m:
            c = classes[int(m.group(1))]
            if USERS[u][0] == "CR" and c["sectionId"] not in USERS[u][1]: return self.err(403, "You are not assigned to that section.")
            if not b.get("reason"): return self.err(422, "reason required")
            c["status"] = "Cancelled"; return self.send(200, {"class_id": c["id"], "status": "Cancelled", "room_released": c["room"]})
        if p == "/api/auth/logout": sessions.pop("tok" + u, None); return self.send(200, {"ok": True})
        self.err(404, "mock: not implemented " + p)
http.server.ThreadingHTTPServer(("127.0.0.1", int(sys.argv[1]) if len(sys.argv) > 1 else 8765), H).serve_forever()
