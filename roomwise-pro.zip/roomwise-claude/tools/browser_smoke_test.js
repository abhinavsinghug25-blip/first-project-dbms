const puppeteer=require('/home/claude/.npm-global/lib/node_modules/@mermaid-js/mermaid-cli/node_modules/puppeteer');
(async()=>{
 const b=await puppeteer.launch({headless:'shell',executablePath:'/home/claude/.cache/puppeteer/chrome-headless-shell/linux-131.0.6778.204/chrome-headless-shell-linux64/chrome-headless-shell',args:['--no-sandbox']});
 const out=[];const ok=(n,c)=>{const l=(c?'PASS ':'FAIL ')+n;out.push(l);console.log(l)};
 async function session(user){
  const ctx=await b.createBrowserContext();const pg=await ctx.newPage();const errs=[];pg.on('pageerror',e=>errs.push(e.message));pg.on('console',m=>{if(m.type()==='error'&&!/Failed to load resource|googleapis|jsdelivr/.test(m.text()))errs.push(m.text())});
  await pg.setRequestInterception(true);pg.on('request',r=>/googleapis|gstatic|jsdelivr/.test(r.url())?r.abort():r.continue());
  await pg.goto('http://127.0.0.1:8765/');
  await pg.waitForSelector('#rwAuthForm');
  await pg.type('[name=username]',user);await pg.type('[name=password]','pw');await pg.click('#rwAuthSubmit');
  await pg.waitForSelector('#rwLogout',{timeout:8000});return {pg,errs};
 }
 // --- bad login shows error
 {const pg=await b.newPage();await pg.setRequestInterception(true);pg.on('request',r=>/googleapis|gstatic|jsdelivr/.test(r.url())?r.abort():r.continue());await pg.goto('http://127.0.0.1:8765/');await pg.waitForSelector('#rwAuthForm');await pg.type('[name=username]','cr');await pg.type('[name=password]','wrong');await pg.click('#rwAuthSubmit');await pg.waitForFunction(()=>document.querySelector('#rwAuthError').textContent.length>0);ok('bad login shows error',true);await pg.close();}
 // --- CR
 let {pg,errs}=await session('cr');
 const n=await pg.evaluate(()=>timetableEvents.length);ok('events loaded from API (>150): '+n,n>150);
 ok('role class on body',await pg.evaluate(()=>document.body.classList.contains('role-cr')));
 ok('no Academic setup nav for CR',await pg.evaluate(()=>!document.querySelector('.nav-item[data-page=academics]')));
 ok('no Administration nav for CR',await pg.evaluate(()=>!document.querySelector('.nav-item[data-page=admin]')));
 ok('timetable renders cards',await pg.evaluate(()=>document.querySelectorAll('#weekGrid .event').length>0));
 ok('section dropdown limited to assigned section',await pg.evaluate(()=>[...document.querySelectorAll('#scheduleForm [name=section] option')].length===2));
 // cancel flow
 await pg.evaluate(()=>go('timetable'));await pg.click('#rwCancelBtn');await pg.waitForSelector('#rwCancelForm');
 const before=await pg.evaluate(()=>timetableEvents.length);
 const opts=await pg.evaluate(()=>document.querySelectorAll('#rwCancelForm option').length);ok('cancel dialog lists own-section classes only ('+opts+')',opts>0&&opts<40);
 await pg.type('#rwCancelForm textarea','Faculty unavailable');await pg.click('#rwCancelForm button[type=submit]');
 await pg.waitForFunction(b=>timetableEvents.length===b-1,{timeout:8000},before);ok('cancelled class disappears -> room slot freed (derived availability)',true);
 // cross-section cancel attempt directly against API -> 403
 const code=await pg.evaluate(async()=>{const other=window.RW.catalog.sections.find(s=>!window.RW.mySectionIds.includes(s.section_id));const ev=sourceTimetableEvents.find(e=>e.sectionId===other.section_id);return (await fetch('/api/classes/'+ev.classId+'/cancel',{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':'t'},body:JSON.stringify({reason:'x'})})).status});
 ok('direct cross-section cancel is denied (403)',code===403);
 ok('week label shows a range',await pg.evaluate(()=>/–/.test(document.querySelector('#weekLabel').textContent)));
 ok('requests page renders',await pg.evaluate(()=>{go('requests');return !!document.querySelector('#requestsTable')}));
 ok('CR: no JS errors '+JSON.stringify(errs),errs.length===0);
 await pg.close();
 // --- VIEWER
 ({pg,errs}=await session('viewer'));
 ok('viewer has no Requests/Schedule nav',await pg.evaluate(()=>!document.querySelector('.nav-item[data-page=requests]')&&!document.querySelector('.nav-item[data-page=schedule]')));
 ok('viewer has no cancel/room-change buttons',await pg.evaluate(()=>!document.querySelector('#rwCancelBtn')&&!document.querySelector('#rwRoomChangeBtn')));
 ok('viewer cannot see edit toggle',await pg.evaluate(()=>getComputedStyle(document.querySelector('#timetableEditToggle')).display==='none'));
 ok('viewer: no JS errors '+JSON.stringify(errs),errs.length===0);await pg.close();
 // --- ADMIN
 ({pg,errs}=await session('admin'));
 ok('admin sees Administration nav',await pg.evaluate(()=>!!document.querySelector('.nav-item[data-page=admin]')));
 await pg.evaluate(()=>{document.querySelector('.nav-item[data-page=admin]').click()});
 await pg.waitForFunction(()=>document.querySelector('#rwAdminBody').textContent.includes('5222'),{timeout:8000});ok('admin console lists rooms',await pg.evaluate(()=>document.querySelector('#rwAdminBody').textContent.includes('5222')));
 ok('admin: no JS errors '+JSON.stringify(errs),errs.length===0);
 await pg.screenshot({path:'/home/claude/admin.png'});
 await pg.evaluate(()=>go('timetable'));await pg.screenshot({path:'/home/claude/tt.png'});
 console.log(out.join('\n'));await b.close();
})().catch(e=>{console.error('SMOKE CRASH',e);process.exit(1)});
