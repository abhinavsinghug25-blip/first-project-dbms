const fs=require('fs');
const src=fs.readFileSync('assets/js/app.js','utf8');
const a=src.indexOf('const room5222Events');
const b=src.indexOf('const scheduleDays');
const code=src.slice(a,b)+';module.exports=sourceTimetableEvents;';
const m={exports:{}};new Function('module',code)(m);
fs.writeFileSync('/home/claude/events.json',JSON.stringify(m.exports,null,1));
console.log(m.exports.length);
