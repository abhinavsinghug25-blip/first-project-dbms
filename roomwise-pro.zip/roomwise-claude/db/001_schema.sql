-- =====================================================================
-- Roomwise - Classroom Occupancy & Scheduling System
-- 001_schema.sql : MySQL 8.0.16+ (CHECK constraints are enforced from 8.0.16)
-- Run as a PRIVILEGED account (schema owner / deployment operator), never
-- as the application runtime account.  See 003_dcl.sql for the runtime user.
--
-- 15 baseline tables:
--   BRANCH, SECTION, TEACHER, ROOM, SUBJECT, TEACHER_AVAILABILITY,
--   ROOM_FEATURE, ROOM_FEATURE_MAPPING, TIMETABLE, TIMETABLE_SLOT,
--   CLASS_SCHEDULE, EXTRA_CLASS_REQUEST, CLASS_CANCELLATION,
--   ROOM_CHANGE_REQUEST, USER_ACCOUNT
-- Approved extensions (4):
--   SECTION_CR_ASSIGNMENT, NOTIFICATION, AUDIT_LOG, USER_SESSION
-- =====================================================================
CREATE DATABASE IF NOT EXISTS roomwise CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE roomwise;

-- ---------------------------------------------------------------- identity
CREATE TABLE USER_ACCOUNT (
  user_id        INT UNSIGNED NOT NULL AUTO_INCREMENT,
  username       VARCHAR(50)  NOT NULL,
  email          VARCHAR(255) NOT NULL,
  full_name      VARCHAR(120) NOT NULL,
  password_hash  VARCHAR(255) NOT NULL,
  -- Exactly three application login roles. Public signup => VIEWER (default).
  role           ENUM('ADMIN','CR','VIEWER') NOT NULL DEFAULT 'VIEWER',
  is_active      TINYINT(1)   NOT NULL DEFAULT 1,
  created_at     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_login_at  DATETIME     NULL,
  PRIMARY KEY (user_id),
  UNIQUE KEY uq_user_username (username),
  UNIQUE KEY uq_user_email (email),
  CONSTRAINT ck_user_username CHECK (CHAR_LENGTH(username) >= 3)
) ENGINE=InnoDB;

CREATE TABLE USER_SESSION (
  token_hash   CHAR(64)     NOT NULL,           -- SHA-256 of the cookie token
  user_id      INT UNSIGNED NOT NULL,
  csrf_token   VARCHAR(64)  NOT NULL,
  created_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expires_at   DATETIME     NOT NULL,
  PRIMARY KEY (token_hash),
  KEY ix_session_user (user_id),
  KEY ix_session_expiry (expires_at),
  CONSTRAINT fk_session_user FOREIGN KEY (user_id) REFERENCES USER_ACCOUNT(user_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------- academic master
CREATE TABLE BRANCH (
  branch_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  code      VARCHAR(10)  NOT NULL,
  name      VARCHAR(120) NOT NULL,
  PRIMARY KEY (branch_id),
  UNIQUE KEY uq_branch_code (code)
) ENGINE=InnoDB;

CREATE TABLE SECTION (
  section_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  branch_id  INT UNSIGNED NOT NULL,
  semester   TINYINT UNSIGNED NOT NULL,
  -- section_no 0 = whole-semester group (the timetable image gave no section number);
  -- electives running in parallel get additional group numbers (see docs).
  section_no TINYINT UNSIGNED NOT NULL DEFAULT 1,
  label      VARCHAR(80)  NOT NULL,             -- e.g. 'CS · Semester 5 · Section 1'
  strength   SMALLINT UNSIGNED NULL,            -- students; used for capacity checks
  status     ENUM('Active','Inactive') NOT NULL DEFAULT 'Active',
  PRIMARY KEY (section_id),
  UNIQUE KEY uq_section_group (branch_id, semester, section_no),
  UNIQUE KEY uq_section_label (label),
  CONSTRAINT fk_section_branch FOREIGN KEY (branch_id) REFERENCES BRANCH(branch_id) ON DELETE RESTRICT,
  CONSTRAINT ck_section_semester CHECK (semester BETWEEN 1 AND 10),
  CONSTRAINT ck_section_strength CHECK (strength IS NULL OR strength > 0)
) ENGINE=InnoDB;

CREATE TABLE TEACHER (
  teacher_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name       VARCHAR(120) NOT NULL,
  email      VARCHAR(255) NULL,
  branch_id  INT UNSIGNED NULL,
  PRIMARY KEY (teacher_id),
  UNIQUE KEY uq_teacher_name (name),
  CONSTRAINT fk_teacher_branch FOREIGN KEY (branch_id) REFERENCES BRANCH(branch_id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE ROOM_FEATURE (
  feature_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name       VARCHAR(60) NOT NULL,
  PRIMARY KEY (feature_id),
  UNIQUE KEY uq_feature_name (name)
) ENGINE=InnoDB;

CREATE TABLE ROOM (
  room_id     INT UNSIGNED NOT NULL AUTO_INCREMENT,
  block       VARCHAR(40)  NOT NULL,
  room_number VARCHAR(20)  NOT NULL,
  floor_no    TINYINT      NULL,
  room_type   ENUM('Classroom','Laboratory','Seminar Hall') NOT NULL DEFAULT 'Classroom',
  capacity    SMALLINT UNSIGNED NOT NULL,
  status      ENUM('Active','Maintenance','Inactive') NOT NULL DEFAULT 'Active',
  PRIMARY KEY (room_id),
  UNIQUE KEY uq_room_block_number (block, room_number),
  KEY ix_room_number (room_number),
  CONSTRAINT ck_room_capacity CHECK (capacity > 0)
) ENGINE=InnoDB;

CREATE TABLE ROOM_FEATURE_MAPPING (
  room_id    INT UNSIGNED NOT NULL,
  feature_id INT UNSIGNED NOT NULL,
  PRIMARY KEY (room_id, feature_id),
  CONSTRAINT fk_rfm_room    FOREIGN KEY (room_id)    REFERENCES ROOM(room_id) ON DELETE CASCADE,
  CONSTRAINT fk_rfm_feature FOREIGN KEY (feature_id) REFERENCES ROOM_FEATURE(feature_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE SUBJECT (
  subject_id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  code                VARCHAR(30)  NOT NULL,
  name                VARCHAR(160) NOT NULL,
  branch_id           INT UNSIGNED NULL,
  required_feature_id INT UNSIGNED NULL,       -- optional: feature a room must have
  PRIMARY KEY (subject_id),
  UNIQUE KEY uq_subject_code (code),
  CONSTRAINT fk_subject_branch  FOREIGN KEY (branch_id) REFERENCES BRANCH(branch_id) ON DELETE SET NULL,
  CONSTRAINT fk_subject_feature FOREIGN KEY (required_feature_id) REFERENCES ROOM_FEATURE(feature_id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE TEACHER_AVAILABILITY (
  availability_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  teacher_id      INT UNSIGNED NOT NULL,
  day_of_week     TINYINT UNSIGNED NOT NULL,   -- 0=Monday .. 6=Sunday (MySQL WEEKDAY())
  start_time      TIME NOT NULL,
  end_time        TIME NOT NULL,
  status          ENUM('Available','Unavailable') NOT NULL DEFAULT 'Unavailable',
  note            VARCHAR(200) NULL,
  PRIMARY KEY (availability_id),
  KEY ix_ta_teacher_day (teacher_id, day_of_week),
  CONSTRAINT fk_ta_teacher FOREIGN KEY (teacher_id) REFERENCES TEACHER(teacher_id) ON DELETE CASCADE,
  CONSTRAINT ck_ta_day  CHECK (day_of_week BETWEEN 0 AND 6),
  CONSTRAINT ck_ta_time CHECK (start_time < end_time)
) ENGINE=InnoDB;

-- ------------------------------------------------------------ timetables
CREATE TABLE TIMETABLE (
  timetable_id   INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name           VARCHAR(120) NOT NULL,
  -- Publication policy: only Published timetables generate CLASS_SCHEDULE rows.
  status         ENUM('Draft','Published','Archived') NOT NULL DEFAULT 'Draft',
  effective_from DATE NOT NULL,
  effective_to   DATE NOT NULL,
  created_by_user_id INT UNSIGNED NULL,
  published_at   DATETIME NULL,
  PRIMARY KEY (timetable_id),
  UNIQUE KEY uq_timetable_name (name),
  CONSTRAINT fk_tt_user FOREIGN KEY (created_by_user_id) REFERENCES USER_ACCOUNT(user_id) ON DELETE SET NULL,
  CONSTRAINT ck_tt_dates CHECK (effective_from <= effective_to)
) ENGINE=InnoDB;

CREATE TABLE TIMETABLE_SLOT (
  slot_id      INT UNSIGNED NOT NULL AUTO_INCREMENT,
  timetable_id INT UNSIGNED NOT NULL,
  section_id   INT UNSIGNED NOT NULL,
  subject_id   INT UNSIGNED NOT NULL,
  teacher_id   INT UNSIGNED NULL,
  room_id      INT UNSIGNED NOT NULL,
  day_of_week  TINYINT UNSIGNED NOT NULL,       -- 0=Monday .. 4=Friday
  start_time   TIME NOT NULL,
  end_time     TIME NOT NULL,
  PRIMARY KEY (slot_id),
  KEY ix_slot_room    (timetable_id, room_id,    day_of_week, start_time, end_time),
  KEY ix_slot_teacher (timetable_id, teacher_id, day_of_week, start_time, end_time),
  KEY ix_slot_section (timetable_id, section_id, day_of_week, start_time, end_time),
  CONSTRAINT fk_slot_tt      FOREIGN KEY (timetable_id) REFERENCES TIMETABLE(timetable_id) ON DELETE CASCADE,
  CONSTRAINT fk_slot_section FOREIGN KEY (section_id) REFERENCES SECTION(section_id) ON DELETE RESTRICT,
  CONSTRAINT fk_slot_subject FOREIGN KEY (subject_id) REFERENCES SUBJECT(subject_id) ON DELETE RESTRICT,
  CONSTRAINT fk_slot_teacher FOREIGN KEY (teacher_id) REFERENCES TEACHER(teacher_id) ON DELETE RESTRICT,
  CONSTRAINT fk_slot_room    FOREIGN KEY (room_id)    REFERENCES ROOM(room_id) ON DELETE RESTRICT,
  CONSTRAINT ck_slot_day  CHECK (day_of_week BETWEEN 0 AND 6),
  CONSTRAINT ck_slot_time CHECK (start_time < end_time)
) ENGINE=InnoDB;

-- CLASS_SCHEDULE is the AUTHORITATIVE record of actual dated classes.
-- Cancelled rows are kept (history) but ignored by every availability check.
CREATE TABLE CLASS_SCHEDULE (
  class_id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  timetable_slot_id INT UNSIGNED NULL,           -- NULL for extra classes
  section_id        INT UNSIGNED NOT NULL,
  subject_id        INT UNSIGNED NOT NULL,
  teacher_id        INT UNSIGNED NULL,
  room_id           INT UNSIGNED NOT NULL,
  class_date        DATE NOT NULL,
  start_time        TIME NOT NULL,
  end_time          TIME NOT NULL,
  status            ENUM('Scheduled','Cancelled','Completed') NOT NULL DEFAULT 'Scheduled',
  origin            ENUM('Timetable','Extra') NOT NULL DEFAULT 'Timetable',
  source_request_id INT UNSIGNED NULL,           -- FK added below (cyclic with EXTRA_CLASS_REQUEST)
  created_by_user_id INT UNSIGNED NULL,
  created_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (class_id),
  UNIQUE KEY uq_class_slot_date (timetable_slot_id, class_date),
  KEY ix_class_room    (room_id,    class_date, status, start_time, end_time),
  KEY ix_class_teacher (teacher_id, class_date, status, start_time, end_time),
  KEY ix_class_section (section_id, class_date, status, start_time, end_time),
  KEY ix_class_date    (class_date, status),
  CONSTRAINT fk_class_slot    FOREIGN KEY (timetable_slot_id) REFERENCES TIMETABLE_SLOT(slot_id) ON DELETE SET NULL,
  CONSTRAINT fk_class_section FOREIGN KEY (section_id) REFERENCES SECTION(section_id) ON DELETE RESTRICT,
  CONSTRAINT fk_class_subject FOREIGN KEY (subject_id) REFERENCES SUBJECT(subject_id) ON DELETE RESTRICT,
  CONSTRAINT fk_class_teacher FOREIGN KEY (teacher_id) REFERENCES TEACHER(teacher_id) ON DELETE RESTRICT,
  CONSTRAINT fk_class_room    FOREIGN KEY (room_id)    REFERENCES ROOM(room_id) ON DELETE RESTRICT,
  CONSTRAINT fk_class_user    FOREIGN KEY (created_by_user_id) REFERENCES USER_ACCOUNT(user_id) ON DELETE SET NULL,
  CONSTRAINT ck_class_time CHECK (start_time < end_time)
) ENGINE=InnoDB;

-- ------------------------------------------------------------ CR assignment
CREATE TABLE SECTION_CR_ASSIGNMENT (
  assignment_id       INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id             INT UNSIGNED NOT NULL,
  section_id          INT UNSIGNED NOT NULL,
  is_active           TINYINT(1) NOT NULL DEFAULT 1,
  assigned_by_user_id INT UNSIGNED NOT NULL,
  assigned_at         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  revoked_at          DATETIME NULL,
  -- NULL when inactive => uniqueness applies only among ACTIVE assignments; history is preserved.
  active_key          TINYINT GENERATED ALWAYS AS (IF(is_active = 1, 1, NULL)) STORED,
  PRIMARY KEY (assignment_id),
  UNIQUE KEY uq_active_assignment (user_id, section_id, active_key),
  KEY ix_assign_section (section_id, is_active),
  CONSTRAINT fk_sca_user     FOREIGN KEY (user_id) REFERENCES USER_ACCOUNT(user_id) ON DELETE CASCADE,
  CONSTRAINT fk_sca_section  FOREIGN KEY (section_id) REFERENCES SECTION(section_id) ON DELETE CASCADE,
  CONSTRAINT fk_sca_assigner FOREIGN KEY (assigned_by_user_id) REFERENCES USER_ACCOUNT(user_id) ON DELETE RESTRICT
) ENGINE=InnoDB;

-- ------------------------------------------------------------- requests
-- Design decision: EXTRA_CLASS_REQUEST was EXTENDED (no duplicate ROOM_USE_REQUEST table).
-- One row = one targeted CR-to-CR room/slot request. The approved result lives ONLY in
-- CLASS_SCHEDULE (resulting_class_id points at it) => exactly one source of booking truth.
CREATE TABLE EXTRA_CLASS_REQUEST (
  request_id           INT UNSIGNED NOT NULL AUTO_INCREMENT,
  requester_user_id    INT UNSIGNED NOT NULL,
  requester_section_id INT UNSIGNED NOT NULL,
  subject_id           INT UNSIGNED NOT NULL,
  teacher_id           INT UNSIGNED NULL,
  requested_room_id    INT UNSIGNED NOT NULL,
  request_date         DATE NOT NULL,
  start_time           TIME NOT NULL,
  end_time             TIME NOT NULL,
  purpose              VARCHAR(500) NULL,
  -- Routing: the class holding (or that released) the slot, and who may decide.
  target_class_id      BIGINT UNSIGNED NULL,     -- active class released on approval
  released_class_id    BIGINT UNSIGNED NULL,     -- cancelled class that freed the slot (informational)
  target_section_id    INT UNSIGNED NULL,
  recipient_role       ENUM('CR','ADMIN') NOT NULL,
  recipient_user_id    INT UNSIGNED NULL,        -- primary CR shown in UI; any active CR of target_section may decide
  status               ENUM('Pending','Approved','Rejected','Cancelled') NOT NULL DEFAULT 'Pending',
  decided_by_user_id   INT UNSIGNED NULL,
  decided_at           DATETIME NULL,
  decision_reason      VARCHAR(500) NULL,
  resulting_class_id   BIGINT UNSIGNED NULL,
  created_at           DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (request_id),
  KEY ix_ecr_status (status, created_at),
  KEY ix_ecr_target_section (target_section_id, status),
  KEY ix_ecr_requester (requester_user_id, status),
  CONSTRAINT fk_ecr_requester FOREIGN KEY (requester_user_id) REFERENCES USER_ACCOUNT(user_id) ON DELETE RESTRICT,
  CONSTRAINT fk_ecr_rsection  FOREIGN KEY (requester_section_id) REFERENCES SECTION(section_id) ON DELETE RESTRICT,
  CONSTRAINT fk_ecr_subject   FOREIGN KEY (subject_id) REFERENCES SUBJECT(subject_id) ON DELETE RESTRICT,
  CONSTRAINT fk_ecr_teacher   FOREIGN KEY (teacher_id) REFERENCES TEACHER(teacher_id) ON DELETE SET NULL,
  CONSTRAINT fk_ecr_room      FOREIGN KEY (requested_room_id) REFERENCES ROOM(room_id) ON DELETE RESTRICT,
  CONSTRAINT fk_ecr_target    FOREIGN KEY (target_class_id) REFERENCES CLASS_SCHEDULE(class_id) ON DELETE SET NULL,
  CONSTRAINT fk_ecr_released  FOREIGN KEY (released_class_id) REFERENCES CLASS_SCHEDULE(class_id) ON DELETE SET NULL,
  CONSTRAINT fk_ecr_tsection  FOREIGN KEY (target_section_id) REFERENCES SECTION(section_id) ON DELETE SET NULL,
  CONSTRAINT fk_ecr_recipient FOREIGN KEY (recipient_user_id) REFERENCES USER_ACCOUNT(user_id) ON DELETE SET NULL,
  CONSTRAINT fk_ecr_decider   FOREIGN KEY (decided_by_user_id) REFERENCES USER_ACCOUNT(user_id) ON DELETE SET NULL,
  CONSTRAINT fk_ecr_result    FOREIGN KEY (resulting_class_id) REFERENCES CLASS_SCHEDULE(class_id) ON DELETE SET NULL,
  CONSTRAINT ck_ecr_time CHECK (start_time < end_time)
) ENGINE=InnoDB;

ALTER TABLE CLASS_SCHEDULE
  ADD CONSTRAINT fk_class_request FOREIGN KEY (source_request_id)
  REFERENCES EXTRA_CLASS_REQUEST(request_id) ON DELETE SET NULL;

-- Cancellation history. The actor is a USER_ACCOUNT (not necessarily a TEACHER).
CREATE TABLE CLASS_CANCELLATION (
  cancellation_id      INT UNSIGNED NOT NULL AUTO_INCREMENT,
  class_id             BIGINT UNSIGNED NOT NULL,
  cancelled_by_user_id INT UNSIGNED NOT NULL,
  reason               VARCHAR(500) NOT NULL,
  cancelled_at         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (cancellation_id),
  UNIQUE KEY uq_cancel_class (class_id),
  CONSTRAINT fk_cancel_class FOREIGN KEY (class_id) REFERENCES CLASS_SCHEDULE(class_id) ON DELETE RESTRICT,
  CONSTRAINT fk_cancel_user  FOREIGN KEY (cancelled_by_user_id) REFERENCES USER_ACCOUNT(user_id) ON DELETE RESTRICT,
  CONSTRAINT ck_cancel_reason CHECK (CHAR_LENGTH(TRIM(reason)) > 0)
) ENGINE=InnoDB;

-- Room-change workflow: move an existing dated class to another room.
CREATE TABLE ROOM_CHANGE_REQUEST (
  change_id           INT UNSIGNED NOT NULL AUTO_INCREMENT,
  class_id            BIGINT UNSIGNED NOT NULL,
  requester_user_id   INT UNSIGNED NOT NULL,
  current_room_id     INT UNSIGNED NOT NULL,
  requested_room_id   INT UNSIGNED NOT NULL,
  reason              VARCHAR(500) NOT NULL,
  target_class_id     BIGINT UNSIGNED NULL,
  released_class_id   BIGINT UNSIGNED NULL,
  target_section_id   INT UNSIGNED NULL,
  recipient_role      ENUM('CR','ADMIN') NOT NULL,
  recipient_user_id   INT UNSIGNED NULL,
  status              ENUM('Pending','Approved','Rejected','Cancelled') NOT NULL DEFAULT 'Pending',
  decided_by_user_id  INT UNSIGNED NULL,
  decided_at          DATETIME NULL,
  decision_reason     VARCHAR(500) NULL,
  created_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (change_id),
  KEY ix_rcr_status (status, created_at),
  KEY ix_rcr_target_section (target_section_id, status),
  CONSTRAINT fk_rcr_class     FOREIGN KEY (class_id) REFERENCES CLASS_SCHEDULE(class_id) ON DELETE RESTRICT,
  CONSTRAINT fk_rcr_requester FOREIGN KEY (requester_user_id) REFERENCES USER_ACCOUNT(user_id) ON DELETE RESTRICT,
  CONSTRAINT fk_rcr_cur       FOREIGN KEY (current_room_id) REFERENCES ROOM(room_id) ON DELETE RESTRICT,
  CONSTRAINT fk_rcr_req       FOREIGN KEY (requested_room_id) REFERENCES ROOM(room_id) ON DELETE RESTRICT,
  CONSTRAINT fk_rcr_target    FOREIGN KEY (target_class_id) REFERENCES CLASS_SCHEDULE(class_id) ON DELETE SET NULL,
  CONSTRAINT fk_rcr_released  FOREIGN KEY (released_class_id) REFERENCES CLASS_SCHEDULE(class_id) ON DELETE SET NULL,
  CONSTRAINT fk_rcr_tsection  FOREIGN KEY (target_section_id) REFERENCES SECTION(section_id) ON DELETE SET NULL,
  CONSTRAINT fk_rcr_recipient FOREIGN KEY (recipient_user_id) REFERENCES USER_ACCOUNT(user_id) ON DELETE SET NULL,
  CONSTRAINT fk_rcr_decider   FOREIGN KEY (decided_by_user_id) REFERENCES USER_ACCOUNT(user_id) ON DELETE SET NULL,
  CONSTRAINT ck_rcr_rooms CHECK (current_room_id <> requested_room_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------- notification / audit
CREATE TABLE NOTIFICATION (
  notification_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id         INT UNSIGNED NOT NULL,
  type            VARCHAR(40)  NOT NULL,   -- CLASS_CANCELLED, REQUEST_RECEIVED, REQUEST_APPROVED, REQUEST_REJECTED ...
  message         VARCHAR(500) NOT NULL,
  entity_type     VARCHAR(40)  NULL,
  entity_id       VARCHAR(40)  NULL,
  is_read         TINYINT(1)   NOT NULL DEFAULT 0,
  created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (notification_id),
  KEY ix_notif_user (user_id, is_read, created_at),
  CONSTRAINT fk_notif_user FOREIGN KEY (user_id) REFERENCES USER_ACCOUNT(user_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE AUDIT_LOG (
  audit_id      BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  actor_user_id INT UNSIGNED NULL,
  action        VARCHAR(60)  NOT NULL,
  entity_type   VARCHAR(40)  NOT NULL,
  entity_id     VARCHAR(40)  NULL,
  details       JSON         NULL,
  created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (audit_id),
  KEY ix_audit_entity (entity_type, entity_id),
  KEY ix_audit_actor (actor_user_id, created_at),
  CONSTRAINT fk_audit_user FOREIGN KEY (actor_user_id) REFERENCES USER_ACCOUNT(user_id) ON DELETE SET NULL
) ENGINE=InnoDB;
