-- 004_demo_queries.sql : DML / joins / aggregates / subqueries / constraints / transactions for the lab.
USE roomwise;

-- ===== DML
INSERT INTO ROOM_FEATURE(name) VALUES ('Demo Feature');
UPDATE ROOM SET capacity = capacity + 5 WHERE room_number = '5222';
DELETE FROM ROOM_FEATURE WHERE name = 'Demo Feature';              -- safe: unreferenced row, WHERE clause

-- ===== Joins: today's active classes with room, section, subject, teacher
SELECT c.class_date, r.room_number, TIME_FORMAT(c.start_time,'%H:%i') AS start, sec.label, sub.code, t.name AS teacher
FROM CLASS_SCHEDULE c JOIN ROOM r USING(room_id) JOIN SECTION sec USING(section_id) JOIN SUBJECT sub USING(subject_id)
LEFT JOIN TEACHER t USING(teacher_id)
WHERE c.status IN ('Scheduled','Completed') AND c.class_date = CURDATE() ORDER BY r.room_number, c.start_time;

-- ===== Aggregate + GROUP BY + HAVING: rooms booked for more than 6 hours per weekday
SELECT r.room_number, s.day_of_week, SUM(TIME_TO_SEC(TIMEDIFF(s.end_time,s.start_time)))/3600 AS hours
FROM TIMETABLE_SLOT s JOIN ROOM r USING(room_id) GROUP BY r.room_number, s.day_of_week HAVING hours > 6 ORDER BY hours DESC;

-- ===== Subquery: teachers with no classes on Friday
SELECT name FROM TEACHER WHERE teacher_id NOT IN (SELECT teacher_id FROM TIMETABLE_SLOT WHERE day_of_week = 4 AND teacher_id IS NOT NULL);

-- ===== Room availability for 2026-11-10 10:00-11:00 (half-open overlap: start1 < end2 AND start2 < end1)
SELECT r.room_number FROM ROOM r WHERE r.status = 'Active' AND NOT EXISTS (
  SELECT 1 FROM CLASS_SCHEDULE c WHERE c.room_id = r.room_id AND c.class_date = '2026-11-10'
    AND c.status IN ('Scheduled','Completed') AND c.start_time < '11:00:00' AND '10:00:00' < c.end_time);

-- ===== Constraint demonstrations (each statement is EXPECTED TO FAIL)
INSERT INTO ROOM(block,room_number,capacity) VALUES ('Block 5','5222',50);          -- ERROR 1062 duplicate (block, room_number)
INSERT INTO ROOM(block,room_number,capacity) VALUES ('Block 9','9001',0);           -- ERROR 3819 ck_room_capacity
INSERT INTO TIMETABLE_SLOT(timetable_id,section_id,subject_id,room_id,day_of_week,start_time,end_time) VALUES (1,1,1,1,0,'10:00:00','09:00:00'); -- ck_slot_time
INSERT INTO USER_ACCOUNT(username,email,full_name,password_hash,role) VALUES ('bad_role','b@example.invalid','x','x','TEACHER'); -- ENUM: only ADMIN/CR/VIEWER
INSERT INTO TIMETABLE_SLOT(timetable_id,section_id,subject_id,room_id,day_of_week,start_time,end_time) VALUES (1,1,1,999,0,'09:00:00','10:00:00'); -- FK violation

-- ===== Transaction with ROLLBACK, then COMMIT
START TRANSACTION;
  UPDATE ROOM SET status = 'Maintenance' WHERE room_number = '5215';
  SELECT room_number, status FROM ROOM WHERE room_number = '5215';
ROLLBACK;
SELECT room_number, status FROM ROOM WHERE room_number = '5215';                   -- back to Active
START TRANSACTION;
  UPDATE ROOM SET capacity = capacity WHERE room_number = '5215';
COMMIT;

-- ===== Index use (look at key / rows)
EXPLAIN SELECT * FROM CLASS_SCHEDULE WHERE room_id = 1 AND class_date = '2026-11-10' AND status = 'Scheduled';

-- ===== Integrity verification: ACTIVE schedules must be conflict-free (all three queries must return 0 rows)
SELECT a.class_id, b.class_id FROM CLASS_SCHEDULE a JOIN CLASS_SCHEDULE b ON a.class_id < b.class_id AND a.room_id = b.room_id
  AND a.class_date = b.class_date AND a.start_time < b.end_time AND b.start_time < a.end_time
  WHERE a.status IN ('Scheduled','Completed') AND b.status IN ('Scheduled','Completed');
SELECT a.class_id, b.class_id FROM CLASS_SCHEDULE a JOIN CLASS_SCHEDULE b ON a.class_id < b.class_id AND a.teacher_id = b.teacher_id
  AND a.class_date = b.class_date AND a.start_time < b.end_time AND b.start_time < a.end_time
  WHERE a.status IN ('Scheduled','Completed') AND b.status IN ('Scheduled','Completed');
SELECT a.class_id, b.class_id FROM CLASS_SCHEDULE a JOIN CLASS_SCHEDULE b ON a.class_id < b.class_id AND a.section_id = b.section_id
  AND a.class_date = b.class_date AND a.start_time < b.end_time AND b.start_time < a.end_time
  WHERE a.status IN ('Scheduled','Completed') AND b.status IN ('Scheduled','Completed');

-- ===== Audit & history
SELECT a.created_at, u.username, a.action, a.entity_type, a.entity_id FROM AUDIT_LOG a LEFT JOIN USER_ACCOUNT u ON u.user_id = a.actor_user_id ORDER BY a.audit_id DESC LIMIT 20;
SELECT x.class_id, u.username AS cancelled_by, x.reason, x.cancelled_at FROM CLASS_CANCELLATION x JOIN USER_ACCOUNT u ON u.user_id = x.cancelled_by_user_id;
