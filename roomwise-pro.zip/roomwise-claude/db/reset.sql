-- Destroys ALL data. Privileged account only. Then re-run 001_schema.sql and 002_seed.sql.
DROP DATABASE IF EXISTS roomwise;
