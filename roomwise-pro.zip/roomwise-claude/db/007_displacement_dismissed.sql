-- 007_displacement_dismissed.sql  (versioned migration - run ONCE as a PRIVILEGED account, after 006_displaced_classes.sql)
--
-- WHY: a CR/ADMIN must be able to DISMISS a displaced class from "Pending rescheduling" (nothing more to schedule) without
-- deleting anything. Adds the status 'Dismissed' plus who/when. Requires MySQL >= 8.0.16 (CHECK constraints are enforced).
--   * CLASS_SCHEDULE, CLASS_CANCELLATION, EXTRA_CLASS_REQUEST, AUDIT_LOG, TIMETABLE, TIMETABLE_SLOT are NOT touched.
--   * No CLASS_DISPLACEMENT row is changed or deleted; every existing row keeps its status ('Awaiting' / 'Rescheduled').
--   * Idempotent: each step checks information_schema first, so re-running is a no-op. No DROP TABLE, no TRUNCATE, no data DML.
--   * The new CHECK deliberately does not reference dismissed_by_user_id (it has an ON DELETE SET NULL foreign key, and MySQL 8
--     rejects CHECK + SET NULL on the same column, error 3823) - same reason 006 avoids it for rescheduled_by_user_id.
USE roomwise;

-- 1. dismissal metadata
SET @sql = IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE()
               AND TABLE_NAME = 'CLASS_DISPLACEMENT' AND COLUMN_NAME = 'dismissed_at') = 0,
  'ALTER TABLE CLASS_DISPLACEMENT ADD COLUMN dismissed_by_user_id INT UNSIGNED NULL AFTER rescheduled_at, ADD COLUMN dismissed_at DATETIME NULL AFTER dismissed_by_user_id, ADD CONSTRAINT fk_disp_dismisser FOREIGN KEY (dismissed_by_user_id) REFERENCES USER_ACCOUNT(user_id) ON DELETE SET NULL',
  'SELECT ''007 step 1: already applied'' AS note');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- 2. drop the old state CHECK (it only knows Awaiting/Rescheduled)
SET @sql = IF((SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA = DATABASE()
               AND TABLE_NAME = 'CLASS_DISPLACEMENT' AND CONSTRAINT_NAME = 'ck_disp_state' AND CONSTRAINT_TYPE = 'CHECK') > 0,
  'ALTER TABLE CLASS_DISPLACEMENT DROP CHECK ck_disp_state', 'SELECT ''007 step 2: already applied'' AS note');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- 3. widen the enum (existing values keep their order, so stored data is unchanged)
SET @sql = IF((SELECT COLUMN_TYPE FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE()
               AND TABLE_NAME = 'CLASS_DISPLACEMENT' AND COLUMN_NAME = 'status') LIKE '%''Dismissed''%',
  'SELECT ''007 step 3: already applied'' AS note',
  'ALTER TABLE CLASS_DISPLACEMENT MODIFY COLUMN status ENUM(''Awaiting'',''Rescheduled'',''Dismissed'') NOT NULL DEFAULT ''Awaiting''');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- 4. the new state CHECK (validates the existing rows: all are Awaiting/Rescheduled and satisfy the first two branches)
SET @sql = IF((SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA = DATABASE()
               AND TABLE_NAME = 'CLASS_DISPLACEMENT' AND CONSTRAINT_NAME = 'ck_disp_state_v2' AND CONSTRAINT_TYPE = 'CHECK') = 0,
  'ALTER TABLE CLASS_DISPLACEMENT ADD CONSTRAINT ck_disp_state_v2 CHECK ((status = ''Awaiting'' AND rescheduled_class_id IS NULL AND rescheduled_at IS NULL AND dismissed_at IS NULL) OR (status = ''Rescheduled'' AND rescheduled_class_id IS NOT NULL AND rescheduled_at IS NOT NULL AND dismissed_at IS NULL) OR (status = ''Dismissed'' AND rescheduled_class_id IS NULL AND rescheduled_at IS NULL AND dismissed_at IS NOT NULL))',
  'SELECT ''007 step 4: already applied'' AS note');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- Verify (read-only):
--   SHOW CREATE TABLE CLASS_DISPLACEMENT;      SELECT status, COUNT(*) FROM CLASS_DISPLACEMENT GROUP BY status;
-- Rollback (only if NO row is Dismissed yet; destroys no history):
--   ALTER TABLE CLASS_DISPLACEMENT DROP CHECK ck_disp_state_v2;
--   ALTER TABLE CLASS_DISPLACEMENT MODIFY COLUMN status ENUM('Awaiting','Rescheduled') NOT NULL DEFAULT 'Awaiting';
--   ALTER TABLE CLASS_DISPLACEMENT DROP FOREIGN KEY fk_disp_dismisser, DROP COLUMN dismissed_at, DROP COLUMN dismissed_by_user_id;
--   ALTER TABLE CLASS_DISPLACEMENT ADD CONSTRAINT ck_disp_state CHECK ((status='Awaiting' AND rescheduled_class_id IS NULL AND rescheduled_at IS NULL) OR (status='Rescheduled' AND rescheduled_class_id IS NOT NULL AND rescheduled_at IS NOT NULL));
