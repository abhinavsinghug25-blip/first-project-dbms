-- 005_migration_example.sql (DDL via CONTROLLED, versioned migration - privileged account only).
-- Example migration "002_add_room_notes": shows ALTER/CREATE INDEX workflow for the lab demo.
-- Convention: one file per change, numbered, reviewed in git, applied once by the operator.
USE roomwise;
ALTER TABLE ROOM ADD COLUMN notes VARCHAR(255) NULL AFTER status;
CREATE INDEX ix_class_origin ON CLASS_SCHEDULE (origin, class_date);
-- Rollback (kept next to the change):
-- DROP INDEX ix_class_origin ON CLASS_SCHEDULE;
-- ALTER TABLE ROOM DROP COLUMN notes;
