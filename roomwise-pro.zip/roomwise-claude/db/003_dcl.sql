-- 003_dcl.sql  (DCL) - run as a privileged account. Creates the LEAST-PRIVILEGE runtime user.
-- The web app connects ONLY as roomwise_app: no CREATE/ALTER/DROP/INDEX/GRANT, AUDIT_LOG is append-only,
-- history tables cannot be purged. Privileges are granted TABLE BY TABLE on purpose: MySQL cannot REVOKE a
-- table privilege that was granted at schema level (ERROR 1147), so a blanket GRANT + REVOKE would not work.
-- Replace the password before use (do not commit real secrets).
CREATE USER IF NOT EXISTS 'roomwise_app'@'%' IDENTIFIED BY 'change-me';
GRANT SELECT, INSERT, UPDATE, DELETE ON roomwise.BRANCH TO 'roomwise_app'@'%';
GRANT SELECT, INSERT, UPDATE, DELETE ON roomwise.SECTION TO 'roomwise_app'@'%';
GRANT SELECT, INSERT, UPDATE, DELETE ON roomwise.TEACHER TO 'roomwise_app'@'%';
GRANT SELECT, INSERT, UPDATE, DELETE ON roomwise.ROOM TO 'roomwise_app'@'%';
GRANT SELECT, INSERT, UPDATE, DELETE ON roomwise.SUBJECT TO 'roomwise_app'@'%';
GRANT SELECT, INSERT, UPDATE, DELETE ON roomwise.TEACHER_AVAILABILITY TO 'roomwise_app'@'%';
GRANT SELECT, INSERT, UPDATE, DELETE ON roomwise.ROOM_FEATURE TO 'roomwise_app'@'%';
GRANT SELECT, INSERT, UPDATE, DELETE ON roomwise.ROOM_FEATURE_MAPPING TO 'roomwise_app'@'%';
GRANT SELECT, INSERT, UPDATE, DELETE ON roomwise.TIMETABLE TO 'roomwise_app'@'%';
GRANT SELECT, INSERT, UPDATE, DELETE ON roomwise.TIMETABLE_SLOT TO 'roomwise_app'@'%';
GRANT SELECT, INSERT, UPDATE, DELETE ON roomwise.CLASS_SCHEDULE TO 'roomwise_app'@'%';
GRANT SELECT, INSERT, UPDATE, DELETE ON roomwise.EXTRA_CLASS_REQUEST TO 'roomwise_app'@'%';
GRANT SELECT, INSERT, UPDATE, DELETE ON roomwise.ROOM_CHANGE_REQUEST TO 'roomwise_app'@'%';
GRANT SELECT, INSERT, UPDATE, DELETE ON roomwise.SECTION_CR_ASSIGNMENT TO 'roomwise_app'@'%';
GRANT SELECT, INSERT, UPDATE, DELETE ON roomwise.NOTIFICATION TO 'roomwise_app'@'%';
GRANT SELECT, INSERT, UPDATE, DELETE ON roomwise.USER_SESSION TO 'roomwise_app'@'%';
GRANT SELECT, INSERT, UPDATE ON roomwise.USER_ACCOUNT TO 'roomwise_app'@'%';        -- accounts are deactivated, never deleted
GRANT SELECT, INSERT, UPDATE ON roomwise.CLASS_CANCELLATION TO 'roomwise_app'@'%';   -- cancellation history is never purged
GRANT SELECT, INSERT         ON roomwise.AUDIT_LOG TO 'roomwise_app'@'%';            -- append-only audit trail
FLUSH PRIVILEGES;

-- Demonstration of DCL (lab):
--   SHOW GRANTS FOR 'roomwise_app'@'%';
--   -- as roomwise_app:  DROP TABLE ROOM;            -> ERROR 1142 command denied
--   -- as roomwise_app:  DELETE FROM AUDIT_LOG;      -> ERROR 1142 command denied
--   -- as roomwise_app:  ALTER TABLE ROOM ADD x INT; -> ERROR 1142 command denied
-- Optional read-only reporting account:
-- CREATE USER IF NOT EXISTS 'roomwise_report'@'%' IDENTIFIED BY 'change-me-too';
-- GRANT SELECT ON roomwise.* TO 'roomwise_report'@'%';
-- Revoke a table privilege that WAS granted at table level:
-- REVOKE DELETE ON roomwise.NOTIFICATION FROM 'roomwise_app'@'%';
