-- 006_displaced_classes.sql  (versioned migration - run ONCE as a PRIVILEGED account, after 001-005)
--
-- WHY: when a CR approves an extra-class request for a slot that another section currently holds, the existing
-- workflow already cancels the holder's CLASS_SCHEDULE row (history kept in CLASS_CANCELLATION) and books the
-- requester's class. What was missing is a durable, queryable record that the cancellation was a DISPLACEMENT and
-- whether the displaced class has been rescheduled yet. Nothing existing can hold that reliably
-- (CLASS_CANCELLATION.reason is free text), so ONE new table is added. Nothing else is altered:
--   * TIMETABLE / TIMETABLE_SLOT are not touched (the weekly template stays as published).
--   * No existing row is modified or deleted. No ENUM is changed (no "Displaced" class status -> a single source of
--     truth: a class is displaced  <=>  it is Cancelled AND has a CLASS_DISPLACEMENT row).
--   * Idempotent: CREATE TABLE IF NOT EXISTS + INSERT IGNORE backfill; safe to re-run.
USE roomwise;

CREATE TABLE IF NOT EXISTS CLASS_DISPLACEMENT (
  displacement_id        BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  original_class_id      BIGINT UNSIGNED NOT NULL,   -- the dated class that lost its room (stays in CLASS_SCHEDULE, status Cancelled)
  request_id             INT UNSIGNED    NOT NULL,   -- the approved EXTRA_CLASS_REQUEST that displaced it
  displacing_class_id    BIGINT UNSIGNED NOT NULL,   -- the class booked into the room by that request
  status                 ENUM('Awaiting','Rescheduled') NOT NULL DEFAULT 'Awaiting',
  rescheduled_class_id   BIGINT UNSIGNED NULL,       -- the NEW dated class created by rescheduling (never the original row)
  rescheduled_by_user_id INT UNSIGNED    NULL,
  rescheduled_at         DATETIME        NULL,
  created_at             DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (displacement_id),
  -- exactly-once guarantees (also the last line of defence against races):
  UNIQUE KEY uq_disp_original   (original_class_id),     -- a class can be displaced once => cannot be rescheduled twice
  UNIQUE KEY uq_disp_request    (request_id),            -- one approval displaces at most one class
  UNIQUE KEY uq_disp_displacing (displacing_class_id),
  UNIQUE KEY uq_disp_rescheduled(rescheduled_class_id),  -- a booking can be the result of one rescheduling only
  KEY ix_disp_status (status, original_class_id),
  CONSTRAINT fk_disp_original   FOREIGN KEY (original_class_id)    REFERENCES CLASS_SCHEDULE(class_id)   ON DELETE RESTRICT,
  CONSTRAINT fk_disp_request    FOREIGN KEY (request_id)           REFERENCES EXTRA_CLASS_REQUEST(request_id) ON DELETE RESTRICT,
  CONSTRAINT fk_disp_displacing FOREIGN KEY (displacing_class_id)  REFERENCES CLASS_SCHEDULE(class_id)   ON DELETE RESTRICT,
  CONSTRAINT fk_disp_new        FOREIGN KEY (rescheduled_class_id) REFERENCES CLASS_SCHEDULE(class_id)   ON DELETE RESTRICT,
  CONSTRAINT fk_disp_user       FOREIGN KEY (rescheduled_by_user_id) REFERENCES USER_ACCOUNT(user_id)    ON DELETE SET NULL,
  -- RESTRICT (not SET NULL) on columns used in a CHECK: MySQL 8 rejects CHECK + SET NULL/CASCADE (error 3823).
  CONSTRAINT ck_disp_state CHECK (
       (status = 'Awaiting'    AND rescheduled_class_id IS NULL     AND rescheduled_at IS NULL)
    OR (status = 'Rescheduled' AND rescheduled_class_id IS NOT NULL AND rescheduled_at IS NOT NULL)),
  CONSTRAINT ck_disp_distinct CHECK (original_class_id <> displacing_class_id
                                     AND (rescheduled_class_id IS NULL OR rescheduled_class_id <> original_class_id))
) ENGINE=InnoDB;

-- NO GRANT here on purpose. The application account (e.g. 'roomwise_v2'@'127.0.0.1') already holds schema-level privileges on
-- roomwise.*, which cover a table created later. This migration creates no account and changes no credentials.
-- Check it yourself after running (read-only):
--   SHOW GRANTS FOR CURRENT_USER();                 -- run as the app account, or
--   SHOW GRANTS FOR 'roomwise_v2'@'127.0.0.1';      -- run as a privileged account
-- You need SELECT, INSERT, UPDATE on `roomwise`.* (or on `roomwise`.`CLASS_DISPLACEMENT`). The app never DELETEs from this table.
-- ONLY if your grants are table-level (not schema-level), add this line yourself with YOUR account name:
--   GRANT SELECT, INSERT, UPDATE ON roomwise.CLASS_DISPLACEMENT TO '<your_app_user>'@'<its_host>';

-- Backfill (optional, additive): FUTURE classes that were already released by an APPROVED extra-class request before
-- this migration get an 'Awaiting' record so they show up under "Pending rescheduling". The cancellation reason written by
-- the existing workflow is "Released for request #<id>[: ...]" - matched exactly (so #1 never matches #12).
-- Past classes are skipped (they can no longer be rescheduled). No notification is generated for backfilled rows.
INSERT IGNORE INTO CLASS_DISPLACEMENT (original_class_id, request_id, displacing_class_id, created_at)
SELECT c.class_id, q.request_id, q.resulting_class_id, x.cancelled_at
FROM EXTRA_CLASS_REQUEST q
JOIN CLASS_SCHEDULE c     ON c.class_id = q.target_class_id AND c.status = 'Cancelled'
JOIN CLASS_CANCELLATION x ON x.class_id = c.class_id
WHERE q.status = 'Approved' AND q.resulting_class_id IS NOT NULL AND q.target_class_id IS NOT NULL
  AND c.class_date >= CURDATE()
  AND (x.reason = CONCAT('Released for request #', q.request_id)
       OR x.reason LIKE CONCAT('Released for request #', q.request_id, ': %'));

-- Rollback (kept next to the change; destroys only the NEW table, never existing data):
-- DROP TABLE CLASS_DISPLACEMENT;
